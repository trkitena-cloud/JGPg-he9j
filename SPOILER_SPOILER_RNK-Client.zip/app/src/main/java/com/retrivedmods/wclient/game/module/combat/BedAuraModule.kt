package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.ModuleGuard
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.entity.Entity
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.kiwi.BlockPlacer
import com.retrivedmods.wclient.game.kiwi.FriendManager
import com.retrivedmods.wclient.game.kiwi.ItemUseState
import com.retrivedmods.wclient.game.kiwi.entityFeetY
import com.retrivedmods.wclient.game.registry.BlockDefinition
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.ItemUseTransaction
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import kotlin.math.floor
import kotlin.math.max

/**
 * BedAura portado de KiwiMods (game/module/combat/BedAuraModule).
 *
 * Coloca camas junto al objetivo y las "usa" (explotan en Nether/End) cuando el dano simulado al
 * objetivo es >= "Enemy Dmg" y el propio <= "Self Dmg". Busca posiciones en la celda del objetivo
 * (Phase Place: tambien alrededor y a +-1 de altura) y en un radio "Proximity". La cama se orienta
 * con el yaw del paquete de input, por eso con "Rotate" el input rotado se envia ANTES de las
 * acciones (se intercepta el original y se manda una copia, como en Kiwi).
 *
 * Notas del port:
 *  - No se portan los ajustes que en Kiwi existian pero no hacian nada (Container Check,
 *    AntiButton/Btn Radius/Btn Smart) ni el overlay de render (Render/Render Max).
 *  - El ajuste del yaw en MovePlayerPacket solo afecta al paquete del jugador local (Kiwi lo
 *    aplicaba tambien al de otras entidades).
 */
class BedAuraModule : Module("bed_aura", ModuleCategory.Combat) {

    private val placeRange by intValue("Place Dist", 6, 1..12)
    private val proximity by intValue("Proximity", 4, 1..5)
    private val placeCPS by intValue("Place CPS", 20, 1..100)
    private val breakCPS by intValue("Break CPS", 20, 1..100)
    private val multiPlace by intValue("Multi Place", 3, 1..10)
    private val targetRange by intValue("Target Dist", 12, 0..20)
    private val enemyDamage by floatValue("Enemy Dmg", 4.0f, 0.0f..36.0f)
    private val selfDamageLimit by floatValue("Self Dmg", 12.0f, 0.0f..36.0f)
    private val rotate by boolValue("Rotate", true)
    private val swap by boolValue("Swap", true)
    private val eatStop by boolValue("EatStop", true)
    private val phasePlace by boolValue("Phase Place", true)
    private val selfTest by boolValue("Self Test", false)
    private val extrapolation by boolValue("Extrapolate", false)
    private val extrapolateAmt by intValue("Extrapolate Ticks", 4, 1..5)
    private val safety by boolValue("Safety", false)
    private val dmgDifference by floatValue("Ratio", 3.0f, 0.0f..5.0f)
    private val dangerDamage by floatValue("Danger Damage", 8.0f, 0.0f..12.0f)
    private val debug by boolValue("Debug", false)

    private class PlaceData(val placePos: Vector3i, val headPos: Vector3i, val targetDamage: Float, val localDamage: Float)

    private val placeList = ArrayList<PlaceData>()
    private val targetList = ArrayList<Entity>()
    private var placeTimer = 0f
    private var breakTimer = 0f
    private var lastActionTick = 0L
    private var serverSlot = -1
    private var realYaw = 0

    override fun onEnabled() {
        super.onEnabled()
        placeList.clear()
        targetList.clear()
        placeTimer = 0f
        breakTimer = 0f
        lastActionTick = 0L
        serverSlot = -1
    }

    override fun onDisabled() {
        super.onDisabled()
        placeList.clear()
        targetList.clear()
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet
        if (packet is PlayerAuthInputPacket) {
            if (packet.tick == lastActionTick) return
            lastActionTick = packet.tick
            onTick(packet, interceptablePacket)
        } else if (rotate && placeList.isNotEmpty() && packet is MovePlayerPacket &&
            packet.runtimeEntityId == session.localPlayer.runtimeEntityId
        ) {
            packet.rotation = Vector3f.from(packet.rotation.x, realYaw.toFloat(), realYaw.toFloat())
        }
    }

    private var lastPlaceGenTime = 0L
    private val BED_GEN_INTERVAL_MS = 100L

    private fun onTick(input: PlayerAuthInputPacket, interceptable: InterceptablePacket) {
        val lp = session.localPlayer
        if (eatStop && ItemUseState.using) return

        targetList.clear()
        // Copia: otro hilo puede agregar/quitar entidades mientras se recorre.
        for (e in session.level.entityMap.values.toList()) {
            if (e !== lp && e is Player && !FriendManager.isFriend(e.uuid) &&
                !FakePlayerModule.isFake(e.uniqueEntityId) &&
                lp.vec3Position.distance(e.vec3Position) <= targetRange
            ) {
                targetList.add(e)
            }
        }
        if (selfTest) targetList.add(lp)
        if (targetList.isEmpty()) return
        if (targetList.size > 1) targetList.sortBy { it.vec3Position.distance(lp.vec3Position) }

        // Escaneo reanudable: como mucho cada BED_GEN_INTERVAL_MS arranca uno nuevo, y cada tick
        // solo gasta SCAN_BUDGET_NS en evaluar candidatos. Asi el hilo de red nunca se bloquea
        // mas de unos ms (antes un solo calculo podia tardar casi 1 s y congelaba el juego).
        val nowMs = System.currentTimeMillis()
        if (!scanActive && nowMs - lastPlaceGenTime >= BED_GEN_INTERVAL_MS) {
            scanQueue.clear()
            scanFound.clear()
            for (t in targetList) buildCandidates(t)
            scanActive = true
            lastPlaceGenTime = nowMs
        }
        if (scanActive) {
            val lp = session.localPlayer
            val deadline = System.nanoTime() + SCAN_BUDGET_NS
            try {
                while (scanQueue.isNotEmpty() && System.nanoTime() < deadline) {
                    evalCandidate(scanQueue.removeFirst(), lp)?.let { scanFound.add(it) }
                }
            } catch (t: Throwable) {
                // Antes, un error dejaba scanActive en true para siempre y el escaneo nunca volvia a empezar.
                scanQueue.clear()
                scanFound.clear()
                placeList.clear()
                scanActive = false
                ModuleGuard.reportError("bed_aura.scan", t)
            }
            // Publicar lo encontrado ya, sin esperar a terminar el escaneo completo.
            if (scanFound.isNotEmpty() || scanQueue.isEmpty()) publishBedResults()
            if (scanQueue.isEmpty()) {
                scanActive = false
                dbg("§7[BedAura] Found ${placeList.size} valid positions")
            }
        }
        if (placeList.isEmpty()) {
            dbg("§7[BedAura] Found 0 valid positions")
            return
        }

        val best = placeList.first()
        if (safety) {
            if (best.targetDamage < best.localDamage - dmgDifference) {
                dbg("§7[BedAura] Safety blocked: target=${"%.1f".format(best.targetDamage)} self=${"%.1f".format(best.localDamage)}")
                return
            }
            if (best.localDamage > dangerDamage) {
                dbg("§7[BedAura] Danger blocked: self=${"%.1f".format(best.localDamage)} > $dangerDamage")
                return
            }
        }

        val bedSlot = findBedInHotbar()
        if (bedSlot == null) {
            dbg("§7[BedAura] No bed in hotbar")
            return
        }
        setYaw(best.placePos, best.headPos)

        if (rotate) {
            // El yaw debe llegar al servidor antes de colocar la cama: se envia una copia rotada
            // del input y se descarta el original.
            interceptable.intercept()
            val clone = input.clone()
            clone.rotation = Vector3f.from(input.rotation.x, realYaw.toFloat(), realYaw.toFloat())
            session.serverBound(clone)
        }

        placeTimer += 1f
        breakTimer += 1f
        val placeDelay = calcDelay(placeCPS)
        val breakDelay = calcDelay(breakCPS)
        val held = lp.inventory.heldItemSlot

        if (swap && bedSlot != held && serverSlot != bedSlot) {
            BlockPlacer.sendServerSlot(session, bedSlot)
            serverSlot = bedSlot
        }

        var cycles = 0
        while (cycles < multiPlace) {
            var acted = false
            if (placeTimer >= placeDelay) {
                placeTimer -= placeDelay
                placeBed(best.placePos, bedSlot, lp)
                acted = true
            }
            if (breakTimer >= breakDelay) {
                breakTimer -= breakDelay
                explodeBed(best.placePos, bedSlot, lp)
                acted = true
            }
            if (!acted) break
            cycles++
        }

        if (swap && serverSlot != held) {
            BlockPlacer.sendServerSlot(session, held)
            serverSlot = held
        }
        dbg(
            "§7[BedAura] Place at ${best.placePos} enemy=${"%.1f".format(best.targetDamage)} " +
                "self=${"%.1f".format(best.localDamage)} cycles=$cycles"
        )
    }

    private fun placeBed(pos: Vector3i, slot: Int, player: LocalPlayer) {
        val support = Vector3i.from(pos.x, pos.y - 1, pos.z)
        clickBlock(support, slot, player)
    }

    private fun explodeBed(pos: Vector3i, slot: Int, player: LocalPlayer) = clickBlock(pos, slot, player)

    private fun clickBlock(pos: Vector3i, slot: Int, player: LocalPlayer) {
        val def = blockDefAt(pos)
        session.serverBound(InventoryTransactionPacket().apply {
            transactionType = InventoryTransactionType.ITEM_USE
            actionType = 0
            blockPosition = pos
            blockFace = 1
            hotbarSlot = slot
            itemInHand = player.inventory.content[slot]
            playerPosition = player.vec3Position
            clickPosition = Vector3f.from(0.5f, 0.5f, 0.5f)
            blockDefinition = def
            triggerType = ItemUseTransaction.TriggerType.PLAYER_INPUT
            clientInteractPrediction = ItemUseTransaction.PredictedResult.SUCCESS
        })
    }

    private fun calcDelay(cps: Int): Float = 20f / max(1, cps)

    private class Cand(val target: Entity, val cell: Vector3i, val pos: Vector3i, val prio: Int, val kind: Int)

    private val scanQueue = ArrayDeque<Cand>()
    private val scanFound = ArrayList<Pair<PlaceData, Int>>()
    private var scanActive = false
    private val SCAN_BUDGET_NS = 3_000_000L

    private fun buildCandidates(target: Entity) {
        val ex = if (extrapolation) floor(target.motionX * extrapolateAmt).toInt() else 0
        val ey = if (extrapolation) floor(target.motionY * extrapolateAmt).toInt() else 0
        val ez = if (extrapolation) floor(target.motionZ * extrapolateAmt).toInt() else 0
        val cell = Vector3i.from(
            floor(target.posX).toInt() + ex,
            floor(session.entityFeetY(target)).toInt() + ey,
            floor(target.posZ).toInt() + ez
        )
        dbg("§7[BedAura] Target feet pos: ${cell.x}, ${cell.y}, ${cell.z}")

        // prioridad 0 = misma altura (phase), 1 = +-1 de altura (phase), 2 = alrededor (proximity)
        if (phasePlace) {
            for (dy in -1..1) for (dx in -1..1) for (dz in -1..1) {
                if (dx == 0 && dz == 0) continue
                val pos = Vector3i.from(cell.x + dx, cell.y + dy, cell.z + dz)
                scanQueue.add(Cand(target, cell, pos, if (dy == 0) 0 else 1, 0))
            }
        }
        for (dx in -proximity..proximity) for (dz in -proximity..proximity) for (dy in -3..0) {
            val pos = Vector3i.from(cell.x + dx, cell.y + dy, cell.z + dz)
            scanQueue.add(Cand(target, cell, pos, 2, 1))
        }
    }

    /** Evalua un candidato. Misma logica que antes; devuelve null si no es valido. */
    private fun publishBedResults() {
        scanFound.sortWith(
            compareBy<Pair<PlaceData, Int>> { it.second }
                .thenByDescending { it.first.targetDamage }
                .thenBy { it.first.localDamage }
        )
        placeList.clear()
        placeList.addAll(scanFound.map { it.first })
    }

    private fun evalCandidate(c: Cand, lp: LocalPlayer): Pair<PlaceData, Int>? {
        val target = c.target
        val pos = c.pos
        if (c.kind == 0) {
            if (!isBlockValid(pos)) return null
            val head = headTowardEnemy(pos, c.cell) ?: return null
            if (pos == head || isPlayerAtBlock(pos)) return null
            val dmg = calculateDamage(pos, target)
            if (dmg < enemyDamage) return null
            val self = calculateDamage(pos, lp)
            return if (self <= selfDamageLimit) PlaceData(pos, head, dmg, self) to c.prio else null
        } else {
            if (!isBlockValid(pos)) return null
            val head = getHeadPos(pos, target)
            if (pos == head || isPlayerAtBlock(pos) || isPlayerAtBlock(head)) return null
            val dmg = calculateDamage(pos, target)
            if (dmg < enemyDamage) return null
            val self = calculateDamage(pos, lp)
            return if (self <= selfDamageLimit) PlaceData(pos, head, dmg, self) to 2 else null
        }
    }

    private fun headTowardEnemy(placePos: Vector3i, targetCell: Vector3i): Vector3i? {
        fun distSq(dir: Vector3i): Float {
            val x = (placePos.x + dir.x + 0.5f) - (targetCell.x + 0.5f)
            val z = (placePos.z + dir.z + 0.5f) - (targetCell.z + 0.5f)
            return x * x + z * z
        }
        for (dir in DIRS.sortedBy { distSq(it) }) {
            val cand = Vector3i.from(placePos.x + dir.x, placePos.y, placePos.z + dir.z)
            if (cand == placePos) continue
            if (cand == targetCell) return cand
            if (isReplaceableOrEmpty(cand) && !isPlayerAtBlock(cand)) return cand
        }
        return null
    }

    private fun isBlockValid(pos: Vector3i): Boolean {
        if (pos.x == 0 && pos.y == 0 && pos.z == 0) return false
        val lp = session.localPlayer
        val world = session.kiwiWorld
        val from = Vector3f.from(lp.posX, session.entityFeetY(lp), lp.posZ)
        if (from.distance(Vector3f.from(pos.x + 0.5f, pos.y + 0.5f, pos.z + 0.5f)) > placeRange) return false

        val airId = session.blockMapping.airId
        val rid = world.getBlockRuntimeId(pos)
        if (world.isBlockKnown(pos) && rid != airId) {
            val id = session.blockMapping.getDefinition(rid).identifier
            val isBedOrFire = id == "minecraft:bed" || id.endsWith("_bed") || id == "minecraft:fire"
            if (id !in REPLACEABLE && (!isBedOrFire || !phasePlace)) return false
        }
        val below = Vector3i.from(pos.x, pos.y - 1, pos.z)
        return !(world.isBlockKnown(below) && world.getBlockRuntimeId(below) == airId)
    }

    private fun isReplaceableOrEmpty(pos: Vector3i): Boolean {
        val airId = session.blockMapping.airId
        val world = session.kiwiWorld
        if (world.isBlockKnown(pos)) {
            val rid = world.getBlockRuntimeId(pos)
            if (rid != airId) return session.blockMapping.getDefinition(rid).identifier in REPLACEABLE
        }
        return true
    }

    private fun isPlayerAtBlock(pos: Vector3i): Boolean {
        for (e in session.level.entityMap.values) {
            if (e is Player && bodyIntersects(e, pos)) return true
        }
        return bodyIntersects(session.localPlayer, pos)
    }

    private fun bodyIntersects(e: Player, pos: Vector3i): Boolean {
        val feet = session.entityFeetY(e)
        return e.posX >= pos.x && e.posX < pos.x + 1 &&
            feet >= pos.y && feet < pos.y + 2 &&
            e.posZ >= pos.z && e.posZ < pos.z + 1
    }

    private fun findBedInHotbar(): Int? {
        val inv = session.localPlayer.inventory
        for (i in 0 until 9) {
            val item = inv.content[i]
            val id = item.definition?.identifier ?: continue
            if ((id.contains("bed", ignoreCase = true) || id == "minecraft:item.bed") && item.count > 0) return i
        }
        if (debug) {
            val sb = StringBuilder("§7[BedAura] Hotbar: ")
            for (i in 0 until 9) {
                val item = inv.content[i]
                sb.append("[$i:${item.definition?.identifier ?: "null"} x${item.count}] ")
            }
            session.displayClientMessage(sb.toString())
        }
        return null
    }

    /** Cabecera de la cama: primero una celda valida (que no sea la del objetivo), si no una vacia. */
    private fun getHeadPos(bedPos: Vector3i, target: Entity): Vector3i {
        val targetCell = Vector3i.from(
            floor(target.posX).toInt(), floor(session.entityFeetY(target)).toInt(), floor(target.posZ).toInt()
        )
        for (dir in DIRS) {
            val p = bedPos.add(dir)
            if (p.x != targetCell.x || p.z != targetCell.z) {
                if (isBlockValid(p)) return p
            }
        }
        val airId = session.blockMapping.airId
        val world = session.kiwiWorld
        for (dir in DIRS) {
            val p = bedPos.add(dir)
            if (p.x != targetCell.x || p.z != targetCell.z) {
                if (world.isBlockKnown(p)) {
                    val rid = world.getBlockRuntimeId(p)
                    if (rid == airId || rid == 0) return p
                }
            }
        }
        return bedPos
    }

    private fun setYaw(bedPos: Vector3i, headPos: Vector3i) {
        val dx = headPos.x - bedPos.x
        val dz = headPos.z - bedPos.z
        realYaw = when {
            dx == 1 -> -90
            dx == -1 -> 90
            dz == -1 -> 180
            else -> 0
        }
    }

    private fun calculateDamage(bedPos: Vector3i, entity: Entity): Float =
        session.kiwiWorld.explosionDamageTo(
            Vector3f.from(bedPos.x + 0.5f, bedPos.y + 0.5f, bedPos.z + 0.5f), entity, 12f, false
        )

    private fun blockDefAt(pos: Vector3i): BlockDefinition? {
        session.kiwiWorld.knownDefinition(pos)?.let { return it }
        session.kiwiWorld.requestBlockData(pos)
        return session.blockMapping.definitionByIdentifier("minecraft:obsidian")
    }

    private fun dbg(message: String) {
        if (debug) session.displayClientMessage(message)
    }

    private companion object {
        val DIRS = listOf(Vector3i.from(1, 0, 0), Vector3i.from(-1, 0, 0), Vector3i.from(0, 0, 1), Vector3i.from(0, 0, -1))
        val REPLACEABLE: Set<String> = BlockPlacer.REPLACEABLE
    }
}
