package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.ModuleGuard
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.entity.Entity
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.kiwi.FriendManager
import com.retrivedmods.wclient.game.kiwi.ItemUseState
import com.retrivedmods.wclient.game.kiwi.entityFeetY
import com.retrivedmods.wclient.game.registry.BlockDefinition
import com.retrivedmods.wclient.game.registry.UnknownBlockDefinition
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.ItemUseTransaction
import org.cloudburstmc.protocol.bedrock.packet.ChangeDimensionPacket
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.MobEquipmentPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.packet.StartGamePacket
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sqrt

/**
 * AnchorAura portado de KiwiMods (game/module/combat/AnchorAuraModule).
 *
 * Genera posiciones para Respawn Anchors junto al objetivo (encima de su cabeza, o alrededor segun
 * "Pos Mode"), puntua cada una con la simulacion de explosion (dano al objetivo / dano propio) y
 * ejecuta el combo colocar -> cargar con glowstone -> detonar. Mantiene "anclas sombra" (lo que
 * creemos que hay colocado, aunque el servidor aun no lo haya confirmado) y una cola de detonaciones
 * pendientes. "Auto Exploit" detona tambien anclas cargadas que ya existan alrededor. En modo
 * "Build" construye un pilar de bloques junto al objetivo para tener donde apoyar el ancla.
 *
 * Notas del port (leelas antes de fiarte del comportamiento):
 *  - tryInstantCombo() de Kiwi NO se pudo decompilar (el decompilador fallo en ese metodo). Esta
 *    version es una RECONSTRUCCION a partir de los metodos que lo rodean (colocar, cargar, detonar,
 *    sombras, delays, "Steps per tick" y "Net cap"): cada llamada avanza un paso del combo
 *    (colocar -> cargar -> detonar) y la velocidad (Normal 3 / Fast 5 / Turbo 35 pasos por tick)
 *    decide cuantos pasos se dan por tick. El orden y los delays exactos de Kiwi pueden diferir.
 *  - Kiwi tambien colocaba el ancla con un clic directo sobre la celda vacia ("brute place", sin
 *    apoyo). Eso se salta la validacion de apoyo del servidor y NO se ha portado: aqui el ancla solo
 *    se coloca con un bloque de apoyo real; si no lo hay y "Support" esta activo, se coloca antes un
 *    bloque de apoyo (obsidiana, etc.) en la celda de debajo.
 *  - No se portan el overlay de render ni sus ajustes (Render, Dmg Text).
 */
class AnchorAuraModule : Module("anchor_aura", ModuleCategory.Combat) {

    private val modeName by stringValue("Mode", "Combo", listOf("Combo", "Build"))
    private val speedName by stringValue("Speed", "Normal", listOf("Normal", "Fast", "Turbo"))
    private val posMode by intValue("Pos Mode", 1, 1..3)
    private val placeRange by floatValue("Place Range", 6.0f, 1.0f..12.0f)
    private val proximity by intValue("Proximity", 3, 1..6)
    private val placeDelay by intValue("Place Delay", 0, 0..20)
    private val chargeDelay by intValue("Charge Delay", 0, 0..20)
    private val detonateDelay by intValue("Detonate Delay", 1, 0..20)
    private val targetRange by floatValue("Target Range", 12.0f, 1.0f..20.0f)
    private val minDamage by floatValue("Min Damage", 6.0f, 0.0f..36.0f)
    private val maxSelfDamage by floatValue("Max Self Damage", 12.0f, 0.0f..36.0f)
    private val headOnly by boolValue("Head Only", true)
    private val support by boolValue("Support", true)
    private val eatStop by boolValue("Eat Stop", true)
    private val safety by boolValue("Safety", true)
    private val autoExploit by boolValue("Auto Exploit", true)
    private val sameTick by boolValue("Same Tick", true)
    private val debug by boolValue("Debug", false)

    private class ShadowAnchor(val pos: Vector3i, var chargeLevel: Int, var lastChargeTick: Long, var placedTick: Long)
    private class PendingDet(val pos: Vector3i, val readyTick: Long)
    private class PlaceCandidate(val pos: Vector3i, val targetDamage: Float, val selfDamage: Float, val tier: Int)
    private class Spot(val pos: Vector3i, val group: Int, val score: Int, val existing: Boolean)

    private val shadowAnchors = ArrayList<ShadowAnchor>()
    private val pendingDets = ArrayList<PendingDet>()
    private val failedSpots = HashMap<Vector3i, Long>()
    private val detClicks = HashMap<Vector3i, Int>()
    private val anchors = ArrayList<PlaceCandidate>()
    private val pillarCellsBuilt = LinkedHashSet<Vector3i>()
    private val ownedSupport = HashMap<Vector3i, Long>()
    private val debugBuf = ArrayList<String>()

    private var currentTarget: Player? = null
    private var currentPos: Vector3i? = null
    private var lastTarget: Player? = null
    private var lastTargetGrace = 0
    private var lastActionTick = Long.MIN_VALUE
    private var lastProcessedTick = 0L
    private var actionsThisTick = 0
    private var nextActionTick = 0L
    private var nextPlaceTick = 0L
    private var buildGraceTicks = 0
    private var lastBuildCells: List<Vector3i> = emptyList()
    private var currentPillarDir: Vector3i? = null
    private var lastDebugTime = 0L
    private var anchorRidsCache: Set<Int> = emptySet()
    private var anchorRidsWorldVersion = -1L

    override fun onEnabled() {
        super.onEnabled()
        reset()
    }

    override fun onDisabled() {
        super.onDisabled()
        reset()
    }

    private fun reset() {
        currentTarget = null
        currentPos = null
        anchors.clear()
        nextActionTick = 0L
        nextPlaceTick = 0L
        lastTarget = null
        lastTargetGrace = 0
        lastActionTick = Long.MIN_VALUE
        debugBuf.clear()
        shadowAnchors.clear()
        pendingDets.clear()
        lastBuildCells = emptyList()
        currentPillarDir = null
        failedSpots.clear()
        pillarCellsBuilt.clear()
        ownedSupport.clear()
        detClicks.clear()
        actionsThisTick = 0
        lastProcessedTick = 0L
        buildGraceTicks = 0
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        when (val packet = interceptablePacket.packet) {
            is StartGamePacket, is ChangeDimensionPacket -> reset() // equivale a onWorldChange de Kiwi
            is PlayerAuthInputPacket -> {
                val tick = packet.tick
                if (tick == lastActionTick) return
                lastActionTick = tick
                if (tick != lastProcessedTick) {
                    lastProcessedTick = tick
                    actionsThisTick = 0
                }
                try {
                    onTick(packet)
                } catch (t: Throwable) {
                    dbg("CRASH: ${t.javaClass.simpleName}: ${t.message}")
                    ModuleGuard.reportError("anchor_aura", t)
                    // Limpiar estado a medias para no arrastrar secuencias incompletas al siguiente tick.
                    pendingDets.clear()
                    detClicks.clear()
                    currentPillarDir = null
                    actionsThisTick = 0
                }
                flushDebug()
            }
        }
    }

    // ------------------------------------------------------------------ velocidad

    private fun netCapPerTick() = when (speedName) {
        "Fast" -> 20
        "Turbo" -> 80
        else -> 15
    }

    private fun stepsPerTick() = when (speedName) {
        "Fast" -> 5
        "Turbo" -> 35
        else -> 3
    }

    // ------------------------------------------------------------------ tick

    private var cachedCandidate: PlaceCandidate? = null
    private var cachedCandidateTarget: Player? = null
    private var cachedCandidateBlockVer = -1L
    private var cachedCandidateTick = -100L

    private fun onTick(input: PlayerAuthInputPacket) {
        val lp = session.localPlayer
        if (eatStop && ItemUseState.using) return

        reconcileShadows()
        if (autoExploit && lastProcessedTick % 2L == 0L) scanExistingAnchors(lp)
        processPendingDets(lp, input)

        val candidates = session.level.entityMap.values
            .filterIsInstance<Player>()
            .filter {
                it !== lp && it.uniqueEntityId != lp.uniqueEntityId && !isBot(it) &&
                    !FriendManager.isFriend(it.uuid) && it.distance(lp) <= targetRange &&
                    !FakePlayerModule.isFake(it.uniqueEntityId)
            }
        if (candidates.isEmpty()) {
            currentTarget = null
            currentPos = null
            lastTarget = null
            lastTargetGrace = 0
            dbg("NO TARGET within $targetRange")
            return
        }

        var target = candidates.minByOrNull { it.distanceSq(lp) }!!
        val last = lastTarget
        if (lastTargetGrace > 0 && last != null && candidates.contains(last)) target = last
        if (target !== lastTarget) {
            lastTarget = target
            lastTargetGrace = 8
            failedSpots.clear()
            pillarCellsBuilt.clear()
            ownedSupport.clear()
            detClicks.clear()
        } else if (lastTargetGrace > 0) {
            lastTargetGrace--
        }
        currentTarget = target

        if (modeName == "Build" && tryBuildPillar(lp, input, target)) return
        // Antes se recalculaban TODOS los candidatos en cada tick y solo se usaba el primero.
        // Ahora se reutiliza el resultado mientras el objetivo, el mundo y el tick no cambien
        // (o cada 2 ticks como maximo).
        val blockVer = session.kiwiWorld.blockVersion
        if (cachedCandidateTarget !== target || cachedCandidateBlockVer != blockVer ||
            input.tick - cachedCandidateTick >= 2
        ) {
            cachedCandidate = generatePlacements(lp, target).firstOrNull()
            cachedCandidateTarget = target
            cachedCandidateBlockVer = blockVer
            cachedCandidateTick = input.tick
        }
        val candidate = cachedCandidate ?: return

        var acted = false
        repeat(stepsPerTick()) {
            if (actionsThisTick < netCapPerTick() && tryInstantCombo(candidate.pos, lp, input)) acted = true
        }
        if (acted) currentPos = candidate.pos
    }

    /** Cada 2 ticks: anclas cargadas (o de carga desconocida) ya existentes alrededor -> detonacion pendiente. */
    private fun scanExistingAnchors(lp: LocalPlayer) {
        val r = placeRange.toInt()
        val px = floor(lp.posX).toInt()
        val pz = floor(lp.posZ).toInt()
        val py = floor(session.entityFeetY(lp)).toInt()
        val rids = resolveAnchorRids()
        val world = session.kiwiWorld
        val tick = lastProcessedTick
        for (x in px - r..px + r) for (z in pz - r..pz + r) for (y in py - r..py + r) {
            val pos = Vector3i.from(x, y, z)
            if (!world.isBlockKnown(pos)) continue
            val rid = world.getBlockRuntimeId(pos)
            if (rid == 0 || rid !in rids) continue
            if (pendingDets.any { it.pos == pos }) continue
            if (existingAnchorCharge(pos) == 0) continue // sin carga conocida: no hay nada que detonar
            addPendingDet(pos, max(detonateDelay, 1).toLong() + tick)
        }
    }

    // ------------------------------------------------------------------ sombras y detonaciones

    private fun reconcileShadows() {
        if (shadowAnchors.isEmpty() && pendingDets.isEmpty()) return
        val rids = resolveAnchorRids()
        if (rids.isEmpty()) return
        val world = session.kiwiWorld
        val airId = session.blockMapping.airId

        val it = shadowAnchors.iterator()
        while (it.hasNext()) {
            val s = it.next()
            if (!world.isBlockKnown(s.pos) || lastProcessedTick - s.placedTick < 3) continue
            val rid = world.getBlockRuntimeId(s.pos)
            val gone = rid == airId || rid == 0 || (rid !in rids && !knownAnchorIdentifier(s.pos))
            if (!gone) continue
            it.remove()
            pendingDets.removeAll { d -> d.pos == s.pos }
            if (currentPos == s.pos) currentPos = null
            failedSpots[s.pos] = lastProcessedTick
            dbg("RECONCILE cleaned ${fmtBlock(s.pos)} (gone/ghost)")
        }

        val it2 = pendingDets.iterator()
        while (it2.hasNext()) {
            val d = it2.next()
            if (!world.isBlockKnown(d.pos)) continue
            val rid = world.getBlockRuntimeId(d.pos)
            if (rid != airId && rid != 0 && rid !in rids && !knownAnchorIdentifier(d.pos)) {
                it2.remove()
                dbg("RECONCILE stale pending-det removed @${fmtBlock(d.pos)}")
            }
        }
    }

    private fun processPendingDets(player: LocalPlayer, input: PlayerAuthInputPacket) {
        val tick = lastProcessedTick
        val it = pendingDets.iterator()
        while (it.hasNext()) {
            val det = it.next()
            if (tick < det.readyTick || tick < nextActionTick || actionsThisTick >= netCapPerTick()) continue

            if (!blockIsAnchor(det.pos)) {
                dbg("DET ${fmtBlock(det.pos)} block gone - skip")
                shadowAnchors.removeAll { s -> s.pos == det.pos }
                it.remove()
                continue
            }
            if (session.kiwiWorld.isBlockKnown(det.pos) && existingAnchorCharge(det.pos) == 0) {
                shadowFind(det.pos)?.chargeLevel = 0
                it.remove()
                dbg("DET ${fmtBlock(det.pos)} NOT charged - re-charge")
                continue
            }
            val clicks = detClicks[det.pos] ?: 0
            if (clicks >= 8) {
                detClicks.remove(det.pos)
                failedSpots[det.pos] = tick
                it.remove()
                dbg("DET ${fmtBlock(det.pos)} blind-click capped - veto+replace")
                continue
            }
            val anchorSlot = findItemSlot("anchor")
            if (anchorSlot == null) {
                dbg("  skip: no anchor in hotbar")
                it.remove()
                continue
            }
            val ok = if (anchorSlot == player.inventory.heldItemSlot) {
                tryDetonateAnchor(det.pos, player, input)
            } else {
                swapAct(anchorSlot, player) { tryDetonateAnchor(det.pos, player, input) }
            }
            if (ok) {
                actionsThisTick++
                nextActionTick = tick + 1
                it.remove()
                detClicks[det.pos] = clicks + 1
                shadowAnchors.removeAll { s -> s.pos == det.pos }
                dbg("  OK det click @${fmtBlock(det.pos)}")
                log("Det click at ${det.pos}")
            } else {
                dbg("  FAIL: detonate packet rejected")
            }
        }
    }

    // ------------------------------------------------------------------ combo (reconstruido)

    /**
     * Un paso del combo sobre [pos]: colocar -> cargar -> detonar. Devuelve true si hizo algo.
     * RECONSTRUIDO: el original de Kiwi no se pudo decompilar (ver cabecera de la clase).
     */
    private fun tryInstantCombo(pos: Vector3i, player: LocalPlayer, input: PlayerAuthInputPacket): Boolean {
        val tick = lastProcessedTick
        val shadow = shadowFind(pos)
        val worldAnchor = blockIsAnchor(pos)

        // 1) Colocar
        if (!worldAnchor) {
            if (tick < nextPlaceTick) return false
            val anchorSlot = findItemSlot("anchor")
            if (anchorSlot == null) {
                dbg("  skip: no anchor item in hotbar")
                return false
            }
            if (findSupportCell(pos) == null) {
                if (!support) {
                    dbg("  no support block next to ${fmtBlock(pos)} and Support is off")
                    return false
                }
                return placeSupportFor(pos, player, input)
            }
            val placed = swapAct(anchorSlot, player) { tryPlaceAnchor(pos, player, anchorSlot, input) }
            if (!placed) {
                dbg("  FAIL: place packet path returned false")
                failedSpots[pos] = tick
                return false
            }
            shadowMarkPlaced(pos, tick)
            actionsThisTick++
            nextPlaceTick = tick + placeDelay
            dbg("  PLACED anchor @${fmtBlock(pos)}")
            return true
        }

        // 2) Cargar con glowstone
        val charge = shadow?.chargeLevel ?: max(existingAnchorCharge(pos), 0)
        if (charge < 1) {
            if (shadow != null && tick - shadow.placedTick < chargeDelay) return false
            val glowSlot = findItemSlot("glowstone")
            if (glowSlot == null) {
                dbg("  skip: no glowstone in hotbar")
                return false
            }
            val charged = swapAct(glowSlot, player) { tryChargeAnchor(pos, player, glowSlot, input) }
            if (!charged) return false
            shadowBumpCharge(pos, tick)
            actionsThisTick++
            dbg("  CHARGED anchor @${fmtBlock(pos)}")
            return true
        }

        // 3) Detonar (en este tick con "Same Tick", o tras "Detonate Delay")
        if (pendingDets.any { it.pos == pos }) return false
        val ready = if (sameTick) tick else tick + max(detonateDelay, 1)
        addPendingDet(pos, ready)
        if (sameTick) processPendingDets(player, input)
        return true
    }

    /** Coloca un bloque de apoyo en la celda de debajo de [pos] para poder apoyar luego el ancla. */
    private fun placeSupportFor(pos: Vector3i, player: LocalPlayer, input: PlayerAuthInputPacket): Boolean {
        val slot = findPillarBlock() ?: run {
            dbg("  no support block in hotbar")
            return false
        }
        val below = Vector3i.from(pos.x, pos.y - 1, pos.z)
        val ok = swapAct(slot, player) { tryPlaceBlock(below, player, slot, "minecraft:obsidian", input) }
        if (ok) {
            ownedSupport[below] = lastProcessedTick + OWNED_SUPPORT_TICKS
            actionsThisTick++
        }
        return ok
    }

    // ------------------------------------------------------------------ candidatos

    private fun generatePlacements(player: LocalPlayer, target: Player): List<PlaceCandidate> {
        val world = session.kiwiWorld
        val airId = session.blockMapping.airId
        val tx = floor(target.posX).toInt()
        val tz = floor(target.posZ).toInt()
        val feetY = session.entityFeetY(target)
        val ty = floor(feetY).toInt()
        val baseY = ty - 1
        val playerFeet = session.entityFeetY(player)
        val headY = ty + 2

        val headCell = Vector3i.from(tx, headY, tz)
        val headRid = if (world.isBlockKnown(headCell)) world.getBlockRuntimeId(headCell) else 0
        val headBlocked = !(headRid == 0 || headRid == airId || headRid in resolveAnchorRids() || knownAnchorIdentifier(headCell))

        val group0: List<Pair<Vector3i, Int>> =
            if (!headBlocked) listOf(headCell to 1000)
            else listOf(
                Vector3i.from(tx + 1, headY, tz) to 990, Vector3i.from(tx - 1, headY, tz) to 990,
                Vector3i.from(tx, headY, tz + 1) to 990, Vector3i.from(tx, headY, tz - 1) to 990
            )
        val group1 = listOf(
            Vector3i.from(tx + 1, ty, tz) to 900, Vector3i.from(tx - 1, ty, tz) to 900,
            Vector3i.from(tx, ty, tz + 1) to 900, Vector3i.from(tx, ty, tz - 1) to 900
        )
        val group2 = listOf(
            Vector3i.from(tx + 1, baseY, tz) to 800, Vector3i.from(tx - 1, baseY, tz) to 800,
            Vector3i.from(tx, baseY, tz + 1) to 800, Vector3i.from(tx, baseY, tz - 1) to 800
        )
        val groups = when (posMode) {
            1 -> listOf(group0)
            2 -> listOf(group0, group1)
            else -> listOf(group0, group1, group2)
        }

        val spots = ArrayList<Spot>()
        val prox2 = (proximity * proximity).toFloat()

        // Revivir anclas sombra sin cargar cercanas al objetivo.
        for (s in shadowAnchors) {
            val failed = failedSpots[s.pos]
            if (s.chargeLevel < 1 && (failed == null || lastProcessedTick - failed >= FAILED_SPOT_TTL)) {
                val dx = s.pos.x + 0.5f - target.posX
                val dy = s.pos.y + 0.5f - target.posY
                val dz = s.pos.z + 0.5f - target.posZ
                if (dx * dx + dy * dy + dz * dz <= prox2) spots.add(Spot(s.pos, 99, 1000000, true))
            }
        }

        for ((gi, group) in groups.withIndex()) {
            for ((pos, prio) in group) {
                if (pos.y > headY) continue
                if (overlapsPlayerHitbox(pos, player, playerFeet)) continue
                if (!world.isBlockKnown(pos)) {
                    world.requestBlockData(pos)
                    continue
                }
                val dx = pos.x + 0.5f - player.posX
                val dy = pos.y + 0.5f - playerFeet
                val dz = pos.z + 0.5f - player.posZ
                if (sqrt(dx * dx + dy * dy + dz * dz) > placeRange + 0.75f) continue

                val rid = world.getBlockRuntimeId(pos)
                if (rid in resolveAnchorRids() || knownAnchorIdentifier(pos)) {
                    spots.add(Spot(pos, gi, 1000000, true))
                    continue
                }
                val failed = failedSpots[pos]
                if (failed != null && lastProcessedTick - failed < FAILED_SPOT_TTL) continue
                if (rid == airId || rid == 0) spots.add(Spot(pos, gi, prio, false))
            }
        }

        // Sin duplicados (se queda el primero), mejor puntuacion primero y a igualdad mas dano al objetivo.
        val seen = HashSet<Vector3i>()
        val unique = spots.filter { seen.add(it.pos) }.toMutableList()
        val damages = HashMap<Vector3i, Pair<Float, Float>>()
        fun dmg(pos: Vector3i) = damages.getOrPut(pos) { calcDamage(pos, target) to calcDamage(pos, player) }
        unique.sortWith(compareByDescending<Spot> { it.score }.thenByDescending { dmg(it.pos).first })

        val result = ArrayList<PlaceCandidate>()
        var safest: PlaceCandidate? = null
        for (spot in unique) {
            val (targetDamage, selfDamage) = dmg(spot.pos)
            if (safety && selfDamage > maxSelfDamage) {
                val c = PlaceCandidate(spot.pos, targetDamage, selfDamage, spot.score)
                if (safest == null || c.selfDamage < safest.selfDamage) safest = c
            } else if (spot.existing || !headOnly) {
                result.add(PlaceCandidate(spot.pos, targetDamage, selfDamage, spot.score))
            } else if (spot.score >= 550) {
                result.add(PlaceCandidate(spot.pos, targetDamage, selfDamage, spot.score))
            }
        }
        if (result.isEmpty() && safest != null) {
            result.add(safest)
            dbg("  SAFETY OVERRIDDEN at ${fmtBlock(safest.pos)} sDmg=${"%.1f".format(safest.selfDamage)} (no safe spot)")
        }
        // Los que no llegan a "Min Damage" quedan al final; entre iguales, mas dano al objetivo primero.
        result.sortWith(
            compareByDescending<PlaceCandidate> { if (it.targetDamage >= minDamage) it.tier else -1 }
                .thenByDescending { it.targetDamage }
        )
        anchors.clear()
        anchors.addAll(result)
        dbg("  cands=${result.size}")
        return result
    }

    private fun calcDamage(pos: Vector3i, entity: Entity): Float = try {
        session.kiwiWorld.explosionDamageTo(
            Vector3f.from(pos.x + 0.5f, pos.y + 0.5f, pos.z + 0.5f), entity, 12f, false
        )
    } catch (e: Exception) {
        dbg("CRASH dmg calc: ${e.javaClass.simpleName}: ${e.message}")
        0f
    }

    private fun overlapsPlayerHitbox(pos: Vector3i, player: LocalPlayer, feetY: Float): Boolean {
        val minX = player.posX - 0.35f
        val maxX = player.posX + 0.35f
        val minZ = player.posZ - 0.35f
        val maxZ = player.posZ + 0.35f
        return pos.x < maxX && pos.x + 1f > minX &&
            pos.y < feetY + 1.9f && pos.y + 1f > feetY &&
            pos.z < maxZ && pos.z + 1f > minZ
    }

    // ------------------------------------------------------------------ pilar (modo Build)

    private fun tryBuildPillar(player: LocalPlayer, input: PlayerAuthInputPacket, target: Player): Boolean {
        pillarCellsBuilt.removeAll { cell -> isAirKnown(cell) }
        if (hasExistingSupport(target)) {
            lastBuildCells = emptyList()
            dbg("BUILD skip - existing support found")
            return false
        }
        val cells = planPillar(target).filter { it !in pillarCellsBuilt }
        lastBuildCells = cells
        if (cells.isEmpty()) return false

        if (cells.any { !session.kiwiWorld.isBlockKnown(it) }) {
            buildGraceTicks++
            if (buildGraceTicks < BUILD_GRACE_TICKS) {
                dbg("BUILD grace $buildGraceTicks/$BUILD_GRACE_TICKS waiting chunk data")
                return true
            }
        }
        buildGraceTicks = 0

        val tick = lastProcessedTick
        if (tick < nextActionTick) {
            dbg("BUILD wait cooldown tick=$tick<$nextActionTick")
            return true
        }
        if (actionsThisTick >= netCapPerTick()) return true

        val slot = findPillarBlock()
        if (slot == null) {
            dbg("BUILD no block in hotbar")
            return false
        }
        val cell = cells.first()
        if (swapAct(slot, player) { tryPlaceBlock(cell, player, slot, "minecraft:obsidian", input) }) {
            pillarCellsBuilt.add(cell)
            ownedSupport[cell] = tick + OWNED_SUPPORT_TICKS
            nextActionTick = tick + 1 + placeDelay
            actionsThisTick++
            dbg("BUILD placed pillar at ${fmtBlock(cell)} (${cells.size} left)")
            log("Pillar at $cell (${cells.size} left)")
        }
        return true
    }

    private fun planPillar(target: Player): List<Vector3i> {
        val world = session.kiwiWorld
        val lp = session.localPlayer
        val tx = floor(target.posX).toInt()
        val tz = floor(target.posZ).toInt()
        val ty = floor(session.entityFeetY(target)).toInt()
        val baseY = ty - 1
        val cx = tx + 0.5f
        val cz = tz + 0.5f

        var dirs = listOf(
            Vector3i.from(1, 0, 0) to (lp.posX - cx),
            Vector3i.from(-1, 0, 0) to (cx - lp.posX),
            Vector3i.from(0, 0, 1) to (lp.posZ - cz),
            Vector3i.from(0, 0, -1) to (cz - lp.posZ)
        ).sortedBy { it.second }
        val keep = currentPillarDir
        if (keep != null && dirs.any { it.first == keep }) dirs = dirs.sortedBy { it.first != keep }

        for ((dir, _) in dirs) {
            val x = dir.x + tx
            val z = dir.z + tz
            // Baja desde la base hasta el primer bloque solido (maximo 8 por debajo).
            var y = baseY
            var unknownBelow = false
            while (y > ty - 8) {
                val p = Vector3i.from(x, y, z)
                if (world.isBlockKnown(p)) {
                    val rid = world.getBlockRuntimeId(p)
                    if (rid != session.blockMapping.airId && rid != 0) break
                } else {
                    world.requestBlockData(p)
                    unknownBelow = true
                }
                y--
            }
            val start = y + 1
            val end = max(ty + 2, start)
            val cells = (start..end).map { Vector3i.from(x, it, z) }
            if (cells.isEmpty()) continue
            if (cells.any { isAirKnown(it) && !clearOfEnt(it) }) continue // un jugador/entidad ocupa la columna

            currentPillarDir = dir
            val anyUnknown = unknownBelow || cells.any { !world.isBlockKnown(it) }
            if (anyUnknown) {
                // Datos aun sin cargar: se devuelve una sola celda para esperar al chunk.
                return listOf(cells.firstOrNull { !world.isBlockKnown(it) } ?: cells.first())
            }
            return cells.filter { isAirKnown(it) }
        }
        val head = Vector3i.from(tx, ty + 2, tz)
        return if (isAirKnown(head) && clearOfEnt(head)) listOf(head) else emptyList()
    }

    private fun isAirKnown(pos: Vector3i): Boolean {
        val world = session.kiwiWorld
        if (!world.isBlockKnown(pos)) {
            world.requestBlockData(pos)
            return false
        }
        val rid = world.getBlockRuntimeId(pos)
        return rid == session.blockMapping.airId || rid == 0
    }

    private fun clearOfEnt(pos: Vector3i): Boolean {
        for (e in session.level.entityMap.values) {
            val ex = floor(e.posX).toInt()
            val ez = floor(e.posZ).toInt()
            val ey = floor(session.entityFeetY(e)).toInt()
            if (ex == pos.x && ez == pos.z && (ey == pos.y || ey + 1 == pos.y)) return false
        }
        return true
    }

    private fun hasExistingSupport(target: Player): Boolean {
        val world = session.kiwiWorld
        val tx = floor(target.posX).toInt()
        val tz = floor(target.posZ).toInt()
        val base = floor(session.entityFeetY(target)).toInt() - 1
        val offsets = when (posMode) {
            1 -> listOf(3)
            2 -> listOf(3, 1)
            else -> listOf(3, 2, 1, 0)
        }
        val airId = session.blockMapping.airId
        for (o in offsets) {
            val pos = Vector3i.from(tx, base + o, tz)
            val failed = failedSpots[pos]
            if (failed != null && lastProcessedTick - failed < FAILED_SPOT_TTL) continue
            if (!world.isBlockKnown(pos)) {
                world.requestBlockData(pos)
                continue
            }
            val rid = world.getBlockRuntimeId(pos)
            if (rid in resolveAnchorRids()) return true
            if ((rid == airId || rid == 0) && findSupportCell(pos) != null) return true
        }
        return false
    }

    private fun findPillarBlock(): Int? {
        for (k in listOf("obsidian", "netherite_block", "concrete", "stone", "wool")) {
            findItemSlot(k)?.let { return it }
        }
        return null
    }

    // ------------------------------------------------------------------ colocacion / clics

    private fun tryPlaceAnchor(pos: Vector3i, player: LocalPlayer, slot: Int, input: PlayerAuthInputPacket): Boolean =
        tryPlaceBlock(pos, player, slot, "minecraft:respawn_anchor", input)

    private fun tryPlaceBlock(
        pos: Vector3i, player: LocalPlayer, slot: Int, identifier: String, input: PlayerAuthInputPacket
    ): Boolean {
        val supportCell = findSupportCell(pos) ?: return false
        val face = faceFromSupportToPos(supportCell, pos)
        aimAtClick(supportCell, face, player, input)
        session.serverBound(InventoryTransactionPacket().apply {
            transactionType = InventoryTransactionType.ITEM_USE
            actionType = 0
            blockPosition = supportCell
            blockFace = face
            hotbarSlot = slot
            itemInHand = player.inventory.content[slot]
            playerPosition = player.vec3Position
            clickPosition = clickPosForFace(face)
            blockDefinition = supportDefAt(supportCell)
            triggerType = ItemUseTransaction.TriggerType.PLAYER_INPUT
            clientInteractPrediction = ItemUseTransaction.PredictedResult.SUCCESS
        })
        player.swing()
        session.kiwiWorld.registerPlacement(pos, identifier)
        return true
    }

    private fun tryChargeAnchor(pos: Vector3i, player: LocalPlayer, slot: Int, input: PlayerAuthInputPacket): Boolean {
        val face = getBlockFace(pos, player)
        aimAtClick(pos, face, player, input)
        session.serverBound(InventoryTransactionPacket().apply {
            transactionType = InventoryTransactionType.ITEM_USE
            actionType = 0
            blockPosition = pos
            blockFace = face
            hotbarSlot = slot
            itemInHand = player.inventory.content[slot]
            playerPosition = player.vec3Position
            clickPosition = clickPosForFace(face)
            blockDefinition = anchorDefAt(pos)
            triggerType = ItemUseTransaction.TriggerType.PLAYER_INPUT
            clientInteractPrediction = ItemUseTransaction.PredictedResult.SUCCESS
        })
        player.swing()
        return true
    }

    private fun tryDetonateAnchor(pos: Vector3i, player: LocalPlayer, input: PlayerAuthInputPacket): Boolean {
        aimAtClick(pos, 1, player, input)
        val hand = player.inventory.hand
        session.serverBound(InventoryTransactionPacket().apply {
            transactionType = InventoryTransactionType.ITEM_USE
            actionType = 0
            blockPosition = pos
            blockFace = 1
            hotbarSlot = player.inventory.heldItemSlot
            itemInHand = hand
            playerPosition = player.vec3Position
            clickPosition = Vector3f.from(0.5f, 0.98f, 0.5f)
            blockDefinition = anchorDefAt(pos)
            triggerType = ItemUseTransaction.TriggerType.PLAYER_INPUT
            clientInteractPrediction = ItemUseTransaction.PredictedResult.SUCCESS
        })
        player.swing()
        return true
    }

    /** Cambia a [wantSlot], ejecuta [action] y vuelve a la ranura original (solo cambios de ranura al servidor). */
    private fun swapAct(wantSlot: Int, player: LocalPlayer, action: () -> Boolean): Boolean {
        val held = player.inventory.heldItemSlot
        val swap = wantSlot != held
        if (swap) {
            val item = player.inventory.content.getOrNull(wantSlot) ?: return false
            player.inventory.heldItemSlot = wantSlot
            session.serverBound(MobEquipmentPacket().apply {
                runtimeEntityId = player.runtimeEntityId
                this.item = item
                inventorySlot = wantSlot
                hotbarSlot = wantSlot
            })
        }
        val result = action()
        if (swap) {
            val back = player.inventory.content.getOrNull(held) ?: player.inventory.content.getOrNull(wantSlot)
            player.inventory.heldItemSlot = held
            if (back != null) {
                session.serverBound(MobEquipmentPacket().apply {
                    runtimeEntityId = player.runtimeEntityId
                    this.item = back
                    inventorySlot = held
                    hotbarSlot = held
                })
            }
        }
        return result
    }

    private fun aimAtClick(pos: Vector3i, face: Int, player: LocalPlayer, input: PlayerAuthInputPacket) {
        val click = clickPosForFace(face)
        val eyeY = session.entityFeetY(player) + 1.62f
        val x = pos.x + click.x - player.posX
        val y = pos.y + click.y - eyeY
        val z = pos.z + click.z - player.posZ
        val yaw = (Math.toDegrees(atan2(z, x).toDouble()) - 90.0).toFloat()
        val pitch = (-Math.toDegrees(atan2(y, sqrt(x * x + z * z)).toDouble())).toFloat()
        input.rotation = Vector3f.from(pitch, yaw, yaw)
    }

    private fun getBlockFace(pos: Vector3i, player: LocalPlayer): Int {
        val eyeY = session.entityFeetY(player) + 1.62f
        val dx = player.posX - (pos.x + 0.5f)
        val dy = eyeY - (pos.y + 0.5f)
        val dz = player.posZ - (pos.z + 0.5f)
        val ax = abs(dx)
        val ay = abs(dy)
        val az = abs(dz)
        if (ay >= ax && ay >= az) return if (dy > 0f) 1 else 0
        if (ax >= az) return if (dx > 0f) 5 else 4
        return if (dz > 0f) 3 else 2
    }

    private fun faceFromSupportToPos(support: Vector3i, pos: Vector3i): Int = when {
        pos.y > support.y -> 1
        pos.y < support.y -> 0
        pos.x > support.x -> 5
        pos.x < support.x -> 4
        pos.z > support.z -> 3
        else -> 2
    }

    private fun clickPosForFace(face: Int): Vector3f = when (face) {
        0 -> Vector3f.from(0.5f, 0.0f, 0.5f)
        1 -> Vector3f.from(0.5f, 1.0f, 0.5f)
        2 -> Vector3f.from(0.5f, 0.62f, 0.0f)
        3 -> Vector3f.from(0.5f, 0.62f, 1.0f)
        4 -> Vector3f.from(0.0f, 0.62f, 0.5f)
        else -> Vector3f.from(1.0f, 0.62f, 0.5f)
    }

    /** Bloque contiguo donde apoyarse: primero los que hemos puesto nosotros, luego cualquiera solido. */
    private fun findSupportCell(pos: Vector3i): Vector3i? {
        val world = session.kiwiWorld
        val airId = session.blockMapping.airId
        val neighbors = listOf(
            Vector3i.from(pos.x, pos.y - 1, pos.z), Vector3i.from(pos.x + 1, pos.y, pos.z),
            Vector3i.from(pos.x - 1, pos.y, pos.z), Vector3i.from(pos.x, pos.y, pos.z + 1),
            Vector3i.from(pos.x, pos.y, pos.z - 1), Vector3i.from(pos.x, pos.y + 1, pos.z)
        )
        val tick = lastProcessedTick
        for (n in neighbors) {
            val until = ownedSupport[n] ?: continue
            if (until < tick) {
                ownedSupport.remove(n)
            } else if (!world.isBlockKnown(n) || world.getBlockRuntimeId(n).let { it != airId && it != 0 }) {
                return n
            } else {
                ownedSupport.remove(n)
            }
        }
        var requested = false
        for (n in neighbors) {
            if (world.isBlockKnown(n)) {
                val rid = world.getBlockRuntimeId(n)
                if (rid != airId && rid != 0) return n
            } else if (!requested) {
                world.requestBlockData(n)
                requested = true
            }
        }
        return null
    }

    // ------------------------------------------------------------------ sombras y utilidades

    private fun shadowFind(pos: Vector3i): ShadowAnchor? = shadowAnchors.firstOrNull { it.pos == pos }

    private fun shadowMarkPlaced(pos: Vector3i, tick: Long) {
        val existing = shadowFind(pos)
        if (existing != null) {
            existing.placedTick = tick
            existing.chargeLevel = 0
            return
        }
        if (shadowAnchors.size >= SHADOW_CAP) {
            val oldest = shadowAnchors.minByOrNull { it.placedTick }
            if (oldest != null) {
                shadowAnchors.remove(oldest)
                pendingDets.removeAll { it.pos == oldest.pos }
            }
        }
        shadowAnchors.add(ShadowAnchor(pos, 0, tick, 0L).also { it.placedTick = tick })
    }

    private fun shadowBumpCharge(pos: Vector3i, tick: Long) {
        shadowFind(pos)?.let {
            it.chargeLevel = (it.chargeLevel + 1).coerceAtMost(4)
            it.lastChargeTick = tick
        }
    }

    private fun addPendingDet(pos: Vector3i, readyTick: Long) {
        if (pendingDets.any { it.pos == pos }) return
        if (pendingDets.size >= DET_CAP) {
            pendingDets.minByOrNull { it.readyTick }?.let { pendingDets.remove(it) }
        }
        pendingDets.add(PendingDet(pos, readyTick))
    }

    private fun blockIsAnchor(pos: Vector3i): Boolean {
        if (shadowFind(pos) != null) return true
        val world = session.kiwiWorld
        if (world.isBlockKnown(pos)) {
            val rid = world.getBlockRuntimeId(pos)
            if (rid != 0) return rid in resolveAnchorRids() || knownAnchorIdentifier(pos)
        }
        return false
    }

    private fun knownAnchorIdentifier(pos: Vector3i): Boolean =
        session.kiwiWorld.knownDefinition(pos)?.identifier == "minecraft:respawn_anchor"

    /** Carga del ancla segun el estado del bloque; -1 si no se puede saber. */
    private fun existingAnchorCharge(pos: Vector3i): Int = try {
        val states = session.blockMapping.getDefinition(session.kiwiWorld.getBlockRuntimeId(pos)).states
        if (!states.isEmpty() && states.containsKey("respawn_anchor_charge")) states.getInt("respawn_anchor_charge") else -1
    } catch (_: Exception) {
        -1
    }

    private fun resolveAnchorRids(): Set<Int> {
        val version = session.kiwiWorld.worldVersion
        if (anchorRidsCache.isEmpty() || anchorRidsWorldVersion != version) {
            anchorRidsCache = session.blockMapping.runtimeIdsByIdentifier("minecraft:respawn_anchor")
            anchorRidsWorldVersion = version
        }
        return anchorRidsCache
    }

    private fun supportDefAt(pos: Vector3i): BlockDefinition = try {
        session.kiwiWorld.knownDefinition(pos)
            ?: session.blockMapping.definitionByIdentifier("minecraft:obsidian")
            ?: UnknownBlockDefinition(0)
    } catch (_: Exception) {
        UnknownBlockDefinition(0)
    }

    private fun anchorDefAt(pos: Vector3i): BlockDefinition = try {
        session.kiwiWorld.knownDefinition(pos)
            ?: session.blockMapping.definitionByIdentifier("minecraft:respawn_anchor")
            ?: UnknownBlockDefinition(0)
    } catch (_: Exception) {
        UnknownBlockDefinition(0)
    }

    private fun findItemSlot(keyword: String): Int? {
        val inv = session.localPlayer.inventory
        for (i in 0 until 9) {
            val item = inv.content[i]
            val id = item.definition?.identifier ?: continue
            if (id.contains(keyword, ignoreCase = true) && item.count > 0) return i
        }
        return null
    }

    // Igual que Kiwi: aqui "bot" es solo una entrada de la lista de jugadores con nombre en blanco.
    private fun isBot(player: Player): Boolean {
        if (player is LocalPlayer) return false
        val entry = session.level.playerMap[player.uuid] ?: return false
        return entry.name?.toString().isNullOrBlank()
    }

    private fun fmtBlock(pos: Vector3i) = "${pos.x} ${pos.y} ${pos.z}"

    private fun dbg(msg: String) {
        if (debug && debugBuf.size < 24) debugBuf.add(msg)
    }

    private fun flushDebug() {
        if (debugBuf.isEmpty()) return
        val now = System.currentTimeMillis()
        if (now - lastDebugTime < 800) return
        lastDebugTime = now
        for (m in debugBuf.take(6)) session.displayClientMessage("§e[Anchor] §f$m")
        debugBuf.clear()
    }

    private fun log(message: String) {
        if (!debug) return
        val now = System.currentTimeMillis()
        if (now - lastDebugTime < 1000) return
        session.displayClientMessage("[Anchor] $message")
        lastDebugTime = now
    }

    private companion object {
        const val SHADOW_CAP = 16
        const val DET_CAP = 16
        const val FAILED_SPOT_TTL = 1L
        const val BUILD_GRACE_TICKS = 1
        const val OWNED_SUPPORT_TICKS = 8L
    }
}
