package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.kiwi.ItemUseState
import com.retrivedmods.wclient.game.kiwi.adaptiveFeetY
import com.retrivedmods.wclient.game.registry.BlockDefinition
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.ItemUseTransaction
import org.cloudburstmc.protocol.bedrock.packet.ChangeDimensionPacket
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.MobEquipmentPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerHotbarPacket
import org.cloudburstmc.protocol.bedrock.packet.StartGamePacket
import kotlin.math.abs
import kotlin.math.floor

/**
 * AnchorHelper portado de KiwiMods (game/module/combat/AnchorHelperModule).
 *
 * Escanea los Respawn Anchor dentro de "Range" y los va usando por cola: si el ancla esta sin
 * carga cambia a glowstone para cargarla; si ya tiene carga hace clic con un item que no sea
 * glowstone (la explota). "Clicks Per Tick" limita cuantas anclas se tocan por tick y "Delay"
 * es la pausa entre rondas. Con "Eat Stop" se pausa mientras usas un item.
 */
class AnchorHelperModule : Module("anchor_helper", ModuleCategory.Combat) {

    private val range by intValue("Range", 5, 1..12)
    private val delay by intValue("Delay", 2, 0..40)
    private val eatStop by boolValue("Eat Stop", true)
    private val clicksPerTick by intValue("Clicks Per Tick", 3, 1..8)

    private val queue = ArrayDeque<Vector3i>()
    private var tickCooldown = 0
    private var anchorRidsCache: Set<Int> = emptySet()
    private var anchorRidsWorldVersion = -1L

    override fun onEnabled() {
        super.onEnabled()
        reset()
    }

    override fun onDisabled() {
        super.onDisabled()
        reset()
    }

    private fun reset() {
        tickCooldown = 0
        queue.clear()
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        when (interceptablePacket.packet) {
            is PlayerAuthInputPacket -> onTick()
            is StartGamePacket, is ChangeDimensionPacket -> reset() // equivale a onWorldChange de Kiwi
        }
    }

    private fun resolveAnchorRids(): Set<Int> {
        val version = session.kiwiWorld.worldVersion
        if (anchorRidsCache.isEmpty() || anchorRidsWorldVersion != version) {
            anchorRidsCache = session.blockMapping.runtimeIdsByIdentifier("minecraft:respawn_anchor")
            anchorRidsWorldVersion = version
        }
        return anchorRidsCache
    }

    private fun onTick() {
        val lp = session.localPlayer
        if (eatStop && ItemUseState.using) return
        if (tickCooldown > 0) {
            tickCooldown--
            return
        }
        if (queue.isEmpty()) {
            scan(lp)
            if (queue.isEmpty()) {
                tickCooldown = 15
                return
            }
        }
        var i = 0
        while (queue.isNotEmpty() && i < clicksPerTick) {
            clickAnchor(queue.removeFirst(), lp)
            i++
        }
        if (queue.isEmpty()) tickCooldown = delay
    }

    private fun scan(player: LocalPlayer) {
        val px = floor(player.posX).toInt()
        val pz = floor(player.posZ).toInt()
        val py = floor(session.adaptiveFeetY(player.posY, px, pz, true, -1.62f)).toInt()
        val r = range
        val r2 = r * r
        val world = session.kiwiWorld
        val rids = resolveAnchorRids()

        val found = ArrayList<Vector3i>()
        for (dx in -r..r) for (dy in -r..r) for (dz in -r..r) {
            if (dx * dx + dy * dy + dz * dz > r2) continue
            val pos = Vector3i.from(px + dx, py + dy, pz + dz)
            if (!world.isBlockKnown(pos)) {
                world.requestBlockData(pos)
                continue
            }
            val rid = world.getBlockRuntimeId(pos)
            if (rid != 0 && rid in rids) found.add(pos)
        }
        found.sortBy { distSq(it, player) }
        queue.addAll(found)
    }

    private fun distSq(pos: Vector3i, player: LocalPlayer): Float {
        val x = pos.x + 0.5f - player.posX
        val y = pos.y + 0.5f - player.posY
        val z = pos.z + 0.5f - player.posZ
        return x * x + y * y + z * z
    }

    private fun clickAnchor(pos: Vector3i, player: LocalPlayer) {
        val heldSlot = player.inventory.heldItemSlot
        val slot: Int
        if (anchorCharge(pos) < 1) {
            slot = findItemSlot("glowstone") ?: return // sin glowstone no se puede cargar
        } else {
            slot = findNonGlowstoneSlot() ?: heldSlot
        }
        if (slot != heldSlot) switchSlot(slot, player)
        clickBlock(pos, player)
        if (slot != heldSlot) switchSlot(heldSlot, player)
    }

    private fun anchorCharge(pos: Vector3i): Int = try {
        val states = session.blockMapping.getDefinition(session.kiwiWorld.getBlockRuntimeId(pos)).states
        if (states.isEmpty()) -1 else states.getInt("respawn_anchor_charge")
    } catch (_: Exception) {
        -1
    }

    private fun findNonGlowstoneSlot(): Int? {
        val inv = session.localPlayer.inventory
        for (i in 0 until 9) {
            val item = inv.content[i]
            val id = item.definition?.identifier ?: continue
            if (!id.contains("glowstone", ignoreCase = true) && item.count > 0) return i
        }
        return null
    }

    private fun findItemSlot(keyword: String): Int? {
        val inv = session.localPlayer.inventory
        for (i in 0 until 9) {
            val item = inv.content[i]
            val id = item.definition?.identifier ?: continue
            if (id.contains(keyword, ignoreCase = true) && item.count > 0) return i
        }
        return null
    }

    private fun switchSlot(slot: Int, player: LocalPlayer) {
        val item: ItemData = player.inventory.content.getOrNull(slot) ?: return
        player.inventory.heldItemSlot = slot
        session.clientBound(PlayerHotbarPacket().apply {
            selectedHotbarSlot = slot
            containerId = 0
            selectHotbarSlot = true
        })
        session.serverBound(MobEquipmentPacket().apply {
            runtimeEntityId = player.runtimeEntityId
            this.item = item
            inventorySlot = slot
            hotbarSlot = slot
        })
    }

    private fun clickBlock(pos: Vector3i, player: LocalPlayer) {
        val face = bestFaceFor(pos, player)
        session.serverBound(InventoryTransactionPacket().apply {
            transactionType = InventoryTransactionType.ITEM_USE
            actionType = 0
            blockPosition = pos
            blockFace = face
            hotbarSlot = player.inventory.heldItemSlot
            itemInHand = player.inventory.hand
            playerPosition = player.vec3Position
            clickPosition = clickPosForFace(face)
            blockDefinition = blockDefAt(pos)
            triggerType = ItemUseTransaction.TriggerType.PLAYER_INPUT
            clientInteractPrediction = ItemUseTransaction.PredictedResult.SUCCESS
        })
        player.swing()
    }

    private fun bestFaceFor(pos: Vector3i, player: LocalPlayer): Int {
        val dx = player.posX - (pos.x + 0.5f)
        val dy = player.posY - (pos.y + 0.5f)
        val dz = player.posZ - (pos.z + 0.5f)
        val ax = abs(dx)
        val ay = abs(dy)
        val az = abs(dz)
        if (ay >= ax && ay >= az) return if (dy > 0f) 1 else 0
        if (ax >= az) return if (dx > 0f) 5 else 4
        return if (dz > 0f) 3 else 2
    }

    private fun clickPosForFace(face: Int): Vector3f = when (face) {
        0 -> Vector3f.from(0.5f, 0.0f, 0.5f)
        1 -> Vector3f.from(0.5f, 1.0f, 0.5f)
        2 -> Vector3f.from(0.5f, 0.62f, 0.0f)
        3 -> Vector3f.from(0.5f, 0.62f, 1.0f)
        4 -> Vector3f.from(0.0f, 0.62f, 0.5f)
        else -> Vector3f.from(1.0f, 0.62f, 0.5f)
    }

    private fun blockDefAt(pos: Vector3i): BlockDefinition? {
        session.kiwiWorld.knownDefinition(pos)?.let { return it }
        session.kiwiWorld.requestBlockData(pos)
        return session.blockMapping.definitionByIdentifier("minecraft:obsidian")
    }
}
