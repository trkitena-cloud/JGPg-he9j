package com.retrivedmods.wclient.game.module.misc

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.ModuleGuard
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory

/**
 * Modo rendimiento: apaga ModuleGuard (la medicion de cada modulo en cada paquete, la pausa
 * automatica de modulos lentos y el resumen periodico al log). Es el costo fijo mas grande del
 * diagnostico, asi que al encenderlo ganas un poco de CPU a cambio de perder el log.
 *
 * Apagado por defecto. Se sincroniza en cada paquete: al apagar este modulo, ModuleGuard vuelve a
 * medir como siempre.
 */
class PerformanceModeModule : Module("performance_mode", ModuleCategory.Misc) {

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        val guardOn = !isEnabled
        if (ModuleGuard.enabled != guardOn) ModuleGuard.enabled = guardOn
    }
}
