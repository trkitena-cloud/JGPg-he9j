package com.retrivedmods.wclient.game.module.misc

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket

/**
 * Timer (version segura): baja la cadencia de los PlayerAuthInputPacket que salen hacia el servidor.
 *
 * Con TPS menor que 20 se descartan paquetes de forma pareja (un acumulador, no el reloj), asi el
 * movimiento se ve estable en vez de entrecortado. Solo se puede ir mas lento: no se mandan paquetes
 * extra, asi que el servidor no ve nada anormal. Con Tickshift el TPS oscila entre Min y Max
 * (modo 0 = alterna, modo 1 = sube y baja gradualmente), siempre dentro de 1..20.
 */
class TimerModule : Module("timer", ModuleCategory.Misc) {

    private val tps by intValue("TPS", 20, 1..20)
    private val tickshift by boolValue("Tickshift", false)
    private val minTps by intValue("Min TPS", 20, 1..20)
    private val maxTps by intValue("Max TPS", 20, 1..20)
    private val tickshiftDuration by intValue("Tickshift Duration", 100, 10..1000)
    private val tickshiftMode by intValue("Tickshift Mode", 0, 0..1) // 0 = switch, 1 = increment

    private var currentTps = 20
    private var tickCounter = 0
    private var increasing = true

    /** Cada paquete suma el TPS; al pasar de 20 se envia, si no se descarta. Reparto parejo. */
    private var accumulator = 0

    override fun onEnabled() {
        super.onEnabled()
        tickCounter = 0
        increasing = true
        currentTps = tps
        accumulator = 0
    }

    override fun onDisabled() {
        super.onDisabled()
        currentTps = 20
        tickCounter = 0
        increasing = true
        accumulator = 0
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet
        if (packet !is PlayerAuthInputPacket) return

        currentTps = computeCurrentTps().coerceIn(1, 20)

        // De cada 20 paquetes se envian currentTps. Con 20 no se descarta nada.
        if (currentTps >= 20) {
            accumulator = 0
            return
        }
        accumulator += currentTps
        if (accumulator >= 20) {
            accumulator -= 20
        } else {
            interceptablePacket.intercept()
        }
    }

    private fun computeCurrentTps(): Int {
        if (!tickshift) return tps

        val lo = minOf(minTps, maxTps)
        val hi = maxOf(maxTps, minTps)

        val next: Int
        if (tickshiftMode == 0) {
            next = if (tickCounter >= tickshiftDuration) {
                tickCounter = 0
                if (currentTps == lo) hi else lo
            } else {
                currentTps
            }
        } else {
            val step = if (tickshiftDuration <= 0) 0.0 else (hi - lo).toDouble() / tickshiftDuration
            var d = currentTps.toDouble()
            if (increasing) {
                d += step
                if (d >= hi) { increasing = false; d = hi.toDouble() }
            } else {
                d -= step
                if (d <= lo) { increasing = true; d = lo.toDouble() }
            }
            next = d.toInt().coerceIn(lo, hi)
        }
        tickCounter++
        return next
    }
}
