package com.retrivedmods.wclient.game

import com.retrivedmods.wclient.util.Lang

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.fastForEach
import com.retrivedmods.wclient.R
import com.retrivedmods.wclient.overlay.OverlayManager
import com.retrivedmods.wclient.util.translatedSelf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt


private val DarkBackground = Color(0xFF0C0C10)
private val CardBackground = Color(0xFF141418)
private val CardBackgroundExpanded = Color(0xFF18181E)
private val AccentPrimary: Color get() = com.retrivedmods.wclient.util.UiColors.accent
private val AccentSecondary = Color(0xFFD0D4DB)
private val AccentDark = Color(0xFF6D45C1)
private val TextPrimary = Color(0xFFF0F1F3)
private val TextSecondary = Color(0xFFA8ADB5)
private val BorderColor = Color(0xFF23232A)
private val BorderColorActive = Color(0xFF614A86)
private val ErrorRed = Color(0xFFCF222E)

private val moduleCache = HashMap<ModuleCategory, List<Module>>()

/** Texto de busqueda compartido por la GUI. Si no esta vacio, se buscan modulos en todas las categorias. */
object GuiSearch {
    var query by mutableStateOf("")
}

private fun matchesSearch(m: Module, q: String): Boolean =
    m.name.contains(q, ignoreCase = true) || m.name.translatedSelf.contains(q, ignoreCase = true)

@Composable
private fun SearchField() {
    OutlinedTextField(
        value = GuiSearch.query,
        onValueChange = { GuiSearch.query = it },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        placeholder = { Text(Lang.t("Buscar modulo...", "Search module...")) }
    )
}

private fun fetchCachedModules(category: ModuleCategory): List<Module> {
    val cached = moduleCache[category] ?: ModuleManager.modules
        .filter { !it.private && it.category === category }
    moduleCache[category] = cached
    return cached
}

@Composable
fun ModuleContent(moduleCategory: ModuleCategory) {
    var modules: List<Module>? by remember(moduleCategory) { mutableStateOf(moduleCache[moduleCategory]) }

    LaunchedEffect(modules) {
        if (modules == null) withContext(Dispatchers.IO) { modules = fetchCachedModules(moduleCategory) }
    }

    // Sin Crossfade: el AnimatedContent del ClickGUI ya hace la transicion y dos a la vez
    // doblaban el trabajo de composicion al cambiar de categoria.
    val list = modules
    val query = GuiSearch.query
    if (list != null) {
        val shown = if (query.isBlank()) list
            else ModuleManager.modules.filter { !it.private && matchesSearch(it, query.trim()) }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "search") { SearchField() }
            items(shown.size, key = { i -> shown[i].name }) { i -> ModuleCard(shown[i]) }
        }
    } else {
        Box(Modifier.fillMaxSize()) {
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center),
                color = AccentPrimary
            )
        }
    }
}

@Composable
private fun ModuleCard(module: Module) {
    val values = module.values
    // Color y elevacion directos (antes animados con spring "bouncy": redibujaban la sombra de la
    // tarjeta en cada fotograma). Solo se anima el tamano, con un tween corto.
    val bg = if (module.isExpanded) CardBackgroundExpanded else CardBackground

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { module.isExpanded = !module.isExpanded },
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            Modifier
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    module.name.translatedSelf,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (module.isEnabled) AccentPrimary else TextPrimary
                )
                Spacer(Modifier.weight(1f))
                Switch(
                    checked = module.isEnabled,
                    onCheckedChange = { module.isEnabled = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = AccentPrimary,
                        checkedTrackColor = AccentPrimary.copy(alpha = 0.3f),
                        checkedBorderColor = Color.Transparent,
                        uncheckedThumbColor = Color(0xFF353535),
                        uncheckedTrackColor = Color(0xFF1A1A1A),
                        uncheckedBorderColor = BorderColor
                    ),
                    modifier = Modifier
                        .width(52.dp)
                        .height(32.dp)
                )
            }

            if (module.isExpanded) {
                values.fastForEach {
                    when (it) {
                        is BoolValue -> BoolValueContent(it)
                        is FloatValue -> FloatValueContent(it)
                        is IntValue -> IntValueContent(it)
                        is ListValue -> ChoiceValueContent(it)
                        is EnumValue<*> -> EnumValueContent(it)
                        is StringValue -> StringValueContent(it)
                    }
                }
                ShortcutContent(module)
            }
        }
    }
}

@Composable
private fun ChoiceValueContent(value: ListValue) {
    Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp)) {
        Text(
            value.name.translatedSelf,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            value.listItems.forEach { item ->
                FilterChip(
                    selected = value.value == item,
                    onClick = { if (value.value != item) value.value = item },
                    label = { Text(item.name.translatedSelf) },
                    modifier = Modifier.height(32.dp),
                    enabled = true,
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = Color(0xFF1A1A1A),
                        selectedContainerColor = AccentPrimary,
                        labelColor = TextSecondary,
                        selectedLabelColor = Color.Black,
                        disabledContainerColor = Color(0xFF121212),
                        disabledLabelColor = Color(0xFF606060)
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = value.value == item,
                        borderColor = BorderColor,
                        selectedBorderColor = AccentPrimary,
                        disabledBorderColor = Color(0xFF1A1A1A),
                        disabledSelectedBorderColor = Color(0xFF1A1A1A)
                    )
                )
                Spacer(Modifier.width(8.dp))
            }
        }
    }
}

@Composable
private fun FloatValueContent(value: FloatValue) {
    Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp)) {
        Row(modifier = Modifier.padding(bottom = 4.dp)) {
            Text(
                value.name.translatedSelf,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Spacer(Modifier.weight(1f))
            Text(
                String.format("%.2f", value.value),
                style = MaterialTheme.typography.bodyMedium,
                color = AccentPrimary
            )
        }

        // El pulgar sigue al dedo directamente: animarlo con un spring suave lo dejaba atrasado
        // y recomponiendo durante cientos de ms tras cada movimiento.
        SlimSlider(
            value = value.value,
            onValueChange = {
                val rounded = ((it * 100.0).roundToInt() / 100.0).toFloat()
                if (value.value != rounded) value.value = rounded
            },
            valueRange = value.range
        )
    }
}

@Composable
private fun IntValueContent(value: IntValue) {
    Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp)) {
        Row(modifier = Modifier.padding(bottom = 4.dp)) {
            Text(
                value.name.translatedSelf,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Spacer(Modifier.weight(1f))
            Text(
                value.value.toString(),
                style = MaterialTheme.typography.bodyMedium,
                color = AccentPrimary
            )
        }

        SlimSlider(
            value = value.value.toFloat(),
            onValueChange = {
                val next = it.roundToInt()
                if (value.value != next) value.value = next
            },
            valueRange = value.range.toFloatRange()
        )
    }
}

@Composable
private fun SlimSlider(
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    val thumbRadius = 6.dp
    val thumbRadiusPx = with(androidx.compose.ui.platform.LocalDensity.current) {
        thumbRadius.toPx()
    }
    val clampedValue = value.coerceIn(valueRange.start, valueRange.endInclusive)

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(28.dp)
            .pointerInput(valueRange, thumbRadiusPx) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    var isPressed = true
                    var lastPosition = down.position.x
                    onValueChange(
                        sliderValueAt(lastPosition, size.width.toFloat(), thumbRadiusPx, valueRange)
                    )
                    down.consume()

                    while (isPressed) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        isPressed = change.pressed
                        if (isPressed) {
                            lastPosition = change.position.x
                            onValueChange(
                                sliderValueAt(
                                    lastPosition,
                                    size.width.toFloat(),
                                    thumbRadiusPx,
                                    valueRange
                                )
                            )
                            change.consume()
                        }
                    }
                }
            }
            .semantics {
                progressBarRangeInfo = ProgressBarRangeInfo(clampedValue, valueRange)
                setProgress { target ->
                    onValueChange(target.coerceIn(valueRange.start, valueRange.endInclusive))
                    true
                }
            }
    ) {
        val centerY = size.height / 2f
        val startX = thumbRadiusPx
        val endX = (size.width - thumbRadiusPx).coerceAtLeast(startX)
        val fraction = if (valueRange.endInclusive > valueRange.start) {
            (clampedValue - valueRange.start) / (valueRange.endInclusive - valueRange.start)
        } else {
            0f
        }
        val thumbX = startX + (endX - startX) * fraction

        drawLine(
            color = Color(0xFF484151),
            start = Offset(startX, centerY),
            end = Offset(endX, centerY),
            strokeWidth = 2.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = AccentPrimary,
            start = Offset(startX, centerY),
            end = Offset(thumbX, centerY),
            strokeWidth = 2.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawCircle(
            color = AccentPrimary.copy(alpha = 0.28f),
            radius = thumbRadiusPx,
            center = Offset(thumbX, centerY)
        )
        drawCircle(
            color = AccentSecondary,
            radius = thumbRadiusPx * 0.62f,
            center = Offset(thumbX, centerY)
        )
    }
}

private fun sliderValueAt(
    position: Float,
    width: Float,
    thumbRadius: Float,
    valueRange: ClosedFloatingPointRange<Float>
): Float {
    val startX = thumbRadius
    val endX = (width - thumbRadius).coerceAtLeast(startX)
    val fraction = ((position - startX) / (endX - startX).coerceAtLeast(1f)).coerceIn(0f, 1f)
    return valueRange.start + (valueRange.endInclusive - valueRange.start) * fraction
}

@Composable
private fun BoolValueContent(value: BoolValue) {
    Row(
        Modifier
            .padding(start = 16.dp, end = 16.dp, bottom = 8.dp)
            .fillMaxWidth()
            .toggleable(
                value = value.value,
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                enabled = true
            ) { value.value = it },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            value.name.translatedSelf,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )
        Spacer(Modifier.weight(1f))
        Checkbox(
            checked = value.value,
            onCheckedChange = null,
            modifier = Modifier.padding(0.dp),
            enabled = true,
            colors = CheckboxDefaults.colors(
                uncheckedColor = Color(0xFF353535),
                checkedColor = AccentPrimary,
                checkmarkColor = Color.Black,
                disabledCheckedColor = Color(0xFF353535),
                disabledUncheckedColor = Color(0xFF252525),
                disabledIndeterminateColor = Color(0xFF353535)
            )
        )
    }
}

@Composable
private fun ShortcutContent(module: Module) {
    Row(
        Modifier
            .padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
            .fillMaxWidth()
            .toggleable(
                value = module.isShortcutDisplayed,
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                enabled = true
            ) {
                module.isShortcutDisplayed = it
                if (it) OverlayManager.showOverlayWindow(module.overlayShortcutButton)
                else OverlayManager.dismissOverlayWindow(module.overlayShortcutButton)
            },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            stringResource(R.string.shortcut),
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )
        Spacer(Modifier.weight(1f))
        Checkbox(
            checked = module.isShortcutDisplayed,
            onCheckedChange = null,
            modifier = Modifier.padding(0.dp),
            enabled = true,
            colors = CheckboxDefaults.colors(
                uncheckedColor = Color(0xFF353535),
                checkedColor = AccentPrimary,
                checkmarkColor = Color.Black,
                disabledCheckedColor = Color(0xFF353535),
                disabledUncheckedColor = Color(0xFF252525),
                disabledIndeterminateColor = Color(0xFF353535)
            )
        )
    }
}

@Composable
private fun <T : Enum<T>> EnumValueContent(value: EnumValue<T>) {
    Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp)) {
        Text(
            value.name.translatedSelf,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            value.enumClass.enumConstants?.forEach { option ->
                FilterChip(
                    selected = value.value == option,
                    onClick = { if (value.value != option) value.value = option },
                    label = { Text(option.name.translatedSelf) },
                    modifier = Modifier.height(32.dp),
                    enabled = true,
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = Color(0xFF1A1A1A),
                        selectedContainerColor = AccentPrimary,
                        labelColor = TextSecondary,
                        selectedLabelColor = Color.Black,
                        disabledContainerColor = Color(0xFF121212),
                        disabledLabelColor = Color(0xFF606060)
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = value.value == option,
                        borderColor = BorderColor,
                        selectedBorderColor = AccentPrimary,
                        disabledBorderColor = Color(0xFF1A1A1A),
                        disabledSelectedBorderColor = Color(0xFF1A1A1A)
                    )
                )
                Spacer(Modifier.width(8.dp))
            }
        }
    }
}

@Composable
private fun StringValueContent(value: StringValue) {
    val choices = value.choices
    if (choices != null) {
        Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp)) {
            Text(
                value.name.translatedSelf,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                choices.forEach { item ->
                    FilterChip(
                        selected = value.value == item,
                        onClick = { if (value.value != item) value.value = item },
                        label = { Text(item) },
                        modifier = Modifier.height(32.dp),
                        enabled = true,
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = Color(0xFF1A1A1A),
                            selectedContainerColor = AccentPrimary,
                            labelColor = TextSecondary,
                            selectedLabelColor = Color.Black,
                            disabledContainerColor = Color(0xFF121212),
                            disabledLabelColor = Color(0xFF606060)
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = value.value == item,
                            borderColor = BorderColor,
                            selectedBorderColor = AccentPrimary,
                            disabledBorderColor = Color(0xFF1A1A1A),
                            disabledSelectedBorderColor = Color(0xFF1A1A1A)
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                }
            }
        }
        return
    }
    Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp)) {
        Text(
            value.name.translatedSelf,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        OutlinedTextField(
            value = value.value,
            onValueChange = { value.value = it },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            enabled = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AccentPrimary,
                unfocusedBorderColor = BorderColor,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                cursorColor = AccentPrimary,
                disabledBorderColor = Color(0xFF1A1A1A),
                disabledTextColor = Color(0xFF606060),
                errorBorderColor = ErrorRed,
                errorTextColor = TextPrimary,
                errorCursorColor = ErrorRed
            ),
            shape = MaterialTheme.shapes.small
        )
    }
}

private fun IntRange.toFloatRange() = first.toFloat()..last.toFloat()