package com.retrivedmods.wclient.game.friend

import com.retrivedmods.wclient.application.AppContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Lista de friends (mismo API que FriendManager de KiwiMods). Guarda UUID y nombre, y los persiste
 * en configs/friends.json dentro de la app, para que sobrevivan al cerrar la app.
 * Se lee desde el hilo de paquetes y se edita desde comandos y GUI, por eso es un mapa concurrente.
 */
object FriendManager {

    private const val FILE_NAME = "friends.json"

    private val friends = ConcurrentHashMap<UUID, String>()

    fun addFriend(uuid: UUID, name: String = "") {
        val old = friends[uuid]
        friends[uuid] = name.ifBlank { old.orEmpty() }
        save()
    }

    fun removeFriend(uuid: UUID) {
        friends.remove(uuid)
        save()
    }

    fun isFriend(uuid: UUID): Boolean = friends.containsKey(uuid)

    fun getFriends(): Set<UUID> = friends.keys

    /** Pares (uuid, nombre) para mostrarlos; el nombre puede estar vacio si nunca se vio al jugador. */
    fun entries(): List<Pair<UUID, String>> = friends.entries.map { it.key to it.value }

    fun clear() {
        friends.clear()
        save()
    }

    /** Carga la lista guardada. Se llama al iniciar, cuando el contexto de la app ya existe. */
    @Synchronized
    fun load() {
        val file = file() ?: return
        if (!file.exists()) return
        try {
            friends.clear()
            Json.parseToJsonElement(file.readText()).jsonArray.forEach { el ->
                val obj = el.jsonObject
                val uuid = UUID.fromString(obj["uuid"]!!.jsonPrimitive.content)
                friends[uuid] = obj["name"]?.jsonPrimitive?.content.orEmpty()
            }
        } catch (e: Exception) {
            // Archivo corrupto: se ignora y se sobrescribe en el siguiente cambio.
        }
    }

    @Synchronized
    private fun save() {
        val file = file() ?: return
        try {
            val json = buildJsonArray {
                friends.forEach { (uuid, name) ->
                    add(buildJsonObject {
                        put("uuid", uuid.toString())
                        put("name", name)
                    })
                }
            }.toString()
            val tmp = File(file.parentFile, "$FILE_NAME.tmp")
            tmp.writeText(json)
            if (!tmp.renameTo(file)) {
                file.writeText(json)
                tmp.delete()
            }
        } catch (e: Exception) {
            // Si no se puede escribir, la lista sigue funcionando en memoria.
        }
    }

    private fun file(): File? {
        if (!AppContext.isInitialized) return null
        val dir = AppContext.instance.filesDir.resolve("configs")
        dir.mkdirs()
        return dir.resolve(FILE_NAME)
    }
}
