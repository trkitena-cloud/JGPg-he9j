package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.kiwi.FriendManager
import com.retrivedmods.wclient.game.kiwi.entityFeetY
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import kotlin.math.atan2
import kotlin.math.sqrt

/**
 * Head Lock: gira la cabeza del jugador hacia otro jugador cercano y se queda fijo en el.
 * Apunta a la cabeza, al cuerpo o a los pies segun la opcion "Aim". Mantiene el mismo objetivo
 * mientras siga valido (en rango, no amigo, no el jugador falso) y solo cambia si lo pierde.
 * La rotacion se envia como en Crystal Aura: copia rotada y original interceptado.
 */
class HeadLockModule : Module("Head Lock", ModuleCategory.Combat) {

    private val range by floatValue("Range", 6.0f, 2.0f..12.0f)
    private val aim by stringValue("Aim", "Head", listOf("Head", "Body", "Feet"))

    private var locked: Player? = null

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet
        if (packet !is PlayerAuthInputPacket) return

        val lp = session.localPlayer
        val target = pickTarget(lp)
        if (target == null) {
            locked = null
            return
        }

        val feet = session.entityFeetY(target)
        val aimY = when (aim) {
            "Feet" -> feet + 0.1f
            "Body" -> feet + 0.9f
            else -> feet + 1.5f
        }

        val dx = target.posX - lp.posX
        val dy = aimY - lp.posY
        val dz = target.posZ - lp.posZ
        val horizontal = sqrt(dx * dx + dz * dz)
        val yaw = Math.toDegrees(atan2(-dx.toDouble(), dz.toDouble())).toFloat()
        val pitch = (-Math.toDegrees(atan2(dy.toDouble(), horizontal.toDouble()))).toFloat()

        val clone = packet.clone()
        clone.rotation = Vector3f.from(pitch, yaw, yaw)
        session.serverBound(clone)
        interceptablePacket.intercept()
    }

    private fun pickTarget(lp: LocalPlayer): Player? {
        val current = locked
        if (current != null && isValid(current, lp)) return current
        locked = session.level.entityMap.values
            .filterIsInstance<Player>()
            .filter { isValid(it, lp) }
            .minByOrNull { it.vec3Position.distance(lp.vec3Position) }
        return locked
    }

    private fun isValid(e: Player, lp: LocalPlayer): Boolean =
        e !== lp &&
            !FakePlayerModule.isFake(e.uniqueEntityId) &&
            !FriendManager.isFriend(e.uuid) &&
            e.vec3Position.distance(lp.vec3Position) <= range

    override fun onDisabled() {
        super.onDisabled()
        locked = null
    }
}
