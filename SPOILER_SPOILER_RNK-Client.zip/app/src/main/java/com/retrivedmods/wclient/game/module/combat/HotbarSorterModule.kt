package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket

/**
 * Port de HotbarSorter de Kiwi. Cada categoria tiene un slot de barra rapida (1-9, 0 = apagado).
 * Si ese slot ya contiene un item de la categoria no hace nada; si no, mueve el primero que
 * encuentre en el inventario (slots 9..35) a ese slot.
 */
class HotbarSorterModule : Module("Hotbar Sorter", ModuleCategory.Combat) {

    private var crystalSlot by intValue("End Crystal", 0, 0..9)
    private var anchorSlot by intValue("Respawn Anchor", 0, 0..9)
    private var gappleSlot by intValue("Golden Apple", 0, 0..9)
    private var bedSlot by intValue("Bed", 0, 0..9)
    private var obsidianSlot by intValue("Obsidian", 0, 0..9)
    private var glowstoneSlot by intValue("Glowstone", 0, 0..9)
    private var echestSlot by intValue("Ender Chest", 0, 0..9)

    // Pausa tras mandar un movimiento para no reenviar la misma peticion en cada tick.
    @Volatile
    private var pendingUntil = 0L

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        if (interceptablePacket.packet !is PlayerAuthInputPacket) return

        val now = System.currentTimeMillis()
        if (now < pendingUntil) return

        val inv = session.localPlayer.inventory
        for ((slot, keywords) in wanted()) {
            if (slot == 0) continue
            val hotbarIndex = slot - 1

            val current = inv.content.getOrNull(hotbarIndex)?.definition?.identifier
            if (current != null && keywords.any { current.contains(it, ignoreCase = true) }) continue

            for (i in 9 until 36) {
                val item = inv.content.getOrNull(i) ?: continue
                if (item == ItemData.AIR) continue
                val id = item.definition?.identifier ?: continue
                if (keywords.any { id.contains(it, ignoreCase = true) }) {
                    try {
                        inv.moveItem(i, hotbarIndex, inv, session)
                        pendingUntil = now + 400L
                    } catch (_: Exception) {
                    }
                    break
                }
            }
        }
    }

    private fun wanted(): List<Pair<Int, List<String>>> = listOf(
        crystalSlot to listOf("end_crystal", "ender_crystal"),
        anchorSlot to listOf("respawn_anchor"),
        gappleSlot to listOf("golden_apple"),
        // Kiwi usa "minecraft:item.bed", que no coincide con los ids reales de cama; aqui "_bed".
        bedSlot to listOf("_bed"),
        obsidianSlot to listOf("obsidian"),
        glowstoneSlot to listOf("glowstone"),
        echestSlot to listOf("ender_chest"),
    )
}
