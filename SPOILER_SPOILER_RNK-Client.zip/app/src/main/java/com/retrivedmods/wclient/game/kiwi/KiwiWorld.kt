package com.retrivedmods.wclient.game.kiwi

import android.util.Log
import com.retrivedmods.wclient.game.GameSession
import com.retrivedmods.wclient.game.entity.Entity
import com.retrivedmods.wclient.game.entity.EntityUnknown
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.registry.BlockDefinition
import com.retrivedmods.wclient.game.registry.UnknownBlockDefinition
import com.retrivedmods.wclient.game.utils.constants.Attribute
import com.retrivedmods.wclient.game.kiwi.chunk.BlockStorage
import com.retrivedmods.wclient.game.kiwi.chunk.ChunkSection
import com.retrivedmods.wclient.game.kiwi.chunk.palette.BitArrayVersion
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.data.SubChunkRequestResult
import org.cloudburstmc.protocol.bedrock.packet.AddEntityPacket
import org.cloudburstmc.protocol.bedrock.packet.BedrockPacket
import org.cloudburstmc.protocol.bedrock.packet.ChangeDimensionPacket
import org.cloudburstmc.protocol.bedrock.packet.ChunkRadiusUpdatedPacket
import org.cloudburstmc.protocol.bedrock.packet.LevelChunkPacket
import org.cloudburstmc.protocol.bedrock.packet.StartGamePacket
import org.cloudburstmc.protocol.bedrock.packet.SubChunkPacket
import org.cloudburstmc.protocol.bedrock.packet.SubChunkRequestPacket
import org.cloudburstmc.protocol.bedrock.packet.UpdateBlockPacket
import org.cloudburstmc.protocol.bedrock.packet.UpdateSubChunkBlocksPacket
import io.netty.buffer.ByteBuf
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ThreadFactory
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Modelo de mundo de KiwiMods para las auras de cristales/camas/anclas.
 *
 * Por que existe: el World de Lumina no recibe paquetes (su onPacket esta comentado en GameSession) y
 * su Chunk no soporta alturas negativas (overworld 1.18+: y = -64..319, 24 secciones). Este modelo
 * lleva sus propios chunks con "minSectionY" y recibe los paquetes desde GameSession.
 *
 * Es el equivalente de las partes de game/world/Level de Kiwi que usan las auras:
 *  - bloques: getBlockRuntimeId / isBlockKnown / knownDefinition / getBlockDefinition
 *  - cristales y jugadores cercanos, soporte de cristal
 *  - simulacion de dano de explosion (exposicion por rayos + oclusion + armadura)
 *
 * Lo que NO se porta: la calibracion adaptativa de altura de pies (se usa pies = posY - 1.62 para
 * jugadores) ni el re-aprendizaje de runtime IDs a partir de UpdateBlockPacket (Lumina elige el
 * mapa de bloques por version de protocolo) ni requestBlockData (el propio cliente pide los
 * subchunks y sus respuestas pasan por aqui).
 */
class KiwiWorld(private val session: GameSession) {

    private class KChunk(val x: Int, val z: Int, val minSectionY: Int, count: Int) {
        val sections = Array(count) { ChunkSection() }
        val populated = BooleanArray(count)
        fun index(blockY: Int) = (blockY shr 4) - minSectionY
    }

    private val chunks = ConcurrentHashMap<Long, KChunk>()

    // ---- el parseo de chunks/subchunks se hace fuera del hilo de red (como Kiwi con corrutinas)
    // Un solo hilo mantiene el orden de llegada; cada seccion se construye completa antes de publicarse.
    private val parseExecutor = ThreadPoolExecutor(
        1, 1, 30L, TimeUnit.SECONDS, LinkedBlockingQueue<Runnable>(),
        ThreadFactory { r ->
            Thread(r, "Abysm-WorldParser").apply {
                isDaemon = true
                priority = Thread.NORM_PRIORITY - 1
            }
        }
    ).apply { allowCoreThreadTimeOut(true) }
    private val pendingParses = AtomicInteger()

    /** Se incrementa al limpiar el mundo: las tareas pendientes de un mundo anterior no publican nada. */
    @Volatile
    private var worldEpoch = 0

    @Volatile private var statDropped = 0

    private class SubChunkItem(val pos: Vector3i, val allAir: Boolean, val data: ByteBuf?)

    /** Encola [task] en el hilo de parseo; [cleanup] siempre se ejecuta (libera buffers). Con la cola llena descarta. */
    private fun submitParse(task: () -> Unit, cleanup: () -> Unit) {
        if (pendingParses.get() >= MAX_PENDING_PARSES) {
            statDropped++
            cleanup()
            return
        }
        pendingParses.incrementAndGet()
        try {
            parseExecutor.execute {
                try {
                    task()
                } catch (e: Throwable) {
                    Log.w("KiwiWorld", "Error procesando datos del mundo", e)
                } finally {
                    cleanup()
                    pendingParses.decrementAndGet()
                }
            }
        } catch (e: RejectedExecutionException) {
            pendingParses.decrementAndGet()
            cleanup()
        }
    }

    // ---- contadores de diagnostico (como llegan los datos del mundo en este servidor)
    @Volatile private var statNormal = 0
    @Volatile private var statRequestMode = 0
    @Volatile private var statCaching = 0
    @Volatile private var statParseFail = 0
    @Volatile private var statSubOk = 0
    @Volatile private var statSubAllAir = 0
    @Volatile private var statSubOther = 0
    @Volatile private var statSubFail = 0

    /** Texto corto con el estado de los datos del mundo (se muestra en el chat para diagnosticar). */
    fun debugSummary(): String {
        var total = 0
        var populated = 0
        for (c in chunks.values) {
            total += c.sections.size
            for (b in c.populated) if (b) populated++
        }
        return "chunks=${chunks.size} secciones con datos=$populated/$total | LevelChunk: normal=$statNormal " +
            "porPeticion=$statRequestMode conCache=$statCaching fallos=$statParseFail | SubChunk: ok=$statSubOk " +
            "aire=$statSubAllAir otros=$statSubOther fallos=$statSubFail descartados=$statDropped"
    }
    private var dimension = 0

    /** Bloques cambiados fuera de secciones ya cargadas (UpdateBlock antes de recibir el chunk). */
    val blockMap = ConcurrentHashMap<Vector3i, Int>()

    /** Colocaciones esperadas (pos -> identificador). Se limpian al llegar el UpdateBlock. */
    val pendingPlacements = ConcurrentHashMap<Vector3i, String>()

    /** Se incrementa al cambiar de mundo/dimension (cambia el mapa de bloques); invalida caches de IDs. */
    @Volatile
    var worldVersion = 0L
        private set

    /** Se incrementa con cada cambio de bloques/chunks; las auras lo usan para regenerar sus listas. */
    @Volatile
    var blockVersion = 0L
        private set

    private val pendingTimes = ConcurrentHashMap<Vector3i, Long>()

    /** Mayor runtimeEntityId de cristal visto (para "ID Predict"). */
    @Volatile
    var highestCrystalRuntimeId = -1L
        private set

    /** Aplica un cambio de bloque predicho (p. ej. el que acabamos de colocar). */
    fun setBlockPredicted(pos: Vector3i, runtimeId: Int) = setBlock(pos, runtimeId)

    fun registerPlacement(pos: Vector3i, identifier: String) {
        pendingPlacements[pos] = identifier
        pendingTimes[pos] = System.currentTimeMillis()
    }

    /**
     * true si hay una colocacion registrada en [pos] hace menos de [maxAgeMs]. En Kiwi estas entradas
     * solo se borraban con un UpdateBlock en esa posicion, asi que tras colocar un cristal el soporte
     * quedaba bloqueado para siempre; aqui caducan.
     */
    fun isPlacementPending(pos: Vector3i, maxAgeMs: Long = 1000L): Boolean {
        val t = pendingTimes[pos] ?: return false
        if (System.currentTimeMillis() - t > maxAgeMs) {
            pendingTimes.remove(pos)
            pendingPlacements.remove(pos)
            return false
        }
        return true
    }

    fun clear() {
        worldEpoch++
        chunks.clear()
        blockMap.clear()
        pendingPlacements.clear()
        pendingTimes.clear()
        highestCrystalRuntimeId = -1L
        worldVersion++
        blockVersion++
    }

    // ------------------------------------------------------------------ paquetes

    /**
     * El rastreo del mundo (leer chunks, guardar bloques, pedir subchunks al servidor) solo se hace
     * mientras haya un modulo que lo use (CrystalAura, BedAura, Surround, Anchor...). Antes corria
     * siempre: gastaba CPU y memoria en gama baja y pedia hasta 512 subchunks al servidor aunque no
     * hubiera nada activado. KiwiMods original tampoco hace nada de esto sin un modulo que lo pida.
     */
    @Volatile private var tracking = false
    private var offSinceMs = 0L

    fun setTracking(on: Boolean) {
        if (on == tracking) return
        tracking = on
        if (on) {
            offSinceMs = 0L
            // Lo que llego mientras estaba apagado no se guardo: se rellena alrededor del jugador.
            lastFillChunk = Long.MIN_VALUE
            fillRequestAttempts = 0
            lastFillRequestTime = 0L
            submitParse({ maybeRequestSubChunks() }, { })
        } else {
            offSinceMs = System.currentTimeMillis()
        }
    }

    fun onPacket(packet: BedrockPacket) {
        // Apagado: tras 60 s sin uso se libera la memoria del mundo.
        if (!tracking && offSinceMs != 0L && System.currentTimeMillis() - offSinceMs > 60_000L) {
            offSinceMs = 0L
            if (chunks.isNotEmpty() || blockMap.isNotEmpty()) {
                worldEpoch++          // descarta lecturas en curso
                chunks.clear()
                blockMap.clear()
                blockVersion++
            }
        }
        try {
            when (packet) {
                is StartGamePacket -> {
                    dimension = packet.dimensionId
                    clear()
                }
                is ChangeDimensionPacket -> {
                    dimension = packet.dimension
                    clear()
                }
                is ChunkRadiusUpdatedPacket -> viewDistance = packet.radius
                is LevelChunkPacket -> if (tracking) handleLevelChunk(packet)
                is SubChunkPacket -> if (tracking) handleSubChunk(packet)
                is UpdateBlockPacket -> {
                    if (tracking && packet.dataLayer == 0) {
                        val rid = packet.definition?.runtimeId ?: return
                        setBlock(packet.blockPosition, rid)
                        pendingPlacements.remove(packet.blockPosition)
                        pendingTimes.remove(packet.blockPosition)
                    }
                }
                is UpdateSubChunkBlocksPacket -> {
                    if (!tracking) return
                    for (entry in packet.standardBlocks) {
                        val rid = entry.definition?.runtimeId ?: continue
                        setBlock(entry.position, rid)
                        pendingPlacements.remove(entry.position)
                        pendingTimes.remove(entry.position)
                    }
                }
                is AddEntityPacket -> {
                    if (packet.identifier == CRYSTAL_ID && packet.runtimeEntityId > highestCrystalRuntimeId) {
                        highestCrystalRuntimeId = packet.runtimeEntityId
                    }
                }
            }
        } catch (_: Exception) {
            // Un paquete de chunk raro no debe tumbar la sesion.
        }
    }

    private fun minSectionY(dim: Int) = if (dim == 0) -4 else 0
    private fun sectionCount(dim: Int) = if (dim == 0) 24 else 16

    private fun newChunk(x: Int, z: Int, dim: Int) = KChunk(x, z, minSectionY(dim), sectionCount(dim))

    private fun key(cx: Int, cz: Int): Long = (cx.toLong() shl 32) or (cz.toLong() and 0xFFFFFFFFL)

    private fun handleLevelChunk(packet: LevelChunkPacket) {
        if (packet.requestSubChunks) statRequestMode++
        else if (packet.cachingEnabled) statCaching++
        else if (packet.subChunksLength > 0) statNormal++

        val cx = packet.chunkX
        val cz = packet.chunkZ
        val dim = packet.dimension
        val parseData = !packet.requestSubChunks && !packet.cachingEnabled && packet.subChunksLength > 0
        val wantFill = packet.subChunksLength != 0 || packet.cachingEnabled

        if (!parseData) {
            // Sin datos de bloques en el paquete: chunk vacio (barato) y, si procede, relleno por peticion.
            chunks[key(cx, cz)] = newChunk(cx, cz, dim)
            blockVersion++
            if (wantFill) submitParse({ maybeRequestSubChunks() }, { })
            return
        }

        // El buffer del paquete se libera al terminar de reenviarlo: se conserva una copia con indices propios.
        val data = packet.data.retainedDuplicate()
        val count = packet.subChunksLength
        val epoch = worldEpoch
        submitParse({
            val chunk = newChunk(cx, cz, dim)
            val n = min(count, chunk.sections.size)
            for (i in 0 until n) {
                try {
                    val section = ChunkSection()
                    section.read(data)
                    if (!section.hasRealStorage) airSection(section)
                    chunk.sections[i] = section
                    chunk.populated[i] = true
                } catch (_: Exception) {
                    statParseFail++
                    break
                }
            }
            if (epoch == worldEpoch) {
                chunks[key(cx, cz)] = chunk
                blockVersion++
                if (wantFill) maybeRequestSubChunks()
            }
        }, { data.release() })
    }

    private fun handleSubChunk(packet: SubChunkPacket) {
        val center = packet.centerPosition
        val dim = packet.dimension
        val items = ArrayList<SubChunkItem>()
        for (sc in packet.subChunks) {
            when (sc.result) {
                SubChunkRequestResult.SUCCESS_ALL_AIR -> {
                    statSubAllAir++
                    items.add(SubChunkItem(sc.position.add(center), true, null))
                }
                SubChunkRequestResult.SUCCESS -> items.add(SubChunkItem(sc.position.add(center), false, sc.data.retainedDuplicate()))
                else -> statSubOther++
            }
        }
        if (items.isEmpty()) return
        val epoch = worldEpoch
        submitParse({
            if (epoch == worldEpoch) {
                var changed = false
                for (item in items) {
                    val abs = item.pos
                    val chunk = chunks.getOrPut(key(abs.x, abs.z)) { newChunk(abs.x, abs.z, dim) }
                    val idx = abs.y - chunk.minSectionY
                    if (idx !in chunk.sections.indices) continue
                    val section = ChunkSection()
                    if (item.allAir) {
                        airSection(section)
                    } else {
                        try {
                            section.read(item.data!!)
                            if (!section.hasRealStorage) airSection(section)
                            statSubOk++
                        } catch (_: Exception) {
                            statSubFail++
                            continue
                        }
                    }
                    chunk.sections[idx] = section
                    chunk.populated[idx] = true
                    changed = true
                }
                if (changed) blockVersion++
            }
        }, {
            for (item in items) item.data?.release()
        })
    }

    private fun setBlock(pos: Vector3i, rid: Int) {
        blockVersion++
        val chunk = chunks[key(pos.x shr 4, pos.z shr 4)]
        if (chunk != null) {
            val idx = chunk.index(pos.y)
            if (idx in chunk.sections.indices && chunk.populated[idx]) {
                chunk.sections[idx].setBlock(pos.x and 15, pos.y and 15, pos.z and 15, rid)
                blockMap.remove(pos)
                return
            }
        }
        blockMap[pos] = rid
    }

    // ------------------------------------------------------------------ bloques

    fun isBlockKnown(pos: Vector3i): Boolean {
        val chunk = chunks[key(pos.x shr 4, pos.z shr 4)]
        if (chunk != null) {
            val idx = chunk.index(pos.y)
            if (idx in chunk.sections.indices && chunk.populated[idx]) return true
        }
        return blockMap.containsKey(pos)
    }

    fun getBlockRuntimeId(pos: Vector3i): Int {
        try {
            val chunk = chunks[key(pos.x shr 4, pos.z shr 4)]
            if (chunk != null) {
                val idx = chunk.index(pos.y)
                if (idx in chunk.sections.indices && chunk.populated[idx]) {
                    return chunk.sections[idx].getBlock(pos.x and 15, pos.y and 15, pos.z and 15)
                }
            }
        } catch (_: Exception) {
        }
        return blockMap[pos] ?: session.blockMapping.airId
    }

    fun getBlockDefinition(pos: Vector3i): BlockDefinition {
        val rid = getBlockRuntimeId(pos)
        return try {
            session.blockMapping.getDefinition(rid)
        } catch (_: Exception) {
            UnknownBlockDefinition(rid)
        }
    }

    /** Definicion del bloque si se conoce y no es aire; null en cualquier otro caso. */
    fun knownDefinition(pos: Vector3i): BlockDefinition? {
        if (!isBlockKnown(pos)) return null
        val rid = getBlockRuntimeId(pos)
        if (rid == 0 || rid == session.blockMapping.airId) return null
        val def = try {
            session.blockMapping.getDefinition(rid)
        } catch (_: Exception) {
            UnknownBlockDefinition(rid)
        }
        return if (def is UnknownBlockDefinition) null else def
    }

    // ------------------------------------------------------------------ peticiones de subchunks
    // Igual que Level de KiwiMods: si falta un bloque se le pide la subchunk al servidor, y si el modelo
    // esta poco lleno se piden las subchunks de alrededor del jugador.

    private val lastBlockRequests = ConcurrentHashMap<Vector3i, Long>()
    @Volatile private var viewDistance = -1
    private var lastFillChunk = Long.MIN_VALUE
    private var fillRequestAttempts = 0
    private var lastFillRequestTime = 0L

    /** Pide al servidor la subchunk que contiene [pos] si no se conoce (maximo una vez cada 350 ms por celda). */
    fun requestBlockData(pos: Vector3i) {
        if (!tracking || isBlockKnown(pos)) return
        val now = System.currentTimeMillis()
        // Todas las celdas de una misma subchunk comparten una sola peticion (un escaneo grande no inunda al servidor).
        val subChunk = Vector3i.from(pos.x shr 4, pos.y shr 4, pos.z shr 4)
        val last = lastBlockRequests[subChunk]
        if (last != null && now - last < BLOCK_REQUEST_THROTTLE_MS) return
        if (lastBlockRequests.size >= 1024) lastBlockRequests.clear()
        lastBlockRequests[subChunk] = now
        val request = SubChunkRequestPacket()
        request.dimension = dimension
        request.subChunkPosition = subChunk
        request.positionOffsets = listOf(Vector3i.from(0, 0, 0))
        session.serverBound(request)
    }

    /** Si menos de la mitad de las secciones tiene datos, pide las subchunks de alrededor del jugador. */
    private fun maybeRequestSubChunks() {
        if (!tracking) return
        val lp = session.localPlayer
        if (lp.posX == 0f && lp.posY == 0f && lp.posZ == 0f) return
        val pcx = floor(lp.posX).toInt() shr 4
        val pcy = floor(lp.posY).toInt() shr 4
        val pcz = floor(lp.posZ).toInt() shr 4

        val chunkKey = key(pcx, pcz)
        if (chunkKey != lastFillChunk) {
            lastFillChunk = chunkKey
            fillRequestAttempts = 0
        }
        if (fillRequestAttempts > 4) return

        val now = System.currentTimeMillis()
        val wait = if (chunks.isEmpty()) 200L else if (fillRequestAttempts <= 2) 1200L else 4000L
        if (now - lastFillRequestTime < wait) return
        lastFillRequestTime = now

        var total = 0
        var real = 0
        for (c in chunks.values) {
            total += c.sections.size
            for (b in c.populated) if (b) real++
        }
        if (total > 0 && real * 100 >= total * 50) {
            fillRequestAttempts = 0
            return
        }
        fillRequestAttempts++

        val radius = viewDistance.coerceIn(1, 4)
        val minY = minSectionY(dimension)
        val maxY = minY + sectionCount(dimension) - 1
        val offsets = ArrayList<Vector3i>()
        for (dx in -radius..radius) {
            for (dz in -radius..radius) {
                for (dy in (minY - pcy)..(maxY - pcy)) {
                    offsets.add(Vector3i.from(dx, dy, dz))
                }
            }
        }
        if (offsets.isEmpty()) return
        offsets.sortBy { it.x * it.x + it.y * it.y + it.z * it.z }
        val limited = if (offsets.size > 512) ArrayList(offsets.subList(0, 512)) else offsets

        val request = SubChunkRequestPacket()
        request.dimension = dimension
        request.subChunkPosition = Vector3i.from(pcx, pcy, pcz)
        request.positionOffsets = limited
        session.serverBound(request)
        Log.i("KiwiWorld", "Mundo poco lleno ($real/$total secciones); pidiendo ${limited.size} subchunks alrededor del jugador")
    }

    /** Seccion de puro aire con el runtime id de aire real (con IDs hasheados el aire no es 0). */
    private fun airSection(section: ChunkSection) {
        section.storage = BlockStorage(BitArrayVersion.V2, session.blockMapping.airId)
    }

    // ------------------------------------------------------------------ entidades

    fun playersNear(range: Float): List<Player> {
        val lp = session.localPlayer
        val r2 = range * range
        return session.level.entityMap.values
            .filterIsInstance<Player>()
            .filter { it !== lp && it.distanceSq(lp) <= r2 }
    }

    fun crystalsNear(range: Float): List<EntityUnknown> {
        val lp = session.localPlayer
        val r2 = range * range
        return session.level.entityMap.values
            .filterIsInstance<EntityUnknown>()
            .filter { it.identifier == CRYSTAL_ID && it.distanceSq(lp) <= r2 }
    }

    /** true si hay un cristal cuya celda de soporte (bloque bajo el) es [support]. */
    fun crystalExistsAtSupport(support: Vector3i): Boolean =
        session.level.entityMap.values.any {
            it is EntityUnknown && it.identifier == CRYSTAL_ID &&
                floor(it.posX).toInt() == support.x &&
                floor(it.posY - 1.0f).toInt() == support.y &&
                floor(it.posZ).toInt() == support.z
        }

    // ------------------------------------------------------------------ explosiones

    private val occlusionCache = ConcurrentHashMap<Int, Boolean>()

    /** 0 = sin calcular, 1 = ocluye, 2 = no ocluye. Indexada por runtime id: sin boxing ni hashing. */
    private val occlusionTable = ByteArray(OCCLUSION_TABLE_SIZE)

    fun clearOcclusionCache() {
        occlusionCache.clear()
        java.util.Arrays.fill(occlusionTable, 0.toByte())
    }

    /** Dano que recibiria [entity] por una explosion de tamano [size] centrada en [center]. */
    fun explosionDamageTo(center: Vector3f, entity: Entity, size: Float = 12f, coarse: Boolean = false): Float {
        var result = 0f
        evalExplosionDamage(entity, center, size, 4f * size * size, coarse) { _, d -> result = d }
        return result
    }

    fun simulateExplosionDamage(
        center: Vector3f,
        size: Float,
        extraEntities: List<Entity> = emptyList(),
        coarse: Boolean = false,
        damageCallback: (Entity, Float) -> Unit
    ) {
        val searchSq = 4f * size * size
        for (e in session.level.entityMap.values) evalExplosionDamage(e, center, size, searchSq, coarse, damageCallback)
        for (e in extraEntities) evalExplosionDamage(e, center, size, searchSq, coarse, damageCallback)
    }

    private fun evalExplosionDamage(
        entity: Entity, center: Vector3f, size: Float, searchSq: Float, coarse: Boolean,
        cb: (Entity, Float) -> Unit
    ) {
        val x = entity.posX - center.x
        val y = session.entityFeetY(entity) - center.y
        val z = entity.posZ - center.z
        val d2 = x * x + y * y + z * z
        if (d2 >= searchSq) return
        val dist = sqrt(d2) / size
        if (dist > 1f) return

        val impact = (1f - dist) * explosionExposure(center, entity, coarse)
        var dmg = ((impact * impact + impact) * 0.5f * size * 8f) + 1f

        val armor = (entity.attributes["minecraft:armor"]?.value ?: 0f).coerceIn(0f, 30f)
        if (armor > 0f) {
            val a = dmg - armor * dmg * 0.04f
            dmg = a - min(ceil(min(ceil(armor / 4f) * 5f, 25f) * 0.5f), 20f) * a * 0.04f
        }
        cb(entity, max(0f, dmg))
    }

    private fun explosionExposure(center: Vector3f, entity: Entity, coarse: Boolean): Float {
        val feetY = session.entityFeetY(entity)
        val isPlayer = entity is Player
        val halfW = if (isPlayer) entity.hitboxWidth() * 0.5f else 0.3f
        val h = if (isPlayer) entity.hitboxHeight() else 1.8f
        val minX = entity.posX - halfW
        val maxX = entity.posX + halfW
        val maxY = feetY + h
        val minZ = entity.posZ - halfW
        val maxZ = entity.posZ + halfW
        val steps = if (coarse) COARSE_STEPS else SAMPLE_STEPS
        var total = 0
        var free = 0
        for (sx in steps) for (sy in steps) for (sz in steps) {
            total++
            if (!rayBlocked(center, minX + (maxX - minX) * sx, feetY + (maxY - feetY) * sy, minZ + (maxZ - minZ) * sz)) free++
        }
        return if (total == 0) 1f else free.toFloat() / total
    }

    /** DDA voxel desde [from] hasta el punto; true si atraviesa un bloque que ocluye. */
    private fun rayBlocked(from: Vector3f, toX: Float, toY: Float, toZ: Float): Boolean {
        var bx = floor(from.x).toInt()
        var by = floor(from.y).toInt()
        var bz = floor(from.z).toInt()
        val ex = floor(toX).toInt()
        val ey = floor(toY).toInt()
        val ez = floor(toZ).toInt()
        if (bx == ex && by == ey && bz == ez) return false

        val dx = toX - from.x
        val dy = toY - from.y
        val dz = toZ - from.z
        val sx = if (dx > 0f) 1 else -1
        val sy = if (dy > 0f) 1 else -1
        val sz = if (dz > 0f) 1 else -1
        val tdx = if (dx == 0f) Float.MAX_VALUE else Math.abs(1f / dx)
        val tdy = if (dy == 0f) Float.MAX_VALUE else Math.abs(1f / dy)
        val tdz = if (dz == 0f) Float.MAX_VALUE else Math.abs(1f / dz)
        var tx = if (dx == 0f) Float.MAX_VALUE else (if (dx > 0f) (bx + 1f) - from.x else from.x - bx) * tdx
        var ty = if (dy == 0f) Float.MAX_VALUE else (if (dy > 0f) (by + 1f) - from.y else from.y - by) * tdy
        var tz = if (dz == 0f) Float.MAX_VALUE else (if (dz > 0f) (bz + 1f) - from.z else from.z - bz) * tdz

        var guard = 0
        while (guard++ < 96) {
            if (bx == ex && by == ey && bz == ez) return false
            if (occludes(bx, by, bz)) return true
            if (tx <= ty && tx <= tz) { bx += sx; tx += tdx }
            else if (ty <= tz) { by += sy; ty += tdy }
            else { bz += sz; tz += tdz }
        }
        return false
    }

    /**
     * Runtime id del bloque en (x, y, z), o UNKNOWN_BLOCK si no se conoce. Equivale a
     * isBlockKnown + getBlockRuntimeId pero con UNA sola consulta al mapa de chunks y sin crear un
     * Vector3i por voxel (el DDA de las explosiones recorre decenas de miles de voxeles por tick).
     */
    private fun blockOrUnknown(x: Int, y: Int, z: Int): Int {
        val chunk = chunks[key(x shr 4, z shr 4)]
        if (chunk != null) {
            val idx = chunk.index(y)
            if (idx in chunk.sections.indices && chunk.populated[idx]) {
                return try {
                    chunk.sections[idx].getBlock(x and 15, y and 15, z and 15)
                } catch (_: Exception) {
                    blockMap[Vector3i.from(x, y, z)] ?: session.blockMapping.airId
                }
            }
        }
        return blockMap[Vector3i.from(x, y, z)] ?: UNKNOWN_BLOCK
    }

    private fun occludes(x: Int, y: Int, z: Int): Boolean {
        val rid = blockOrUnknown(x, y, z)
        if (rid == UNKNOWN_BLOCK) return false
        if (rid == 0 || rid == session.blockMapping.airId) return false
        return occludesRid(rid)
    }

    private fun occludesRid(rid: Int): Boolean {
        if (rid >= 0 && rid < OCCLUSION_TABLE_SIZE) {
            val cached = occlusionTable[rid].toInt()
            if (cached != 0) return cached == 1
            val computed = computeOcclusion(rid)
            occlusionTable[rid] = (if (computed) 1 else 2).toByte()
            return computed
        }
        return occlusionCache.computeIfAbsent(rid) { computeOcclusion(rid) }
    }

    private fun computeOcclusion(rid: Int): Boolean =
        try {
            session.blockMapping.getDefinition(rid).identifier !in NON_OCCLUDING
        } catch (_: Exception) {
            true
        }

    companion object {
        private const val BLOCK_REQUEST_THROTTLE_MS = 350L
        private const val MAX_PENDING_PARSES = 400
        const val CRYSTAL_ID = "minecraft:ender_crystal"
        private const val UNKNOWN_BLOCK = Int.MIN_VALUE
        private const val OCCLUSION_TABLE_SIZE = 16384
        private val SAMPLE_STEPS = floatArrayOf(0f, 0.5f, 1f)
        private val COARSE_STEPS = floatArrayOf(0f, 1f)
        private val NON_OCCLUDING = setOf(
            "minecraft:air", "minecraft:water", "minecraft:flowing_water", "minecraft:lava",
            "minecraft:flowing_lava", "minecraft:tallgrass", "minecraft:double_plant",
            "minecraft:short_grass", "minecraft:fern", "minecraft:dead_bush", "minecraft:snow_layer",
            "minecraft:torch", "minecraft:wall_torch", "minecraft:redstone_wire", "minecraft:rail",
            "minecraft:powered_rail", "minecraft:detector_rail", "minecraft:activator_rail",
            "minecraft:vine", "minecraft:glow_lichen", "minecraft:structure_void", "minecraft:scaffolding",
            "minecraft:chain", "minecraft:iron_bars", "minecraft:glass_pane", "minecraft:tripwire",
            "minecraft:tripwire_hook", "minecraft:light_weighted_pressure_plate",
            "minecraft:heavy_weighted_pressure_plate", "minecraft:stone_pressure_plate",
            "minecraft:wooden_pressure_plate", "minecraft:sign", "minecraft:wall_sign",
            "minecraft:standing_sign", "minecraft:banner", "minecraft:wall_banner",
            "minecraft:item_frame", "minecraft:painting", "minecraft:lever", "minecraft:stone_button",
            "minecraft:wooden_button", "minecraft:polished_blackstone_button"
        )
    }
}
