package com.retrivedmods.wclient.overlay.gui.classic

import android.content.res.Configuration
import android.view.WindowManager
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.retrivedmods.wclient.R
import com.retrivedmods.wclient.overlay.OverlayManager
import com.retrivedmods.wclient.overlay.OverlayWindow
import kotlin.math.min

class OverlayButton : OverlayWindow() {
    // Borde plateado (antes arcoiris): colores del logo de Abysm.
    private val rainbowColors = listOf(
        Color(0xFF6E747D),
        Color(0xFFE6E8EC),
        Color(0xFF9AA0A9),
        Color(0xFFF4F5F7),
        Color(0xFF6E747D)
    )

    private val _layoutParams by lazy {
        super.layoutParams.apply {
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            windowAnimations = android.R.style.Animation_Toast
            x = 0
            y = 100
        }
    }

    override val layoutParams: WindowManager.LayoutParams
        get() = _layoutParams

    private val overlayClickGUI by lazy { OverlayClickGUI() }

    @Composable
    override fun Content() {
        val context = LocalContext.current
        val width = context.resources.displayMetrics.widthPixels
        val height = context.resources.displayMetrics.heightPixels
        val configuration = LocalConfiguration.current
        val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        // Borde arcoiris ESTATICO: antes era una animacion infinita (un sweepGradient nuevo por
        // fotograma, para siempre, en su propia ventana) que gastaba GPU en gama baja incluso con
        // el juego en primer plano.
        val rainbowBrush = remember { Brush.sweepGradient(rainbowColors) }

        LaunchedEffect(isLandscape) {
            _layoutParams.x = min(width, _layoutParams.x)
            _layoutParams.y = min(height, _layoutParams.y)
            windowManager.updateViewLayout(composeView, _layoutParams)
        }

        val buttonShape = RoundedCornerShape(6.dp)
        Box(
            modifier = Modifier
                .padding(5.dp)
                .size(60.dp)
                .clip(buttonShape)
                .background(Color(0xFF111114))
                .drawBehind {
                    val borderWidth = 3.dp.toPx()
                    drawRoundRect(
                        brush = rainbowBrush,
                        topLeft = Offset(borderWidth / 2, borderWidth / 2),
                        size = Size(size.width - borderWidth, size.height - borderWidth),
                        cornerRadius = CornerRadius(6.dp.toPx()),
                        style = Stroke(width = borderWidth)
                    )
                }
                .pointerInput(Unit) {
                    detectDragGestures { _, drag ->
                        _layoutParams.x += drag.x.toInt()
                        _layoutParams.y += drag.y.toInt()
                        windowManager.updateViewLayout(composeView, _layoutParams)
                    }
                }
                .clickable { OverlayManager.showOverlayWindow(overlayClickGUI) },
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(R.drawable.abysm_button),
                contentDescription = "Overlay Button Icon",
                modifier = Modifier
                    .size(50.dp)
            )
        }
    }
}
