package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.friend.FriendManager
import com.retrivedmods.wclient.game.kiwi.BlockPlacer
import com.retrivedmods.wclient.game.kiwi.entityFeetY
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import kotlin.math.floor
import kotlin.math.sqrt

/**
 * HoleFill (simplificado): rellena con obsidiana los bloques de aire a los lados de los pies de
 * los enemigos cercanos, para cerrar su hueco. Solo coloca dentro de tu alcance y nunca encima de
 * una entidad. No detecta huecos de cualquier forma: cubre los 4 lados a la altura de los pies.
 */
class HoleFillModule : Module("hole_fill", ModuleCategory.Combat) {

    private val enemyRange by intValue("Enemy Range", 4, 2..6)
    private val placeRange by intValue("Place Range", 4, 2..6)
    private val placeDelay by intValue("Place Delay ms", 100, 0..1000)
    private val skipFriends by boolValue("Skip Friends", true)

    private var lastPlace = 0L

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet
        if (packet !is PlayerAuthInputPacket) return

        val now = System.currentTimeMillis()
        if (now - lastPlace < placeDelay) return

        val lp = session.localPlayer
        val slot = BlockPlacer.findObsidianSlot(session) ?: return
        val world = session.kiwiWorld
        val airId = session.blockMapping.airId

        val enemies = session.level.entityMap.values.toList()
            .filterIsInstance<Player>()
            .filter { it.runtimeEntityId != lp.runtimeEntityId }
            .filter { !(skipFriends && FriendManager.isFriend(it.uuid)) }
            .filter { distance(it.posX, it.posZ, lp.posX, lp.posZ) <= enemyRange }

        val cells = enemies.flatMap { p ->
            val fx = floor(p.posX).toInt()
            val fy = floor(session.entityFeetY(p)).toInt()
            val fz = floor(p.posZ).toInt()
            listOf(
                Vector3i.from(fx + 1, fy, fz), Vector3i.from(fx - 1, fy, fz),
                Vector3i.from(fx, fy, fz + 1), Vector3i.from(fx, fy, fz - 1)
            )
        }.distinct()
            .filter { world.isBlockKnown(it) && (world.getBlockRuntimeId(it) == 0 || world.getBlockRuntimeId(it) == airId) }
            .filter { !BlockPlacer.anyEntityInCell(session, it) }
            .filter { distance(it.x + 0.5f, it.z + 0.5f, lp.posX, lp.posZ) <= placeRange }
            .sortedBy { distance(it.x + 0.5f, it.z + 0.5f, lp.posX, lp.posZ) }

        val cell = cells.firstOrNull() ?: return

        val held = lp.inventory.heldItemSlot
        BlockPlacer.sendServerSlot(session, slot)
        val ok = BlockPlacer.tryPlaceWithSupport(session, cell, slot, 8.0f, "minecraft:obsidian", 4)
        BlockPlacer.sendServerSlot(session, held)
        if (ok) lastPlace = now
    }

    private fun distance(ax: Float, az: Float, bx: Float, bz: Float): Float {
        val dx = ax - bx
        val dz = az - bz
        return sqrt(dx * dx + dz * dz)
    }
}
