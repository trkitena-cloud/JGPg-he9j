package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.kiwi.FriendManager
import com.retrivedmods.wclient.game.kiwi.entityFeetY
import com.retrivedmods.wclient.game.kiwi.localEyeY
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import kotlin.math.atan2
import kotlin.math.sqrt

/**
 * RNK Aura: killaura aparte (no reemplaza a Kiwi Killaura).
 *  - Ataca hasta "Max Targets" jugadores en rango, el mas cercano primero.
 *  - "Lock On": mantiene el objetivo principal mientras siga en rango (no salta entre jugadores).
 *  - Apunta con prediccion de movimiento ("Predict" = ticks por delante) a cabeza/cuerpo/pies.
 *  - CPS y paquetes por golpe configurables.
 */
class RnkAuraModule : Module("RNK Aura", ModuleCategory.Combat) {

    private val range by floatValue("Range", 6.0f, 2.0f..12.0f)
    private val cps by intValue("CPS", 16, 1..30)
    private val maxTargets by intValue("Max Targets", 3, 1..8)
    private val packets by intValue("Packets", 1, 1..5)
    private val aim by stringValue("Aim", "Body", listOf("Head", "Body", "Feet"))
    private val predict by floatValue("Predict", 1.0f, 0.0f..4.0f)
    // Learn Motion: aprende como se mueve el objetivo (quieto, linea recta o dando vueltas a tu
    // alrededor) y apunta hacia donde ESTARA, no donde esta.
    private val learnMotion by boolValue("Learn Motion", true)
    private val leadTicks by floatValue("Lead Ticks", 2.0f, 0.0f..6.0f)
    private val lockOn by boolValue("Lock On", true)
    private val antiBot by boolValue("Anti Bot", true)

    private var lastAttackTime = 0L
    private var locked: Player? = null

    private class Track {
        var has = false
        var lx = 0f
        var lz = 0f
        var lt = 0L
        var vx = 0f          // velocidad (bloques por tick)
        var vz = 0f
        var omega = 0f       // velocidad angular alrededor de ti (rad por tick)
        var radius = 0f
        var lastAngle = 0f
    }

    private val tracks = HashMap<Long, Track>()

    override fun onEnabled() {
        super.onEnabled()
        lastAttackTime = 0L
        locked = null
        tracks.clear()
    }

    override fun onDisabled() {
        super.onDisabled()
        locked = null
        tracks.clear()
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet
        if (packet !is PlayerAuthInputPacket) return

        val lp = session.localPlayer
        val targets = session.level.entityMap.values
            .filterIsInstance<Player>()
            .filter { isValid(it, lp) }
            .sortedBy { it.distance(lp) }
            .take(maxTargets)

        if (targets.isEmpty()) {
            locked = null
            return
        }

        val current = locked
        val primary = if (lockOn && current != null && targets.any { it === current }) current else targets.first()
        locked = primary

        val nowMs = System.currentTimeMillis()
        if (learnMotion) {
            val ids = targets.map { it.runtimeEntityId }.toSet()
            tracks.keys.retainAll(ids)
            for (t in targets) updateTrack(t, lp, nowMs)
        }

        // --- rotacion hacia el objetivo principal (con prediccion)
        val feet = session.entityFeetY(primary)
        val aimY = when (aim) {
            "Feet" -> feet + 0.1f
            "Head" -> feet + 1.5f
            else -> feet + 0.9f
        } + (primary.motionY * predict).coerceIn(-1f, 1f)
        var tx = primary.posX + primary.motionX * predict
        var tz = primary.posZ + primary.motionZ * predict
        if (learnMotion) {
            val pred = predictLearned(primary, lp)
            tx = pred.first
            tz = pred.second
        }
        val dx = tx - lp.posX
        val dy = aimY - session.localEyeY()
        val dz = tz - lp.posZ
        val horizontal = sqrt(dx * dx + dz * dz)
        val yaw = Math.toDegrees(atan2(-dx.toDouble(), dz.toDouble())).toFloat()
        val pitch = (-Math.toDegrees(atan2(dy.toDouble(), horizontal.toDouble()))).toFloat()
        packet.rotation = Vector3f.from(pitch, yaw, yaw)

        // --- ataque segun CPS
        val now = System.currentTimeMillis()
        if (now - lastAttackTime < 1000L / cps) return
        for (t in targets) {
            repeat(packets) { lp.attack(t) }
        }
        lastAttackTime = now
    }

    /** Actualiza la velocidad lineal y angular (alrededor de ti) del objetivo con suavizado. */
    private fun updateTrack(e: Player, lp: LocalPlayer, now: Long) {
        val t = tracks.getOrPut(e.runtimeEntityId) { Track() }
        val ang = atan2((e.posZ - lp.posZ).toDouble(), (e.posX - lp.posX).toDouble()).toFloat()
        val dist = e.distance(lp)
        if (!t.has) {
            t.has = true
            t.lx = e.posX
            t.lz = e.posZ
            t.lt = now
            t.lastAngle = ang
            t.radius = dist
            return
        }
        val dtTicks = (now - t.lt) / 50f
        val moved = e.posX != t.lx || e.posZ != t.lz
        if (moved && dtTicks > 0.5f) {
            val ivx = (e.posX - t.lx) / dtTicks
            val ivz = (e.posZ - t.lz) / dtTicks
            t.vx += (ivx - t.vx) * 0.5f
            t.vz += (ivz - t.vz) * 0.5f
            var d = ang - t.lastAngle
            while (d > Math.PI) d -= (2 * Math.PI).toFloat()
            while (d < -Math.PI) d += (2 * Math.PI).toFloat()
            t.omega += (d / dtTicks - t.omega) * 0.4f
            t.radius += (dist - t.radius) * 0.5f
            t.lastAngle = ang
            t.lx = e.posX
            t.lz = e.posZ
            t.lt = now
        } else if (!moved && dtTicks > 3f) {
            // Se quedo quieto: olvida el movimiento
            t.vx = 0f
            t.vz = 0f
            t.omega = 0f
        }
    }

    /**
     * Posicion (x, z) donde estara el objetivo dentro de "Lead Ticks":
     *  - quieto -> donde esta
     *  - dando vueltas a tu alrededor -> sigue el arco (angulo + omega * ticks, mismo radio)
     *  - en linea -> posicion + velocidad * ticks
     */
    private fun predictLearned(e: Player, lp: LocalPlayer): Pair<Float, Float> {
        val t = tracks[e.runtimeEntityId] ?: return Pair(e.posX, e.posZ)
        val speed = sqrt(t.vx * t.vx + t.vz * t.vz)
        if (speed < 0.02f) return Pair(e.posX, e.posZ)

        val lead = leadTicks
        val tangential = t.radius * kotlin.math.abs(t.omega)
        val circling = kotlin.math.abs(t.omega) > 0.04f && tangential > 0.6f * speed

        var px: Float
        var pz: Float
        if (circling) {
            val a = t.lastAngle + t.omega * lead
            px = lp.posX + t.radius * kotlin.math.cos(a.toDouble()).toFloat()
            pz = lp.posZ + t.radius * kotlin.math.sin(a.toDouble()).toFloat()
        } else {
            px = e.posX + t.vx * lead
            pz = e.posZ + t.vz * lead
        }
        // Limite: nunca se aleja mas de 3 bloques de donde esta realmente
        val ox = px - e.posX
        val oz = pz - e.posZ
        val off = sqrt(ox * ox + oz * oz)
        if (off > 3f) {
            px = e.posX + ox / off * 3f
            pz = e.posZ + oz / off * 3f
        }
        return Pair(px, pz)
    }

    private fun isValid(e: Player, lp: LocalPlayer): Boolean {
        if (e === lp || e is LocalPlayer) return false
        if (FakePlayerModule.isFake(e.uniqueEntityId)) return false
        if (FriendManager.isFriend(e.uuid)) return false
        if (e.distance(lp) > range) return false
        return !(antiBot && isBot(e))
    }

    private fun isBot(player: Player): Boolean {
        val entry = session.level.playerMap[player.uuid] ?: return true
        val name = entry.name?.toString().orEmpty()
        if (name.isBlank()) return true
        val xuid = entry.xuid.orEmpty()
        return xuid.isEmpty() || xuid == "0"
    }
}
