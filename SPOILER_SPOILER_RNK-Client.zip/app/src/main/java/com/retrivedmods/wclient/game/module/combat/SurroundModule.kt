package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.entity.Entity
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.kiwi.BlockPlacer
import com.retrivedmods.wclient.game.kiwi.ItemUseState
import com.retrivedmods.wclient.game.kiwi.adaptiveFeetY
import com.retrivedmods.wclient.game.kiwi.entityFeetY
import com.retrivedmods.wclient.game.kiwi.toRotation
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.ItemUseTransaction
import org.cloudburstmc.protocol.bedrock.packet.ChangeDimensionPacket
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.MobEquipmentPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerHotbarPacket
import org.cloudburstmc.protocol.bedrock.packet.StartGamePacket
import kotlin.math.floor

/**
 * Surround portado de KiwiMods (game/module/combat/SurroundModule).
 *
 * Rodea al jugador de obsidiana (anillo de bloques a su alrededor, sobre los pies y opcionalmente
 * "anti anclas": una segunda altura y un techo). Si hay un jugador pegado a tu bloque, el anillo
 * se agranda para cubrirlo. Con "Crystal Check" golpea los cristales que aparezcan cerca.
 *
 * Modos: SURROUND (anillo de bloques) y BUTTON (un boton sobre los pies).
 * Switch: MANUAL (cambia el slot visible), SILENT (solo el servidor) o PACKET.
 */
class SurroundModule : Module("surround", ModuleCategory.Combat) {

    enum class SurroundMode { SURROUND, BUTTON }
    enum class SwitchMode { MANUAL, SILENT, PACKET }

    private val placeDelay by intValue("Place Delay", 0, 0..20)
    private val placePerTick by intValue("Place Per Tick", 4, 1..10)
    private val instant by boolValue("Instant", true)
    private val failTimeout by intValue("Fail Timeout", 10, 0..30)
    private val supportFallback by boolValue("Support Fallback", true)
    private val antiAA by boolValue("Anti AA", true)
    private val antiAAHeight by intValue("Anti AA Height", 2, 1..3)
    private val antiAARoof by boolValue("Anti AA Roof", true)
    private val crystalCheck by boolValue("Crystal Check", true)
    private val sortMode by intValue("Sort Mode", 0, 0..2)
    private val rotate by boolValue("Rotate", true)
    private val center by boolValue("Center", true)
    private val disableOnJump by boolValue("Disable On Jump", true)
    private val blockType by intValue("Block Type", 0, 0..2)
    private val debug by boolValue("Debug", false)
    private val nukkitAABB by boolValue("Nukkit AABB", true)
    private val yOffset by floatValue("Y Offset", -1.62f, -3.0f..0.0f)
    private val switchMode by enumValue("Switch", SwitchMode.MANUAL, SwitchMode::class.java)
    private val mode by enumValue("Mode", SurroundMode.SURROUND, SurroundMode::class.java)
    private val eatStop by boolValue("Eat Stop", false)

    private val blockIdentifiers = listOf("minecraft:obsidian", "minecraft:crying_obsidian", "minecraft:ancient_debris")

    private val interactiveBlocks = setOf(
        "minecraft:chest", "minecraft:trapped_chest", "minecraft:ender_chest", "minecraft:furnace",
        "minecraft:blast_furnace", "minecraft:smoker", "minecraft:hopper", "minecraft:dropper",
        "minecraft:dispenser", "minecraft:crafting_table", "minecraft:anvil", "minecraft:chipped_anvil",
        "minecraft:damaged_anvil", "minecraft:enchanting_table", "minecraft:barrel", "minecraft:shulker_box",
        "minecraft:undyed_shulker_box", "minecraft:brewing_stand", "minecraft:beacon", "minecraft:noteblock",
        "minecraft:jukebox", "minecraft:daylight_detector", "minecraft:daylight_detector_inverted",
        "minecraft:composter", "minecraft:loom", "minecraft:cartography_table", "minecraft:fletching_table",
        "minecraft:smithing_table", "minecraft:grindstone", "minecraft:stonecutter_block", "minecraft:bell",
        "minecraft:lectern"
    )

    private val placeList = ArrayList<Vector3i>()
    private val ringPositions = ArrayList<Vector3i>()
    private var lastPlayerPos: Vector3i = Vector3i.from(Int.MAX_VALUE, 0, 0)
    private var needsRecalc = true
    private var wasSurrounding = false
    private var tickCounter = 0
    private var lastPlaceTime = 0L
    private var lastRecalcAttempt = 0L
    private val lastPlaceAttempt = HashMap<Vector3i, Long>()
    private val failMap = HashMap<Vector3i, Int>()
    private val crystalHitTick = HashMap<Long, Int>()

    /** onEnabled/onDisabled corren en el hilo de la interfaz: el estado se limpia en el siguiente tick. */
    @Volatile
    private var pendingReset = true

    private class Box(
        val minX: Float, val minY: Float, val minZ: Float,
        val maxX: Float, val maxY: Float, val maxZ: Float
    ) {
        fun intersects(o: Box): Boolean =
            minX < o.maxX && maxX > o.minX && minY < o.maxY && maxY > o.minY && minZ < o.maxZ && maxZ > o.minZ
    }

    private class Support(val face: Int, val pos: Vector3i, val assumed: Boolean)

    override fun onEnabled() {
        super.onEnabled()
        pendingReset = true
    }

    override fun onDisabled() {
        super.onDisabled()
        pendingReset = true
    }

    private fun resetState() {
        placeList.clear()
        ringPositions.clear()
        lastPlayerPos = Vector3i.from(Int.MAX_VALUE, 0, 0)
        needsRecalc = true
        wasSurrounding = false
        tickCounter = 0
        lastPlaceTime = 0L
        lastRecalcAttempt = 0L
        lastPlaceAttempt.clear()
        failMap.clear()
        crystalHitTick.clear()
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        when (val packet = interceptablePacket.packet) {
            is PlayerAuthInputPacket -> onTick(packet)
            is StartGamePacket, is ChangeDimensionPacket -> pendingReset = true
            else -> Unit
        }
    }

    // ------------------------------------------------------------------ utilidades

    private fun blockIdentifier(): String = blockIdentifiers[blockType.coerceIn(0, 2)]

    private fun isButtonItem(identifier: String): Boolean = identifier.contains("button")

    private fun feetY(player: LocalPlayer): Float =
        session.adaptiveFeetY(player.posY, floor(player.posX).toInt(), floor(player.posZ).toInt(), true, yOffset)

    /** Celda de los pies. El pequeno margen evita que 63.99999 (error de coma flotante) cuente como el bloque de abajo. */
    private fun feetCell(player: LocalPlayer): Vector3i =
        Vector3i.from(floor(player.posX).toInt(), floor(feetY(player) + 0.01f).toInt(), floor(player.posZ).toInt())

    private fun isAirId(rid: Int): Boolean = rid == 0 || rid == session.blockMapping.airId

    /** Bloque conocido y que no es aire. */
    private fun isKnownSolid(pos: Vector3i): Boolean {
        val world = session.kiwiWorld
        return world.isBlockKnown(pos) && !isAirId(world.getBlockRuntimeId(pos))
    }

    private fun blockWidth(): Float = if (nukkitAABB) 0.32f else 0.3f

    private fun blockBox(pos: Vector3i) =
        Box(pos.x.toFloat(), pos.y.toFloat(), pos.z.toFloat(), pos.x + 1f, pos.y + 1f, pos.z + 1f)

    private fun playerBox(player: LocalPlayer, feet: Float): Box {
        val w = blockWidth()
        return Box(player.posX - w, feet, player.posZ - w, player.posX + w, feet + 1.8f, player.posZ + w)
    }

    private fun entityBox(entity: Entity): Box {
        val w = blockWidth()
        val feet = session.entityFeetY(entity)
        val box = Box(entity.posX - w, feet, entity.posZ - w, entity.posX + w, feet + 1.8f, entity.posZ + w)
        if (entity !is Player) return box
        val f = if (nukkitAABB) 0.1f else 0.05f
        return Box(box.minX - f, box.minY, box.minZ - f, box.maxX + f, box.maxY, box.maxZ + f)
    }

    private fun distSq(cx: Float, cy: Float, cz: Float, p: Vector3i): Float {
        val dx = p.x - cx
        val dy = p.y - cy
        val dz = p.z - cz
        return dx * dx + dy * dy + dz * dz
    }

    // ------------------------------------------------------------------ tick

    private fun onTick(input: PlayerAuthInputPacket) {
        if (pendingReset) {
            pendingReset = false
            resetState()
        }
        val player = session.localPlayer
        val now = System.currentTimeMillis()

        if (disableOnJump && (input.inputData.contains(PlayerAuthInputData.JUMPING) || player.motionY > 0.01f)) {
            isEnabled = false
            return
        }
        if (eatStop && ItemUseState.using) return
        if (crystalCheck) attackCrystals(player)
        if (now - lastPlaceTime < placeDelay * 50L) return

        val slot: Int? = if (mode == SurroundMode.BUTTON) {
            val handId = player.inventory.hand.definition?.identifier ?: ""
            if (isButtonItem(handId) || handId == blockIdentifier()) -1 else findPlaceSlot()
        } else {
            findPlaceSlot()
        }
        if (slot == null) {
            if (debug) session.displayClientMessage("\u00a77[Surround] No hay obsidiana en la barra!")
            return
        }

        if (center) {
            val cell = feetCell(player)
            val cx = cell.x + 0.5f
            val cz = cell.z + 0.5f
            if (player.distance(Vector3f.from(cx, player.posY, cz)) >= 0.1f) {
                player.move(cx, player.posY, cz)
            }
        }

        val cell = feetCell(player)
        if (cell.x != lastPlayerPos.x || cell.z != lastPlayerPos.z) {
            lastPlayerPos = cell
            needsRecalc = true
        }
        if ((needsRecalc || placeList.isEmpty()) && now - lastRecalcAttempt >= RECALC_THROTTLE_MS) {
            lastRecalcAttempt = now
            calculatePlaceList(player)
            if (debug) {
                val sample = placeList.take(8).joinToString(" ") { "(${it.x},${it.y},${it.z})" }
                session.displayClientMessage("\u00a77[Surround] pies=${cell.y} lista(${placeList.size}): $sample")
            }
        }

        // Reponer los bloques del anillo que se hayan roto.
        for (pos in ringPositions) {
            if (canPlace(pos) && pos !in placeList) {
                val last = lastPlaceAttempt[pos] ?: 0L
                if (now - last >= PLACE_RETRY_MS) placeList.add(pos)
            }
        }

        if (placeList.isEmpty()) {
            if (wasSurrounding && debug) session.displayClientMessage("\u00a77[Surround] Completo!")
            wasSurrounding = false
            return
        }

        val done = HashSet<Vector3i>()
        var placed = 0
        for (pos in placeList) {
            if (!instant && placed >= placePerTick) break
            if (failTimeout > 0 && (failMap[pos] ?: 0) >= failTimeout) {
                done.add(pos) // se rinde con esta posicion
                continue
            }
            val last = lastPlaceAttempt[pos] ?: 0L
            if (now - last < PLACE_RETRY_MS) continue
            if (doPlace(pos, player, input, slot)) {
                done.add(pos)
                placed++
                lastPlaceTime = now
                failMap.remove(pos)
                if (debug) session.displayClientMessage("\u00a77[Surround] colocado en (${pos.x},${pos.y},${pos.z})")
            } else {
                failMap[pos] = (failMap[pos] ?: 0) + 1
            }
        }
        placeList.removeAll(done)
        wasSurrounding = true
        if (debug && placed == 0) session.displayClientMessage("\u00a77[Surround] Ninguna colocacion valida en este tick")
    }

    private fun attackCrystals(player: LocalPlayer) {
        tickCounter++
        for (crystal in session.kiwiWorld.crystalsNear(4.0f)) {
            val last = crystalHitTick[crystal.runtimeEntityId] ?: -1000
            if (tickCounter - last >= 10) {
                crystalHitTick[crystal.runtimeEntityId] = tickCounter
                player.attack(crystal)
            }
        }
    }

    // ------------------------------------------------------------------ lista de posiciones

    private fun calculatePlaceList(player: LocalPlayer) {
        placeList.clear()
        val feet = feetY(player)
        val pBox = playerBox(player, feet)
        val centerX = (pBox.minX + pBox.maxX) / 2f
        val centerZ = (pBox.minZ + pBox.maxZ) / 2f
        val minY = pBox.minY
        val world = session.kiwiWorld

        var base = Vector3i.from(floor(centerX).toInt(), floor(minY + 0.01f).toInt(), floor(centerZ).toInt())

        if (mode == SurroundMode.BUTTON) {
            if (canPlace(base)) placeList.add(base)
            ringPositions.clear()
            ringPositions.addAll(placeList)
            lastPlayerPos = Vector3i.from(floor(player.posX).toInt(), base.y, floor(player.posZ).toInt())
            needsRecalc = false
            return
        }

        // Si estas dentro de un bloque (losa, nieve...) sube hasta la primera celda libre.
        if (isKnownSolid(base)) {
            for (up in 1 until 4) {
                val p = Vector3i.from(base.x, base.y + up, base.z)
                if (!world.isBlockKnown(p) || isAirId(world.getBlockRuntimeId(p))) {
                    base = p
                    break
                }
            }
        }
        lastPlayerPos = Vector3i.from(floor(player.posX).toInt(), base.y, floor(player.posZ).toInt())

        // El anillo crece si otro jugador esta pegado a tu bloque.
        var xMin = -1
        var xMax = 1
        var zMin = -1
        var zMax = 1
        for (other in world.playersNear(6.0f)) {
            val box = entityBox(other)
            if (box.intersects(blockBox(Vector3i.from(base.x + xMin, base.y, base.z)))) xMin--
            if (box.intersects(blockBox(Vector3i.from(base.x + xMax, base.y, base.z)))) xMax++
            if (box.intersects(blockBox(Vector3i.from(base.x, base.y, base.z + zMin)))) zMin--
            if (box.intersects(blockBox(Vector3i.from(base.x, base.y, base.z + zMax)))) zMax++
        }

        for (dx in xMin..xMax) {
            for (dz in zMin..zMax) {
                val corner = (dx == xMin || dx == xMax) && (dz == zMin || dz == zMax)
                if (corner) continue
                val interior = dx > xMin && dx < xMax && dz > zMin && dz < zMax
                if (interior) {
                    // Celda bajo los pies (suelo).
                    val under = Vector3i.from(base.x + dx, base.y - 1, base.z + dz)
                    if (canPlace(under)) placeList.add(under)
                } else {
                    val pos = Vector3i.from(base.x + dx, base.y, base.z + dz)
                    val below = Vector3i.from(pos.x, pos.y - 1, pos.z)
                    if (canPlace(pos)) placeList.add(pos) else if (canPlace(below)) placeList.add(below)
                }
            }
        }

        if (antiAA) {
            val body = playerBox(player, feet)
            for (pos in ArrayList(placeList)) {
                if (pos.y != base.y) continue
                for (h in 1..antiAAHeight) {
                    val up = Vector3i.from(pos.x, pos.y + h, pos.z)
                    if (!body.intersects(blockBox(up)) && canPlace(up)) placeList.add(up)
                }
            }
            if (antiAARoof) {
                val roof = Vector3i.from(base.x, base.y + 2, base.z)
                if (!body.intersects(blockBox(roof)) && canPlace(roof)) placeList.add(roof)
            }
        }

        when (sortMode) {
            1 -> placeList.sortWith(compareBy<Vector3i> { it.y }.thenBy { distSq(centerX, minY, centerZ, it) })
            2 -> placeList.sortWith(
                compareBy<Vector3i> { abs(it.x - base.x) + abs(it.y - base.y) + abs(it.z - base.z) }
                    .thenBy { distSq(centerX, minY, centerZ, it) }
            )
            else -> if (placeList.size > 1) placeList.sortBy { distSq(centerX, minY, centerZ, it) }
        }

        ringPositions.clear()
        ringPositions.addAll(placeList)
        needsRecalc = false
    }

    private fun abs(v: Int): Int = if (v < 0) -v else v

    /** Celda libre (aire) o desconocida pero con un apoyo desde el que colocar. */
    private fun canPlace(pos: Vector3i): Boolean {
        val world = session.kiwiWorld
        if (world.isBlockKnown(pos)) return isAirId(world.getBlockRuntimeId(pos))
        world.requestBlockData(pos)
        return findSupport(pos) != null
    }

    private fun isInteractiveBlock(pos: Vector3i): Boolean {
        val world = session.kiwiWorld
        if (!world.isBlockKnown(pos)) return false
        val rid = world.getBlockRuntimeId(pos)
        if (isAirId(rid)) return false
        return world.getBlockDefinition(pos).identifier in interactiveBlocks
    }

    /**
     * Bloque contiguo sobre el que hacer clic para colocar en [pos]. Si el de abajo aun no se conoce se pide
     * al servidor y se asume que existe ("apoyo asumido"), como hace Kiwi.
     */
    private fun findSupport(pos: Vector3i): Support? {
        val world = session.kiwiWorld
        val below = Vector3i.from(pos.x, pos.y - 1, pos.z)
        if (isKnownSolid(below) && !isInteractiveBlock(below)) return Support(FACE_UP, below, false)
        for ((face, off) in OTHER_FACES) {
            val support = Vector3i.from(pos.x - off.x, pos.y - off.y, pos.z - off.z)
            if (isKnownSolid(support) && !isInteractiveBlock(support)) return Support(face, support, false)
        }
        if (world.isBlockKnown(below)) return null
        world.requestBlockData(below)
        return Support(FACE_UP, below, true)
    }

    // ------------------------------------------------------------------ colocacion

    private fun doPlace(target: Vector3i, player: LocalPlayer, input: PlayerAuthInputPacket, slot: Int): Boolean {
        val world = session.kiwiWorld
        if (world.isBlockKnown(target) && !isAirId(world.getBlockRuntimeId(target))) return false
        if (mode == SurroundMode.BUTTON) return doPlaceButton(target, player, input, slot)

        val support = findSupport(target)
        if (support == null) {
            if (supportFallback) {
                val held = player.inventory.heldItemSlot
                val useSlot = if (slot != -1) slot else held
                if (slot != -1 && sendSwap(slot) == null) return false
                val ok = BlockPlacer.tryPlaceWithSupport(session, target, useSlot, 8.0f, blockIdentifier(), 4)
                if (slot != -1) sendSwap(held)
                if (ok) {
                    lastPlaceAttempt[target] = System.currentTimeMillis()
                    return true
                }
            }
            if (debug) session.displayClientMessage("\u00a77[Surround] Sin bloque de apoyo para (${target.x},${target.y},${target.z})")
            return false
        }

        lastPlaceAttempt[target] = System.currentTimeMillis()
        val held = player.inventory.heldItemSlot
        val useSlot = if (slot != -1) slot else held
        val item: ItemData? = if (slot != -1) sendSwap(slot) else player.inventory.hand
        if (item == null) {
            if (debug) session.displayClientMessage("\u00a77[Surround] el slot $useSlot esta vacio")
            return false
        }
        val ok = doPlacement(target, support, player, input, useSlot, item)
        if (slot != -1) sendSwap(held)
        return ok
    }

    private fun aimAt(player: LocalPlayer, input: PlayerAuthInputPacket, x: Float, y: Float, z: Float) {
        if (!rotate) return
        val eye = Vector3f.from(player.posX, feetY(player) + 1.62f, player.posZ)
        val rotation = toRotation(eye, Vector3f.from(x, y, z))
        input.rotation = Vector3f.from(rotation.pitch, rotation.yaw, rotation.yaw)
    }

    private fun doPlacement(
        target: Vector3i, support: Support, player: LocalPlayer, input: PlayerAuthInputPacket,
        activeSlot: Int, item: ItemData
    ): Boolean {
        aimAt(player, input, target.x + 0.5f, target.y + 0.5f, target.z + 0.5f)

        val world = session.kiwiWorld
        var definition = world.knownDefinition(support.pos)
        if (definition == null) world.requestBlockData(support.pos)
        if (definition == null) definition = session.blockMapping.definitionByIdentifier("minecraft:obsidian")
        if (debug) {
            session.displayClientMessage(
                "\u00a77[Surround] coloca en (${target.x},${target.y},${target.z}) cara=${support.face} " +
                    "apoyo=(${support.pos.x},${support.pos.y},${support.pos.z}) asumido=${support.assumed}"
            )
        }
        if (!support.assumed) world.registerPlacement(target, blockIdentifier())

        session.serverBound(InventoryTransactionPacket().apply {
            transactionType = InventoryTransactionType.ITEM_USE
            actionType = 0
            blockPosition = support.pos
            blockFace = support.face
            hotbarSlot = activeSlot
            itemInHand = item
            playerPosition = player.vec3Position
            clickPosition = Vector3f.from(0.5f, 0.5f, 0.5f)
            blockDefinition = definition
            triggerType = ItemUseTransaction.TriggerType.PLAYER_INPUT
            clientInteractPrediction = ItemUseTransaction.PredictedResult.SUCCESS
        })
        player.swing()
        return true
    }

    private fun doPlaceButton(target: Vector3i, player: LocalPlayer, input: PlayerAuthInputPacket, slot: Int): Boolean {
        val world = session.kiwiWorld
        val under = Vector3i.from(target.x, target.y - 1, target.z)
        if (!world.isBlockKnown(under)) {
            world.requestBlockData(under)
            return false
        }
        if (isAirId(world.getBlockRuntimeId(under))) return false

        val held = player.inventory.heldItemSlot
        val useSlot = if (slot != -1) slot else held
        val item: ItemData = (if (slot != -1) sendSwap(slot) else player.inventory.hand) ?: return false

        aimAt(player, input, under.x + 0.5f, under.y + 1.0f, under.z + 0.5f)

        val itemId = item.definition?.identifier ?: return false
        val definition = world.knownDefinition(under) ?: session.blockMapping.definitionByIdentifier(itemId) ?: return false
        world.registerPlacement(target, itemId)

        session.serverBound(InventoryTransactionPacket().apply {
            transactionType = InventoryTransactionType.ITEM_USE
            actionType = 0
            blockPosition = under
            blockFace = FACE_UP
            hotbarSlot = useSlot
            itemInHand = item
            playerPosition = player.vec3Position
            clickPosition = Vector3f.from(0.5f, 1.0f, 0.5f)
            blockDefinition = definition
            triggerType = ItemUseTransaction.TriggerType.PLAYER_INPUT
            clientInteractPrediction = ItemUseTransaction.PredictedResult.SUCCESS
        })
        player.swing()
        if (slot != -1) sendSwap(held)
        return true
    }

    // ------------------------------------------------------------------ slots

    private fun findPlaceSlot(): Int? {
        val inv = session.localPlayer.inventory
        for (i in 0 until 9) {
            val item = inv.content[i]
            if (item.count <= 0) continue
            val id = item.definition?.identifier ?: continue
            val matches = if (mode == SurroundMode.BUTTON) isButtonItem(id) else id == blockIdentifier()
            if (matches) return i
        }
        return null
    }

    /** Cambia a [slot] segun el modo de cambio. Devuelve el item de ese slot, o null si esta vacio. */
    private fun sendSwap(slot: Int): ItemData? {
        val player = session.localPlayer
        val item = player.inventory.content.getOrNull(slot) ?: return null
        if (item.count <= 0) return null
        if (switchMode != SwitchMode.PACKET && player.inventory.heldItemSlot == slot) return item
        if (switchMode != SwitchMode.PACKET) player.inventory.heldItemSlot = slot
        if (switchMode == SwitchMode.MANUAL) {
            session.clientBound(PlayerHotbarPacket().apply {
                selectedHotbarSlot = slot
                containerId = 0
                selectHotbarSlot = true
            })
        }
        session.serverBound(MobEquipmentPacket().apply {
            runtimeEntityId = player.runtimeEntityId
            this.item = item
            inventorySlot = slot
            hotbarSlot = slot
        })
        return item
    }

    private companion object {
        const val RECALC_THROTTLE_MS = 50L
        const val PLACE_RETRY_MS = 50L
        const val FACE_UP = 1

        /** Caras distintas de UP con su desplazamiento: DOWN, NORTH, SOUTH, WEST, EAST (orden de Kiwi). */
        val OTHER_FACES: List<Pair<Int, Vector3i>> = listOf(
            0 to Vector3i.from(0, -1, 0),
            2 to Vector3i.from(0, 0, -1),
            3 to Vector3i.from(0, 0, 1),
            4 to Vector3i.from(-1, 0, 0),
            5 to Vector3i.from(1, 0, 0)
        )
    }
}
