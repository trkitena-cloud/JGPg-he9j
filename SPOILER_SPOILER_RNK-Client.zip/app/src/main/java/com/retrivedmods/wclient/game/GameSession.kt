package com.retrivedmods.wclient.game

import android.util.Log
import com.retrivedmods.wclient.application.AppContext
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.kiwi.KiwiWorld
import com.retrivedmods.wclient.game.registry.BlockMapping
import com.retrivedmods.wclient.game.registry.BlockMappingProvider
import com.retrivedmods.wclient.game.registry.ItemMapping
import com.retrivedmods.wclient.game.registry.ItemMappingProvider
import com.retrivedmods.wclient.game.world.Level
import com.retrivedmods.wrelay.WRelaySession
import org.cloudburstmc.protocol.bedrock.data.definitions.ItemDefinition
import org.cloudburstmc.protocol.bedrock.packet.BedrockPacket
import org.cloudburstmc.protocol.bedrock.packet.ItemComponentPacket
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.packet.StartGamePacket
import org.cloudburstmc.protocol.bedrock.packet.TextPacket
import org.cloudburstmc.protocol.common.SimpleDefinitionRegistry

@Suppress("MemberVisibilityCanBePrivate")
class GameSession(val wRelaySession: WRelaySession) : ComposedPacketHandler {

    val localPlayer = LocalPlayer(this)
    val level = Level(this)
    val kiwiWorld = KiwiWorld(this)

    val protocolVersion: Int
        get() = wRelaySession.server.codec.protocolVersion

    private val mappingProviderContext = AppContext.instance

    private val blockMappingProvider = BlockMappingProvider(mappingProviderContext).also { it.warmUpAsync() }
    private val itemMappingProvider = ItemMappingProvider(mappingProviderContext)

    lateinit var blockMapping: BlockMapping
    lateinit var itemMapping: ItemMapping

    private var startGameReceived = false

    init {
        // Los avisos de ModuleGuard tambien se copian a un archivo que se puede enviar sin adb.
        try {
            val dir = AppContext.instance.getExternalFilesDir(null) ?: AppContext.instance.filesDir
            ModuleGuard.setLogFile(java.io.File(dir, "abysm-guard.log"))
        } catch (_: Throwable) {
        }
    }

    fun clientBound(packet: BedrockPacket) {
        wRelaySession.clientBound(packet)
    }

    fun serverBound(packet: BedrockPacket) {
        // Ataques al jugador falso (solo local) no salen al servidor.
        if (com.retrivedmods.wclient.game.module.combat.FakePlayerModule.isBlockedServerBound(packet)) return
        wRelaySession.serverBound(packet)
    }

    override fun beforePacketBound(packet: BedrockPacket): Boolean {
        ModuleGuard.begin("sesion")
        try {
            return dispatchBeforePacketBound(packet)
        } finally {
            ModuleGuard.end()
        }
    }

    /**
     * Igual que KiwiMods: 1) paleta de bloques que manda el servidor, 2) mapa por hash si el servidor usa
     * IDs hasheados, 3) mapa secuencial estatico como ultimo recurso.
     */
    private fun buildBlockMapping(packet: StartGamePacket): BlockMapping {
        val serverPalette = packet.blockPalette
        val origin: String
        val mapping = when {
            serverPalette != null && serverPalette.isNotEmpty() -> {
                origin = "paleta del servidor (${serverPalette.size})"
                BlockMapping.fromServerPalette(serverPalette)
            }
            packet.isBlockNetworkIdsHashed -> {
                origin = "IDs hasheados"
                blockMappingProvider.craftMapping(protocolVersion).toHashed()
            }
            else -> {
                origin = "estatico secuencial"
                blockMappingProvider.craftMapping(protocolVersion)
            }
        }
        val summary = "Mapa de bloques: $origin | aire=${mapping.airId} | protocolo=$protocolVersion"
        Log.i("GameSession", summary)
        ModuleGuard.info(summary)
        // Se muestra en el chat del juego en el primer tick (justo al entrar el chat aun no existe).
        mappingNotice = "\u00a7b[RNK Client] $summary"
        ticksSinceStart = 0
        worldChecks = 0
        return mapping
    }

    private var ticksSinceStart = 0
    private var worldChecks = 0

    /** Modulos que necesitan el mapa de bloques; mientras ninguno este activo el mundo no se rastrea. */
    private val worldConsumers: List<Module> by lazy {
        ModuleManager.modules.filter {
            it is com.retrivedmods.wclient.game.module.combat.SurroundModule ||
                it is com.retrivedmods.wclient.game.module.combat.AnchorAuraModule ||
                it is com.retrivedmods.wclient.game.module.combat.AnchorHelperModule ||
                it is com.retrivedmods.wclient.game.module.combat.CrystalAuraModule ||
                it is com.retrivedmods.wclient.game.module.combat.BedAuraModule
        }
    }

    /**
     * Diagnostico en el chat: a los ~8 s y a los ~30 s de entrar informa de que bloques ve el cliente bajo
     * los pies del jugador y de como estan llegando los datos del mundo.
     */
    private fun worldCheck() {
        if (worldChecks >= 2) return
        ticksSinceStart++
        if (ticksSinceStart < (if (worldChecks == 0) 160 else 600)) return
        worldChecks++
        try {
            val p = localPlayer.vec3Position
            val x = Math.floor(p.x.toDouble()).toInt()
            val z = Math.floor(p.z.toDouble()).toInt()
            val baseY = Math.floor((p.y - 1.62f).toDouble()).toInt()
            val sb = StringBuilder("\u00a7b[RNK Client] bloques bajo tus pies:")
            for (dy in 0..2) {
                val pos = Vector3i.from(x, baseY - dy, z)
                val known = kiwiWorld.isBlockKnown(pos)
                val rid = kiwiWorld.getBlockRuntimeId(pos)
                val name = if (known) blockMapping.getDefinition(rid).identifier else "desconocido"
                sb.append(" y").append(pos.y).append("=").append(name).append("(").append(rid).append(")")
            }
            val text = sb.toString()
            val world = "\u00a7b[RNK Client] mundo: " + kiwiWorld.debugSummary()
            ModuleGuard.info(text)
            ModuleGuard.info(world)
            displayClientMessage(text)
            displayClientMessage(world)
        } catch (e: Exception) {
            ModuleGuard.reportError("worldCheck", e)
        }
    }

    /** Mensaje pendiente de mostrar en el chat del juego (una sola vez por sesion). */
    @Volatile
    private var mappingNotice: String? = null

    private fun dispatchBeforePacketBound(packet: BedrockPacket): Boolean {
        when (packet) {
            is StartGamePacket -> {
                try {
                    val itemDefinitions = SimpleDefinitionRegistry.builder<ItemDefinition>()
                        .addAll(packet.itemDefinitions)
                        .build()

                    wRelaySession.server.peer.codecHelper.itemDefinitions = itemDefinitions
                    wRelaySession.client?.peer?.codecHelper?.itemDefinitions = itemDefinitions

                    Log.i("GameSession", "Successfully set up codecHelper itemDefinitions: ${packet.itemDefinitions.size} items")
                } catch (e: Exception) {
                    Log.e("GameSession", "Failed to set up codecHelper itemDefinitions", e)
                }

                if (!startGameReceived) {
                    startGameReceived = true
                    Log.i("GameSession", "StartGamePacket received")

                    try {
                        blockMapping = buildBlockMapping(packet)
                        itemMapping = itemMappingProvider.craftMapping(protocolVersion)

                        Log.i("GameSession", "Loaded mappings for protocol $protocolVersion")
                    } catch (e: Exception) {
                        Log.e("GameSession", "Failed to load mappings for protocol $protocolVersion", e)
                    }
                }
            }

            is ItemComponentPacket -> {
                try {
                    val itemDefinitions = SimpleDefinitionRegistry.builder<ItemDefinition>()
                        .addAll(packet.items)
                        .build()

                    wRelaySession.server.peer.codecHelper.itemDefinitions = itemDefinitions
                    wRelaySession.client?.peer?.codecHelper?.itemDefinitions = itemDefinitions

                    Log.i("GameSession", "Successfully updated codecHelper from ItemComponentPacket: ${packet.items.size} items")
                } catch (e: Exception) {
                    Log.e("GameSession", "Failed to update codecHelper from ItemComponentPacket", e)
                }
            }
        }

        // Igual que KiwiMods: un fallo en un modulo o handler NUNCA debe tumbar la conexion
        // (antes una excepcion aqui cortaba la sesion: "conexion perdida / tiempo de espera agotado").
        val localStart = ModuleGuard.phase("localPlayer")
        try {
            localPlayer.onPacketBound(packet)
        } catch (e: Throwable) {
            ModuleGuard.reportError("localPlayer.onPacketBound", e)
        }
        ModuleGuard.finish("localPlayer", localStart, packet, false)

        val levelStart = ModuleGuard.phase("level")
        try {
            level.onPacketBound(packet)
        } catch (e: Throwable) {
            ModuleGuard.reportError("level.onPacketBound", e)
        }
        ModuleGuard.finish("level", levelStart, packet, false)

        val worldStart = ModuleGuard.phase("kiwiWorld")
        try {
            kiwiWorld.onPacket(packet)
        } catch (e: Throwable) {
            ModuleGuard.reportError("kiwiWorld.onPacket", e)
        }
        ModuleGuard.finish("kiwiWorld", worldStart, packet, false)

        val interceptablePacket = InterceptablePacket(packet)
        val isTick = packet is PlayerAuthInputPacket
        if (isTick) {
            kiwiWorld.setTracking(worldConsumers.any { it.isEnabled })
            val notice = mappingNotice
            if (notice != null) {
                mappingNotice = null
                displayClientMessage(notice)
            }
            // El diagnostico del mundo solo tiene sentido si el mundo se esta rastreando.
            if (worldConsumers.any { it.isEnabled }) worldCheck()
        }

        for (module in ModuleManager.modules) {
            // Set session if not already set
            if (!module.isSessionCreated) {
                module.session = this
            }
            // Solo se mide / vigila lo que esta habilitado: los desactivados salen enseguida.
            val watched = module.isEnabled
            if (watched && isTick && ModuleGuard.shouldSkip(module.name)) {
                continue
            }
            val moduleStart = if (watched) ModuleGuard.phase(module.name) else 0L
            try {
                module.beforePacketBound(interceptablePacket)
            } catch (e: Throwable) {
                ModuleGuard.reportError(module.name, e)
            }
            if (watched) {
                val warning = ModuleGuard.finish(module.name, moduleStart, packet, isTick)
                if (warning != null) {
                    displayClientMessage(warning)
                }
            }
            if (interceptablePacket.isIntercepted) {
                return true
            }
        }

        return false
    }

    override fun afterPacketBound(packet: BedrockPacket) {
        for (module in ModuleManager.modules) {
            try {
                module.afterPacketBound(packet)
            } catch (e: Throwable) {
                ModuleGuard.reportError("${module.name}.afterPacketBound", e)
            }
        }
    }

    override fun onDisconnect(reason: String) {
        try {
            localPlayer.onDisconnect()
            level.onDisconnect()
            kiwiWorld.clear()
        } catch (e: Throwable) {
            Log.e("GameSession", "Exception clearing session state", e)
        }
        startGameReceived = false

        for (module in ModuleManager.modules) {
            try {
                module.onDisconnect(reason)
            } catch (e: Throwable) {
                Log.e("GameSession", "Crash in module ${module.name} onDisconnect, continuing", e)
            }
        }
    }

    fun displayClientMessage(message: String, type: TextPacket.Type = TextPacket.Type.RAW) {
        val textPacket = TextPacket()
        textPacket.type = type
        textPacket.sourceName = ""
        textPacket.message = message
        textPacket.xuid = ""
        textPacket.platformChatId = ""
        textPacket.filteredMessage = ""
        clientBound(textPacket)
    }

}