package com.retrivedmods.wclient.game.bind

import com.retrivedmods.wclient.application.AppContext
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleManager
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File

/**
 * Binds (multibinds): un grupo con nombre que enciende o apaga varios modulos a la vez.
 * Tocar el bind: si alguno del grupo esta apagado, los enciende todos; si estan todos encendidos,
 * los apaga todos. Se guarda en configs/binds.json.
 *
 * En celular no hay teclado, asi que el bind se activa desde la pestana Binds de la GUI.
 */
object BindManager {

    private const val FILE_NAME = "binds.json"

    /** nombre del bind -> ids internos de los modulos (Module.name). */
    private val groups = LinkedHashMap<String, List<String>>()

    @Synchronized
    fun all(): Map<String, List<String>> = LinkedHashMap(groups)

    @Synchronized
    fun put(name: String, moduleIds: List<String>) {
        groups[name] = moduleIds.distinct()
        save()
    }

    @Synchronized
    fun remove(name: String) {
        groups.remove(name)
        save()
    }

    /** Modulos reales del bind (los que aun existen). */
    fun resolve(name: String): List<Module> {
        val ids = all()[name] ?: return emptyList()
        return ids.mapNotNull { id -> ModuleManager.modules.firstOrNull { it.name == id } }
    }

    fun toggle(name: String) {
        val mods = resolve(name)
        if (mods.isEmpty()) return
        val turnOn = mods.any { !it.isEnabled }
        mods.forEach { it.isEnabled = turnOn }
    }

    fun isOn(name: String): Boolean {
        val mods = resolve(name)
        return mods.isNotEmpty() && mods.all { it.isEnabled }
    }

    @Synchronized
    fun load() {
        val file = file() ?: return
        if (!file.exists()) return
        try {
            groups.clear()
            Json.parseToJsonElement(file.readText()).jsonObject.forEach { (name, arr) ->
                groups[name] = arr.jsonArray.map { it.jsonPrimitive.content }
            }
        } catch (e: Exception) {
            // Archivo dañado: se ignora y se sobrescribe en el siguiente cambio.
        }
    }

    @Synchronized
    private fun save() {
        val file = file() ?: return
        try {
            val json = buildJsonObject {
                groups.forEach { (name, ids) ->
                    put(name, buildJsonArray { ids.forEach { add(JsonPrimitive(it)) } })
                }
            }.toString()
            val tmp = File(file.parentFile, "$FILE_NAME.tmp")
            tmp.writeText(json)
            if (!tmp.renameTo(file)) {
                file.writeText(json)
                tmp.delete()
            }
        } catch (e: Exception) {
            // Sin escritura, los binds siguen funcionando en memoria.
        }
    }

    private fun file(): File? {
        if (!AppContext.isInitialized) return null
        val dir = AppContext.instance.filesDir.resolve("configs")
        dir.mkdirs()
        return dir.resolve(FILE_NAME)
    }
}
