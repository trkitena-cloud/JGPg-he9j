package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.kiwi.FriendManager
import com.retrivedmods.wclient.game.kiwi.entityFeetY
import com.retrivedmods.wclient.game.kiwi.localEyeY
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import kotlin.math.acos
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Trigger Bot: ataca automaticamente cuando la mira esta sobre un jugador.
 * Reescrito para RNK Client (la idea es parecida al TriggerBot de Riveria V1).
 * Elige el objetivo mas cercano a la mira (menor angulo) entre los que estan en rango.
 */
class TriggerBotModule : Module("Trigger Bot", ModuleCategory.Combat) {

    private val cpsMin by intValue("CPS Min", 10, 1..20)
    private val cpsMax by intValue("CPS Max", 14, 1..20)
    private val range by floatValue("Range", 4.0f, 2.0f..7.0f)
    private val tolerance by floatValue("Aim Tolerance", 4.0f, 0.5f..20.0f)
    private val antiBot by boolValue("Anti Bot", true)

    private var lastAttackTime = 0L
    private var nextDelayMs = 80L

    override fun onEnabled() {
        super.onEnabled()
        lastAttackTime = 0L
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet
        if (packet !is PlayerAuthInputPacket) return

        val now = System.currentTimeMillis()
        if (now - lastAttackTime < nextDelayMs) return

        val lp = session.localPlayer
        val pitch = packet.rotation.x
        val yaw = packet.rotation.y

        var best: Player? = null
        var bestAngle = tolerance
        for (e in session.level.entityMap.values) {
            if (e !is Player || !isValid(e, lp)) continue
            val feet = session.entityFeetY(e)
            val angle = min(
                min(angleTo(lp, yaw, pitch, e.posX, feet, e.posZ), angleTo(lp, yaw, pitch, e.posX, feet + 0.9f, e.posZ)),
                angleTo(lp, yaw, pitch, e.posX, feet + 1.7f, e.posZ)
            )
            if (angle <= bestAngle) {
                bestAngle = angle
                best = e
            }
        }
        val target = best ?: return

        lp.attack(target)
        lastAttackTime = now
        val lo = min(cpsMin, cpsMax).coerceAtLeast(1)
        val hi = maxOf(cpsMin, cpsMax).coerceAtLeast(1)
        val cps = if (hi > lo) lo + kotlin.random.Random.nextInt(hi - lo + 1) else lo
        nextDelayMs = 1000L / cps
    }

    // Angulo (grados) entre la direccion de mira y la direccion hacia el punto.
    private fun angleTo(lp: LocalPlayer, yawDeg: Float, pitchDeg: Float, tx: Float, ty: Float, tz: Float): Float {
        val dx = (tx - lp.posX).toDouble()
        val dy = (ty - session.localEyeY()).toDouble()
        val dz = (tz - lp.posZ).toDouble()
        val dist = sqrt(dx * dx + dy * dy + dz * dz)
        if (dist < 1e-4) return 0f
        val yawRad = Math.toRadians(yawDeg.toDouble())
        val pitchRad = Math.toRadians(-pitchDeg.toDouble())
        val lookX = -sin(yawRad) * cos(pitchRad)
        val lookY = sin(pitchRad)
        val lookZ = cos(yawRad) * cos(pitchRad)
        val dot = ((dx * lookX + dy * lookY + dz * lookZ) / dist).coerceIn(-1.0, 1.0)
        return Math.toDegrees(acos(dot)).toFloat()
    }

    private fun isValid(e: Player, lp: LocalPlayer): Boolean {
        if (e === lp || e is LocalPlayer) return false
        if (FakePlayerModule.isFake(e.uniqueEntityId)) return false
        if (FriendManager.isFriend(e.uuid)) return false
        if (e.distance(lp) > range) return false
        return !(antiBot && isBot(e))
    }

    private fun isBot(player: Player): Boolean {
        val entry = session.level.playerMap[player.uuid] ?: return true
        val name = entry.name?.toString().orEmpty()
        if (name.isBlank()) return true
        val xuid = entry.xuid.orEmpty()
        return xuid.isEmpty() || xuid == "0"
    }
}
