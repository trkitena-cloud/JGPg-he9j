package com.retrivedmods.wclient.game.module.visual

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.AddItemEntityPacket

/**
 * NoRender: no deja que aparezcan en tu cliente los items tirados (filtra el paquete que los crea).
 * Solo filtra items: no oculta entidades como cristales, porque CrystalAura y otros modulos las
 * necesitan para funcionar.
 */
class NoRenderModule : Module("no_render", ModuleCategory.Visual) {

    private val hideItems by boolValue("Hide Dropped Items", true)

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled || !hideItems) return
        if (interceptablePacket.packet is AddItemEntityPacket) {
            interceptablePacket.intercept()
        }
    }
}
