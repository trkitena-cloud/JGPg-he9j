package com.retrivedmods.wclient.game.module.misc

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.friend.FriendManager
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.packet.SetTitlePacket

/**
 * GearInfo: muestra en la barra de accion el equipo del jugador mas cercano (mano, casco,
 * pechera, pantalones y botas). Usa los paquetes de equipo que ya llegan del servidor.
 */
class GearInfoModule : Module("gear_info", ModuleCategory.Misc) {

    private val range by intValue("Range", 8, 2..32)
    private val refreshMs by intValue("Refresh ms", 1000, 250..5000)
    private val showFriends by boolValue("Show Friends", true)

    private var lastShow = 0L

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet
        if (packet !is PlayerAuthInputPacket) return

        val now = System.currentTimeMillis()
        if (now - lastShow < refreshMs) return
        lastShow = now

        val lp = session.localPlayer
        val maxDist = (range * range).toDouble()
        val nearest = session.level.entityMap.values.toList()
            .filterIsInstance<Player>()
            .filter { it.runtimeEntityId != lp.runtimeEntityId }
            .filter { showFriends || !FriendManager.isFriend(it.uuid) }
            .map { it to it.distanceSq(lp).toDouble() }
            .filter { it.second <= maxDist }
            .minByOrNull { it.second }?.first ?: return

        session.clientBound(SetTitlePacket().apply {
            type = SetTitlePacket.Type.ACTIONBAR
            text = gearText(nearest)
        })
    }

    private fun gearText(p: Player): String {
        val inv = p.inventory
        val name = p.username.ifBlank { p.uuid.toString().take(8) }
        return "§b$name §7| §fMano: ${itemName(inv.hand)} §7| §fCasco: ${itemName(inv.helmet)} " +
            "§7| §fPechera: ${itemName(inv.chestplate)} §7| §fPantalon: ${itemName(inv.leggings)} " +
            "§7| §fBotas: ${itemName(inv.boots)}"
    }

    /** "minecraft:diamond_sword" -> "diamond sword"; "-" si no hay nada. */
    private fun itemName(item: ItemData): String {
        if (item == ItemData.AIR || item.count == 0) return "-"
        val id = item.definition?.identifier ?: return "?"
        return id.removePrefix("minecraft:").replace('_', ' ')
    }
}
