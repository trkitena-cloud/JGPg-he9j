package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.kiwi.BlockPlacer
import com.retrivedmods.wclient.game.kiwi.FriendManager
import com.retrivedmods.wclient.game.kiwi.ItemUseState
import com.retrivedmods.wclient.game.kiwi.entityFeetY
import com.retrivedmods.wclient.game.kiwi.toRotation
import com.retrivedmods.wclient.game.utils.constants.Attribute
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.ItemUseTransaction
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import kotlin.math.floor
import kotlin.math.sqrt

/**
 * RNK Crystal: crystal aura simple.
 *  - Objetivo: el jugador mas cercano en "Target Range" (no amigos, no Fake Player).
 *  - Colocar: busca obsidiana/bedrock alrededor del OBJETIVO con 2 bloques de aire encima, dentro
 *    de "Place Range" de ti, y solo si el cristal queda mas cerca del objetivo que de ti
 *    (asi no pone cristales a tu espalda). Elige la posicion con mejor (dano enemigo - dano propio).
 *  - Romper: golpea cristales cercanos que cumplan el mismo criterio de dano.
 *  - Seguridad: nunca coloca/rompe si tu vida quedaria bajo "Min Health" ni si te hace mas dano
 *    a ti que al enemigo. "Face Place" baja el dano minimo cuando el objetivo tiene poca vida.
 * Sin ID Predict, sin escaneo incremental: un escaneo corto cada 'Scan Interval' ms.
 */
class CrystalPreset(
    val targetRange: Float, val placeRange: Float, val breakRange: Float,
    val placeDelay: Int, val breakDelay: Int, val minDamage: Float, val maxSelf: Float,
    val minHealth: Float, val facePlace: Float, val perCycle: Int
)

class RnkCrystalModule : RnkCrystalBase(
    "RNK Crystal", CrystalPreset(10f, 5.5f, 5.5f, 50, 50, 5f, 5f, 8f, 8f, 2)
)

/** Mas agresivo: sin delay, mas cristales por ciclo, acepta mas dano propio (sigue respetando Min Health). */
class RnkCrystalMaxModule : RnkCrystalBase(
    "RNK Crystal Max", CrystalPreset(12f, 6f, 6f, 0, 0, 3f, 9f, 5f, 14f, 4)
)

/** Muy conservador: casi nunca te hace dano, ideal con poca vida o sin totems. */
class RnkCrystalSafeModule : RnkCrystalBase(
    "RNK Crystal Safe", CrystalPreset(9f, 5f, 5f, 80, 60, 6f, 2f, 12f, 6f, 1)
)

abstract class RnkCrystalBase(name: String, d: CrystalPreset) : Module(name, ModuleCategory.Combat) {

    private val placeEnabled by boolValue("Place", true)
    private val breakEnabled by boolValue("Break", true)
    private val targetRange by floatValue("Target Range", d.targetRange, 3.0f..16.0f)
    private val placeRange by floatValue("Place Range", d.placeRange, 2.0f..8.0f)
    private val breakRange by floatValue("Break Range", d.breakRange, 2.0f..8.0f)
    private val placeDelay by intValue("Place Delay (ms)", d.placeDelay, 0..500)
    private val breakDelay by intValue("Break Delay (ms)", d.breakDelay, 0..500)
    private val minDamage by floatValue("Min Damage", d.minDamage, 0.5f..20.0f)
    private val maxSelfDamage by floatValue("Max Self Damage", d.maxSelf, 0.0f..20.0f)
    private val minHealth by floatValue("Min Health", d.minHealth, 1.0f..20.0f)
    private val facePlaceBelow by floatValue("Face Place Below HP", d.facePlace, 0.0f..20.0f)
    private val maxPerCycle by intValue("Max Per Cycle", d.perCycle, 1..6)
    private val rotate by boolValue("Rotate", true)
    private val eatStop by boolValue("Eat Stop", true)

    private class Spot(val support: Vector3i, val center: Vector3f, val score: Float)

    private var lastPlace = 0L
    private var lastBreak = 0L
    private var lastScan = 0L
    private var lastTick = -1L
    private var spots: List<Spot> = emptyList()
    private var oldSlot = -1
    private var serverSlot = -1

    override fun onEnabled() {
        super.onEnabled()
        spots = emptyList()
        oldSlot = -1
        serverSlot = -1
        lastTick = -1L
    }

    override fun onDisabled() {
        super.onDisabled()
        if (oldSlot >= 0 && isSessionCreated && serverSlot != oldSlot) {
            BlockPlacer.sendServerSlot(session, oldSlot)
        }
        oldSlot = -1
        serverSlot = -1
        spots = emptyList()
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet as? PlayerAuthInputPacket ?: return
        if (packet.tick == lastTick) return
        lastTick = packet.tick
        if (eatStop && ItemUseState.using) return

        val lp = session.localPlayer
        val target = findTarget(lp) ?: run { restoreSlot(); spots = emptyList(); return }
        val now = System.currentTimeMillis()
        var aim: Vector3f? = null

        // 1) Romper
        if (breakEnabled && now - lastBreak >= breakDelay) {
            val list = session.kiwiWorld.crystalsNear(breakRange)
                .map { c ->
                    val pos = c.vec3Position
                    Triple(c, session.kiwiWorld.explosionDamageTo(pos, target), session.kiwiWorld.explosionDamageTo(pos, lp))
                }
                .filter { (_, t, s) -> okDamage(lp, target, t, s) }
                .sortedByDescending { (_, t, s) -> t - s * 0.8f }
            var n = 0
            for ((c, _, _) in list) {
                lp.attack(c)
                aim = c.vec3Position
                if (++n >= maxPerCycle) break
            }
            if (n > 0) lastBreak = now
        }

        // 2) Colocar
        if (placeEnabled && now - lastPlace >= placeDelay) {
            val slot = findCrystalSlot()
            if (slot != null) {
                if (now - lastScan >= SCAN_INTERVAL_MS) {
                    spots = scan(lp, target)
                    lastScan = now
                }
                if (spots.isNotEmpty() && placeAt(lp, slot)) {
                    lastPlace = now
                    if (aim == null) aim = spots.first().center
                }
            } else restoreSlot()
        }

        if (rotate && aim != null) {
            val eye = Vector3f.from(lp.posX, session.entityFeetY(lp) + 1.62f, lp.posZ)
            val rot = toRotation(eye, aim)
            // El relay reenvia los bytes originales: se manda una copia rotada y se descarta el original.
            val clone = packet.clone()
            clone.rotation = Vector3f.from(rot.pitch, rot.yaw, rot.yaw)
            session.serverBound(clone)
            interceptablePacket.intercept()
        }
    }

    private fun okDamage(lp: LocalPlayer, target: Player, targetDmg: Float, selfDmg: Float): Boolean {
        val health = lp.attributes[Attribute.HEALTH]?.value ?: 20f
        if (health - selfDmg < minHealth) return false
        if (selfDmg > maxSelfDamage || selfDmg > targetDmg) return false
        val targetHealth = target.attributes[Attribute.HEALTH]?.value ?: 20f
        val need = if (targetHealth <= facePlaceBelow) 1.0f else minDamage
        return targetDmg >= need
    }

    private fun scan(lp: LocalPlayer, target: Player): List<Spot> {
        val world = session.kiwiWorld
        val air = session.blockMapping.airId
        val tx = floor(target.posX).toInt()
        val ty = floor(session.entityFeetY(target)).toInt()
        val tz = floor(target.posZ).toInt()
        val me = Vector3f.from(lp.posX, session.entityFeetY(lp), lp.posZ)
        val tgt = Vector3f.from(target.posX, session.entityFeetY(target), target.posZ)
        val out = ArrayList<Spot>()
        for (dx in -4..4) for (dz in -4..4) for (dy in -3..2) {
            val support = Vector3i.from(tx + dx, ty + dy, tz + dz)
            val center = Vector3f.from(support.x + 0.5f, support.y + 1.5f, support.z + 0.5f)
            if (center.distance(me) > placeRange) continue
            // Nunca a tu espalda: el cristal debe quedar mas cerca del objetivo que de ti.
            if (center.distance(tgt) >= center.distance(me)) continue
            if (!world.isBlockKnown(support)) { world.requestBlockData(support); continue }
            val rid = world.getBlockRuntimeId(support)
            if (rid == air || rid == 0) continue
            val id = try { session.blockMapping.getDefinition(rid).identifier } catch (_: Exception) { null }
            if (id == null || !(id.contains("obsidian") || id.contains("bedrock"))) continue
            val a1 = Vector3i.from(support.x, support.y + 1, support.z)
            val a2 = Vector3i.from(support.x, support.y + 2, support.z)
            if (!world.isBlockKnown(a1) || !world.isBlockKnown(a2)) continue
            val r1 = world.getBlockRuntimeId(a1)
            val r2 = world.getBlockRuntimeId(a2)
            if (!((r1 == air || r1 == 0) && (r2 == air || r2 == 0))) continue
            if (world.crystalExistsAtSupport(support) || world.isPlacementPending(support)) continue
            val td = world.explosionDamageTo(center, target, 12f, true)
            val sd = world.explosionDamageTo(center, lp, 12f, true)
            if (!okDamage(lp, target, td, sd)) continue
            out.add(Spot(support, center, td - sd * 0.8f))
        }
        out.sortByDescending { it.score }
        return out
    }

    private fun placeAt(lp: LocalPlayer, slot: Int): Boolean {
        val world = session.kiwiWorld
        if (oldSlot == -1) oldSlot = lp.inventory.heldItemSlot
        if (serverSlot != slot) {
            BlockPlacer.sendServerSlot(session, slot)
            serverSlot = slot
        }
        var n = 0
        for (s in spots) {
            if (world.crystalExistsAtSupport(s.support) || world.isPlacementPending(s.support)) continue
            val def = world.knownDefinition(s.support)
                ?: session.blockMapping.definitionByIdentifier("minecraft:obsidian")
            session.serverBound(InventoryTransactionPacket().apply {
                transactionType = InventoryTransactionType.ITEM_USE
                actionType = 0
                blockPosition = s.support
                blockFace = 1
                hotbarSlot = slot
                itemInHand = lp.inventory.content[slot]
                playerPosition = lp.vec3Position
                clickPosition = Vector3f.from(0.5f, 0.5f, 0.5f)
                blockDefinition = def
                triggerType = ItemUseTransaction.TriggerType.PLAYER_INPUT
                clientInteractPrediction = ItemUseTransaction.PredictedResult.SUCCESS
            })
            lp.swing()
            world.registerPlacement(s.support, "minecraft:obsidian")
            if (++n >= maxPerCycle) break
        }
        restoreSlot()
        return n > 0
    }

    private fun findCrystalSlot(): Int? {
        val inv = session.localPlayer.inventory
        for (i in 0 until 9) {
            val item = inv.content[i]
            val id = item.definition?.identifier ?: continue
            if ((id.contains("end_crystal") || id.contains("ender_crystal")) && item.count > 0) return i
        }
        return null
    }

    private fun findTarget(lp: LocalPlayer): Player? {
        var best: Player? = null
        var bestD = Float.MAX_VALUE
        for (e in session.level.entityMap.values) {
            if (e !is Player || e === lp || e is LocalPlayer) continue
            if (FriendManager.isFriend(e.uuid) || FakePlayerModule.isFake(e.uniqueEntityId)) continue
            val dx = e.posX - lp.posX
            val dy = session.entityFeetY(e) - session.entityFeetY(lp)
            val dz = e.posZ - lp.posZ
            val d = sqrt(dx * dx + dy * dy + dz * dz)
            if (d <= targetRange && d < bestD) { best = e; bestD = d }
        }
        return best
    }

    private fun restoreSlot() {
        val old = oldSlot
        if (old == -1) return
        if (serverSlot != old) BlockPlacer.sendServerSlot(session, old)
        serverSlot = old
        oldSlot = -1
    }

    private companion object {
        const val SCAN_INTERVAL_MS = 80L
    }
}
