package com.retrivedmods.wclient.game.module.combat

import org.cloudburstmc.protocol.bedrock.packet.SetTitlePacket
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.entity.Entity
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.kiwi.FriendManager
import com.retrivedmods.wclient.game.kiwi.entityFeetY
import com.retrivedmods.wclient.game.utils.constants.Attribute
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.LevelEvent
import org.cloudburstmc.protocol.bedrock.data.entity.EntityEventType
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData
import org.cloudburstmc.protocol.bedrock.packet.EntityEventPacket
import org.cloudburstmc.protocol.bedrock.packet.LevelEventPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.packet.RemoveEntityPacket
import org.cloudburstmc.protocol.bedrock.packet.TextPacket
import kotlin.math.sqrt

/**
 * PopCounter portado de KiwiMods (game/module/combat/PopCounterModule).
 *
 * Cuenta cuantos totems revienta cada jugador cercano y avisa en tu chat local ("Send Pop/Death
 * Message" ademas lo envia al chat del servidor). Detecta el pop por el sonido de totem
 * (LevelEvent) o, con "Actor Event", por el EntityEvent CONSUME_TOTEM. Un pop solo se atribuye a
 * jugadores que se vieron con un totem en la mano secundaria y que estan a <= 10 bloques del evento.
 *
 * Los textos de aviso son listas fijas (Kiwi las tenia editables como lista de cadenas).
 */
class PopCounterModule : Module("pop_counter", ModuleCategory.Combat) {

    private val sendPops by boolValue("Send Pop Message", false)
    private val sendDeath by boolValue("Send Death Message", false)
    private val countFriends by boolValue("Track Friends", false)
    private val countSelf by boolValue("Track Self", false)
    private val actorEventOnly by boolValue("Actor Event", false)
    private val smartReset by boolValue("Smart Reset", false)
    private val messageDelay by intValue("Message Delay", 1000, 0..5000)

    /**
     * Mensaje propio para cada evento. Si esta vacio se usa la lista de mensajes aleatorios.
     * Placeholders: !player! !pops! !totem! !clientname!. Colores con & (ej. &c = rojo).
     */
    /** Titulo animado en pantalla (lo dibuja el propio juego: entrada, pausa y salida). */
    private val popAnimation by boolValue("Pop Animation", true)
    private val deathAnimation by boolValue("Death Animation", true)

    /** Texto extra al final de cada mensaje (acepta & para colores). Vacio = nada. */
    private val popSuffix by stringValue("Pop Suffix", "", listOf())
    private val usedSelfPopIdx = mutableListOf<Int>()
    private val usedSelfDeathIdx = mutableListOf<Int>()
    private val deathSuffix by stringValue("Death Suffix", "", listOf())

    private val customPopMessage by stringValue("Custom Pop Message", "", listOf())
    private val customDeathMessage by stringValue("Custom Death Message", "", listOf())

    private val popCounts = LinkedHashMap<Long, Int>()
    private val hadTotem = LinkedHashMap<Long, Boolean>()
    private val pendingDeaths = ArrayList<String>()
    private val usedPopIdx = ArrayList<Int>()
    private val usedDeathIdx = ArrayList<Int>()
    private var lastPopTime = 0L
    private var lastDeathTime = 0L

    override fun onEnabled() {
        super.onEnabled()
        resetState()
    }

    override fun onDisabled() {
        super.onDisabled()
        popCounts.clear()
        hadTotem.clear()
        pendingDeaths.clear()
    }

    private fun resetState() {
        popCounts.clear()
        hadTotem.clear()
        pendingDeaths.clear()
        lastPopTime = 0L
        lastDeathTime = 0L
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet
        val localPlayer = session.localPlayer
        when (packet) {
            is PlayerAuthInputPacket -> {
                onTick(localPlayer)
                flushPendingDeaths()
            }
            is LevelEventPacket -> onLevelEvent(packet)
            is EntityEventPacket -> onEntityEvent(packet)
            is RemoveEntityPacket -> onRemoveEntity(packet)
        }
    }

    private fun flushPendingDeaths() {
        if (pendingDeaths.isEmpty()) return
        val now = System.currentTimeMillis()
        if (now - lastDeathTime < messageDelay) return
        val msg = pendingDeaths.removeAt(0)
        sendClientMessage(msg)
        if (sendDeath) sendGameChatMessage(msg)
        lastDeathTime = now
    }

    private fun onTick(localPlayer: LocalPlayer) {
        val health = localPlayer.attributes[Attribute.HEALTH]?.value ?: 20f
        if (smartReset) {
            if (health <= 0f) {
                popCounts[localPlayer.runtimeEntityId] = 0
                hadTotem[localPlayer.runtimeEntityId] = false
            }
            // Entidades que ya no existen: se reinicia su contador.
            val present = session.level.entityMap.keys.toSet()
            for (id in popCounts.keys.filter { it !in present }) {
                popCounts[id] = 0
                hadTotem[id] = false
            }
        } else if (health <= 0f) {
            popCounts[localPlayer.runtimeEntityId] = 0
        }

        for (entity in session.level.entityMap.values) {
            if (entity is Player && holdsTotem(entity.inventory.offhand)) {
                hadTotem[entity.runtimeEntityId] = true
            }
        }
        // El jugador local no siempre esta en entityMap: se revisa su mano secundaria aparte.
        if (holdsTotem(localPlayer.inventory.offhand)) hadTotem[localPlayer.runtimeEntityId] = true
    }

    private fun holdsTotem(item: ItemData): Boolean =
        item != ItemData.AIR && item.definition?.identifier == TOTEM_ID

    private fun onLevelEvent(packet: LevelEventPacket) {
        if (actorEventOnly || packet.type != LevelEvent.SOUND_TOTEM_USED || packet.position == Vector3f.ZERO) return
        val pos = packet.position
        val localPlayer = session.localPlayer

        // Se buscan candidatos entre TODOS los jugadores con totem (tu incluido, y friends).
        // Si el mas cercano es tu o un friend y no lo quieres contar, el pop NO se pasa a otro.
        val candidates = ArrayList<Pair<Player, Float>>()
        val players = (session.level.entityMap.values.filterIsInstance<Player>() + localPlayer)
            .distinctBy { it.runtimeEntityId }
        for (entity in players) {
            if (hadTotem[entity.runtimeEntityId] != true) continue

            val feetY = session.entityFeetY(entity)
            val dx = entity.posX - pos.x
            val dy = feetY - pos.y
            val dz = entity.posZ - pos.z
            val dist = sqrt(dx * dx + dy * dy + dz * dz)
            if (dist <= 10f) candidates.add(entity to dist)
        }
        if (candidates.isEmpty()) return
        val owner = candidates.minByOrNull { it.second }!!.first
        if (!shouldCount(owner)) return
        onPop(owner)
    }

    /** Decide si este jugador cuenta: tu solo con "Track Self", friends solo con "Track Friends". */
    private fun shouldCount(player: Player): Boolean {
        if (player.runtimeEntityId == session.localPlayer.runtimeEntityId) return countSelf
        if (FriendManager.isFriend(player.uuid)) return countFriends
        return true
    }

    private fun onEntityEvent(packet: EntityEventPacket) {
        if (!actorEventOnly || packet.type != EntityEventType.CONSUME_TOTEM) return
        val lp = session.localPlayer
        val entity: Entity = session.level.entityMap[packet.runtimeEntityId]
            ?: if (packet.runtimeEntityId == lp.runtimeEntityId) lp else return
        if (entity !is Player) return
        if (!shouldCount(entity)) return
        onPop(entity)
    }

    private fun onRemoveEntity(packet: RemoveEntityPacket) {
        val entity = session.level.entityMap.values.firstOrNull { it.uniqueEntityId == packet.uniqueEntityId }
        if (entity !is Player) return
        val id = entity.runtimeEntityId
        val pops = popCounts[id] ?: 0
        if (pops <= 0) return
        if (entity === session.localPlayer && !countSelf) return
        if (FriendManager.isFriend(entity.uuid) && !countFriends) return

        if (deathAnimation) sendTitle("§c${nameOf(entity)} murio", "§7$pops totems")
        val selfDeath = entity === session.localPlayer
        val message = formatMessage(
            customDeathMessage.ifBlank {
                if (selfDeath) pickMessage(SELF_DEATH_MESSAGES, usedSelfDeathIdx)
                else pickMessage(DEATH_MESSAGES, usedDeathIdx)
            }, if (selfDeath) "You" else nameOf(entity), pops, if (pops > 1) "totems" else "totem", deathSuffix
        )
        val now = System.currentTimeMillis()
        if (now - lastDeathTime >= messageDelay) {
            sendClientMessage(message)
            if (sendDeath) sendGameChatMessage(message)
            lastDeathTime = now
        } else {
            pendingDeaths.add(message)
        }
        popCounts[id] = 0
        hadTotem[id] = false
    }

    private fun onPop(target: Player) {
        val id = target.runtimeEntityId
        val pops = (popCounts[id] ?: 0) + 1
        popCounts[id] = pops

        if (popAnimation) sendTitle("§e-$pops totem", "§7${nameOf(target)}")
        val selfPop = target === session.localPlayer
        val message = formatMessage(
            customPopMessage.ifBlank {
                if (selfPop) pickMessage(SELF_POP_MESSAGES, usedSelfPopIdx)
                else pickMessage(POP_MESSAGES, usedPopIdx)
            }, if (selfPop) "You" else nameOf(target), pops, if (pops > 1) "totems" else "totem", popSuffix
        )
        sendClientMessage(message)
        if (!sendPops || target === session.localPlayer || FriendManager.isFriend(target.uuid)) return

        val now = System.currentTimeMillis()
        if (now - lastPopTime >= messageDelay) {
            sendGameChatMessage(message)
            lastPopTime = now
        }
    }

    private fun nameOf(player: Player): String =
        player.username.ifEmpty { player.uuid.toString().substring(0, 8) }

    /** Elige un mensaje al azar sin repetir hasta agotar la lista. */
    private fun pickMessage(pool: List<String>, used: MutableList<Int>): String {
        if (pool.isEmpty()) return "!player! popped !pops! !totem!"
        if (used.size >= pool.size) used.clear()
        val free = pool.indices.filter { it !in used }
        val idx = if (free.isEmpty()) pool.indices.random() else free.random()
        used.add(idx)
        return pool[idx]
    }

    /** Muestra un titulo y subtitulo con animacion usando el paquete de titulo del protocolo. */
    private fun sendTitle(title: String, subtitle: String) {
        session.clientBound(SetTitlePacket().apply {
            type = SetTitlePacket.Type.TIMES
            fadeInTime = 5
            stayTime = 40
            fadeOutTime = 10
        })
        session.clientBound(SetTitlePacket().apply {
            type = SetTitlePacket.Type.SUBTITLE
            text = subtitle
        })
        session.clientBound(SetTitlePacket().apply {
            type = SetTitlePacket.Type.TITLE
            text = title
        })
    }

    private fun formatMessage(template: String, name: String, pops: Int, totemWord: String, suffix: String = ""): String =
        (if (suffix.isBlank()) template else "$template $suffix")
            .replace(Regex("&([0-9a-fk-or])"), "§$1")
            .replace("!player!", name)
            .replace("!pops!", pops.toString())
            .replace("!totem!", totemWord)
            .replace("!clientname!", "RNK Client")

    private fun sendClientMessage(message: String) = session.displayClientMessage(message)

    private fun sendGameChatMessage(message: String) {
        session.serverBound(TextPacket().apply {
            type = TextPacket.Type.CHAT
            sourceName = ""
            this.message = message
            xuid = ""
            platformChatId = ""
            needsTranslation = false
        })
    }

    private companion object {
        const val TOTEM_ID = "minecraft:totem_of_undying"

        /** Mensajes cuando el pop o la muerte es TUYA (segunda persona). */
        val SELF_POP_MESSAGES = listOf(
            "§7[§bRNK Client§r] §eYou §rpopped §a!pops!§r !totem!.",
            "§7[§bRNK Client§r] §eYou §rjust popped §a!pops!§r !totem!, nice",
            "§7[§bRNK Client§r] §eYou §rlost §a!pops!§r !totem!, rip",
            "§7[§bRNK Client§r] §eYou §rpopped §a!pops!§r !totem!, be careful"
        )
        val SELF_DEATH_MESSAGES = listOf(
            "§7[§bRNK Client§r] §cYou §rdied after popping §a!pops!§c !totem!.",
            "§7[§bRNK Client§r] §cYou §rpopped §a!pops!§c !totem! and then died",
            "§7[§bRNK Client§r] §cYou §rlost §a!pops!§c !totem! and died"
        )

        val POP_MESSAGES = listOf(
            "§7[§bRNK Client§r] §e§l!player!§r popped §a!pops!§r !totem!.",
            "§7[§bRNK Client§r] §e!player!§r just popped §a!pops!§r !totem!, ez",
            "§7[§bRNK Client§r] §e!player!§r lost §a!pops!§r !totem!, lol",
            "§7[§bRNK Client§r] §e!player!§r popped §a!pops!§r !totem!, get good"
        )
        val DEATH_MESSAGES = listOf(
            "§7[§bRNK Client§r] §c§l!player!§r died after popping §a!pops!§c !totem!.",
            "§7[§bRNK Client§r] §c!player!§r popped §a!pops!§c !totem! then died, ez",
            "§7[§bRNK Client§r] §c!player!§r lost §a!pops!§c !totem! and died"
        )
    }
}
