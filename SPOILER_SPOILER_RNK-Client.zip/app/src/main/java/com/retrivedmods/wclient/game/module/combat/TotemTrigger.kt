package com.retrivedmods.wclient.game.module.combat

import org.cloudburstmc.protocol.bedrock.data.entity.EntityEventType
import org.cloudburstmc.protocol.bedrock.data.inventory.ContainerId
import org.cloudburstmc.protocol.bedrock.packet.BedrockPacket
import org.cloudburstmc.protocol.bedrock.packet.EntityEventPacket
import org.cloudburstmc.protocol.bedrock.packet.InventoryContentPacket
import org.cloudburstmc.protocol.bedrock.packet.InventorySlotPacket

/**
 * Paquetes del servidor tras los que conviene mirar de inmediato si hay que reponer el totem:
 * el aviso de totem gastado y las actualizaciones del offhand/inventario. Asi el Auto Totem no espera
 * al siguiente tick del jugador (hasta 50 ms) para reaccionar.
 */
internal object TotemTrigger {
    fun shouldReact(packet: BedrockPacket, localRuntimeId: Long): Boolean = when (packet) {
        is EntityEventPacket ->
            packet.type == EntityEventType.CONSUME_TOTEM && packet.runtimeEntityId == localRuntimeId
        is InventorySlotPacket -> packet.containerId == ContainerId.OFFHAND
        is InventoryContentPacket ->
            packet.containerId == ContainerId.OFFHAND || packet.containerId == ContainerId.INVENTORY
        else -> false
    }
}
