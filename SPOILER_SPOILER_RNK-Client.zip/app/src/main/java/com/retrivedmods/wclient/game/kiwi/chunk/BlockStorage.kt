package com.retrivedmods.wclient.game.kiwi.chunk

import android.util.Log
import com.retrivedmods.wclient.game.kiwi.chunk.palette.BitArray
import com.retrivedmods.wclient.game.kiwi.chunk.palette.BitArrayVersion
import com.retrivedmods.wclient.game.kiwi.chunk.palette.Pow2BitArray
import io.netty.buffer.ByteBuf
import org.cloudburstmc.protocol.common.util.VarInts

class BlockStorage {
    var bitArray: BitArray
    val palette = mutableListOf<Int>()

    constructor(version: BitArrayVersion, airId: Int) {
        bitArray = version.createPalette(MAX_BLOCKS)
        palette.add(airId)
    }

    /**
     * Lee una capa de almacenamiento de bloques (formato de red de Bedrock, igual que KiwiMods):
     *   byte cabecera = (bitsPorBloque << 1) | esRuntime
     *   palabras int LE: se calculan a partir de los bits, SIN prefijo de longitud
     *   (0 bits = capa uniforme: sin palabras y una unica entrada de paleta, sin tamano)
     *   tamano de paleta (VarInt) + entradas (VarInt)
     * Antes se leia un "wordCount" inexistente y se desalineaba todo el chunk.
     */
    constructor(buf: ByteBuf, network: Boolean) {
        val header = buf.readUnsignedByte().toInt()
        val runtime = (header and 1) == 1
        val paletteBits = (header shr 1) and 0x7F
        if (!runtime) {
            throw IllegalStateException("Paleta NBT no soportada (cabecera=$header)")
        }

        fun readEntry(): Int = if (network) VarInts.readInt(buf) else buf.readIntLE()

        if (paletteBits == 0) {
            bitArray = BitArrayVersion.V1.createPalette(MAX_BLOCKS)
            palette.add(readEntry())
        } else {
            val bitArrayVersion = BitArrayVersion.get(paletteBits, true)
            bitArray = bitArrayVersion.createPalette(MAX_BLOCKS)
            val words = bitArray.getWords()
            for (i in words.indices) {
                words[i] = buf.readIntLE()
            }
            val paletteSize = readEntry()
            if (paletteSize < 0 || paletteSize > MAX_PALETTE_SIZE) {
                throw IllegalStateException("Tamano de paleta invalido: $paletteSize")
            }
            repeat(paletteSize) {
                palette.add(readEntry())
            }
        }
    }

    fun getBlock(x: Int, y: Int, z: Int): Int {
        val index = (x shl 8) or (z shl 4) or y
        val paletteIndex = bitArray.get(index)
        // Un indice fuera de la paleta no debe lanzar una excepcion por cada lectura de bloque.
        return if (paletteIndex < palette.size) palette[paletteIndex] else (palette.firstOrNull() ?: 0)
    }

    fun setBlock(x: Int, y: Int, z: Int, id: Int) {
        val index = (x shl 8) or (z shl 4) or y
        val paletteIndex = palette.indexOf(id).takeIf { it != -1 } ?: run {
            palette.add(id)
            palette.lastIndex
        }
        bitArray.set(index, paletteIndex)
    }

    companion object {
        const val MAX_BLOCKS = 4096
        const val MAX_PALETTE_SIZE = 65536
    }
}
