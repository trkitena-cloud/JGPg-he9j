package com.retrivedmods.wclient.game.module.misc

import com.retrivedmods.wclient.BuildConfig
import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.packet.SetTitlePacket
import org.cloudburstmc.protocol.bedrock.packet.StartGamePacket

/**
 * Bienvenida: al entrar a un servidor muestra un titulo con tu nombre y la version de Abysm.
 * Espera unos segundos tras entrar (ticks de movimiento) para que el cliente ya este listo.
 */
class WelcomeModule : Module("welcome", ModuleCategory.Misc) {

    private var ticksLeft = -1

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet

        if (packet is StartGamePacket) {
            ticksLeft = WAIT_TICKS
            return
        }
        if (ticksLeft < 0 || packet !is PlayerAuthInputPacket) return

        ticksLeft--
        if (ticksLeft == 0) {
            ticksLeft = -1
            showWelcome()
        }
    }

    private fun showWelcome() {
        val name = session.localPlayer.username.ifBlank { "jugador" }
        session.clientBound(SetTitlePacket().apply {
            type = SetTitlePacket.Type.TIMES
            fadeInTime = 10
            stayTime = 60
            fadeOutTime = 20
        })
        session.clientBound(SetTitlePacket().apply {
            type = SetTitlePacket.Type.SUBTITLE
            text = "§7RNK Client v${BuildConfig.VERSION_NAME}"
        })
        session.clientBound(SetTitlePacket().apply {
            type = SetTitlePacket.Type.TITLE
            text = "§fBienvenido, §e$name"
        })
    }

    companion object {
        /** Ticks de movimiento (~50 ms cada uno) a esperar tras entrar: unos 2 segundos. */
        private const val WAIT_TICKS = 40
    }
}
