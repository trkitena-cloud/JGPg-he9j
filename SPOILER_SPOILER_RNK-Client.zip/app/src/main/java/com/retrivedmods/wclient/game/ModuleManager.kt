package com.retrivedmods.wclient.game

import android.content.Context
import android.net.Uri
import android.os.Environment
import com.retrivedmods.wclient.application.AppContext
import com.retrivedmods.wclient.game.module.combat.AntiCrystalModule
import com.retrivedmods.wclient.game.module.combat.AnchorAuraModule
import com.retrivedmods.wclient.game.module.combat.AnchorHelperModule
import com.retrivedmods.wclient.game.module.combat.SurroundModule
import com.retrivedmods.wclient.game.module.combat.CrystalAuraModule
import com.retrivedmods.wclient.game.module.combat.BedAuraModule
import com.retrivedmods.wclient.game.module.combat.PopCounterModule
import com.retrivedmods.wclient.game.module.combat.KiwiKillauraModule
import com.retrivedmods.wclient.game.module.motion.TestflyModule
import com.retrivedmods.wclient.game.module.motion.NoSlowDownModule
import com.retrivedmods.wclient.game.module.misc.TimerModule
import com.retrivedmods.wclient.game.module.combat.AntiKnockbackModule
import com.retrivedmods.wclient.game.module.combat.EnemyHunterModule
import com.retrivedmods.wclient.game.module.combat.HitboxModule
import com.retrivedmods.wclient.game.module.combat.AutoTotemModule
import com.retrivedmods.wclient.game.module.combat.HotbarSorterModule
import com.retrivedmods.wclient.game.module.combat.FakePlayerModule
import com.retrivedmods.wclient.game.module.combat.HeadLockModule
import com.retrivedmods.wclient.game.module.combat.RnkAuraModule
import com.retrivedmods.wclient.game.module.combat.MultiAuraModule
import com.retrivedmods.wclient.game.module.combat.RnkCrystalModule
import com.retrivedmods.wclient.game.module.combat.RnkCrystalMaxModule
import com.retrivedmods.wclient.game.module.combat.RnkCrystalSafeModule
import com.retrivedmods.wclient.game.module.combat.RnkGuardModule
import com.retrivedmods.wclient.game.module.combat.TriggerBotModule
import com.retrivedmods.wclient.game.module.combat.HotbarSwitcherModule
import com.retrivedmods.wclient.game.module.motion.NoClipModule
import com.retrivedmods.wclient.game.module.misc.AutoDisconnectModule
import com.retrivedmods.wclient.game.module.misc.CommandHandlerModule
import com.retrivedmods.wclient.game.module.misc.DesyncModule
import com.retrivedmods.wclient.game.module.misc.FakeDeathModule
import com.retrivedmods.wclient.game.module.misc.FakeXPModule
import com.retrivedmods.wclient.game.module.misc.MinerModule
import com.retrivedmods.wclient.game.module.misc.NoChatModule
import com.retrivedmods.wclient.game.module.misc.PieChartModule
import com.retrivedmods.wclient.game.module.misc.PositionLoggerModule
import com.retrivedmods.wclient.game.module.misc.ReplayModule
import com.retrivedmods.wclient.game.module.misc.ChestStealerModule
import com.retrivedmods.wclient.game.module.misc.SpammerModule
import com.retrivedmods.wclient.game.module.misc.ToggleSoundModule
import com.retrivedmods.wclient.game.module.misc.WaterMarkModule
import com.retrivedmods.wclient.game.module.world.AntiDebuffModule
import com.retrivedmods.wclient.game.module.world.EffectsModule
import com.retrivedmods.wclient.game.module.world.ParticlesModule
import com.retrivedmods.wclient.game.module.world.WeatherControllerModule
import com.retrivedmods.wclient.game.module.motion.AirJumpModule
import com.retrivedmods.wclient.game.module.motion.AntiAFKModule
import com.retrivedmods.wclient.game.module.motion.AutoWalkModule
import com.retrivedmods.wclient.game.module.motion.BhopModule
import com.retrivedmods.wclient.game.module.motion.FlyModule
import com.retrivedmods.wclient.game.module.motion.RnkFlyModule
import com.retrivedmods.wclient.game.module.motion.ScaffoldModule
import com.retrivedmods.wclient.game.module.motion.HighJumpModule
import com.retrivedmods.wclient.game.module.motion.JetPackModule
import com.retrivedmods.wclient.game.module.motion.MotionFlyModule
import com.retrivedmods.wclient.game.module.motion.PlayerTPModule
import com.retrivedmods.wclient.game.module.motion.SpeedModule
import com.retrivedmods.wclient.game.module.motion.SpiderModule
import com.retrivedmods.wclient.game.module.motion.SprintModule
import com.retrivedmods.wclient.game.module.visual.DamageTextModule
import com.retrivedmods.wclient.game.module.visual.ESPModule
import com.retrivedmods.wclient.game.module.visual.FullbrightModule
import com.retrivedmods.wclient.game.module.visual.SwingSpeedModule
import com.retrivedmods.wclient.game.module.misc.PerformanceModeModule
import com.retrivedmods.wclient.game.module.visual.MinimapModule
import com.retrivedmods.wclient.game.module.visual.NetworkInfoModule
import com.retrivedmods.wclient.game.module.visual.NoHurtCameraModule
import com.retrivedmods.wclient.game.module.visual.PlayerJoinModule
import com.retrivedmods.wclient.game.module.visual.SpeedDisplayModule
import com.retrivedmods.wclient.game.module.visual.ZoomModule
import com.retrivedmods.wclient.game.module.visual.TargetHudModule
import com.retrivedmods.wclient.game.module.world.FreeCameraModule
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import java.io.File

object ModuleManager {

    private val _modules: MutableList<Module> = ArrayList()

    val modules: List<Module> = _modules

    @Volatile
    var isLoadingConfig = false

    // Evita sobrescribir la config guardada con valores por defecto antes de haberla cargado.
    @Volatile
    private var configLoaded = false

    private val saveExecutor = java.util.concurrent.Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "WConfigSave").apply { isDaemon = true }
    }

    @Volatile
    private var autoSavePending = false

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }

    init {
        with(_modules) {
            // Combat
            add(HotbarSwitcherModule())
            add(AutoTotemModule())
            add(HotbarSorterModule())
            add(FakePlayerModule())
            add(HeadLockModule())
            add(RnkAuraModule())
            add(MultiAuraModule())
            add(RnkCrystalModule())
            add(RnkCrystalMaxModule())
            add(RnkCrystalSafeModule())
            add(RnkGuardModule())
            add(TriggerBotModule())
            add(EnemyHunterModule())
            add(AntiKnockbackModule())

            add(AntiCrystalModule())
            // --- Portados de KiwiMods ---
            add(AnchorAuraModule())
            add(AnchorHelperModule())
            add(SurroundModule())
            add(CrystalAuraModule())
            add(BedAuraModule())
            add(PopCounterModule())
            add(KiwiKillauraModule())
            add(TestflyModule())
            add(NoSlowDownModule())
            add(TimerModule())
            add(HitboxModule())

            // Motion
            add(MotionFlyModule())
            add(PlayerTPModule())
            add(FlyModule())
            add(RnkFlyModule())
            add(ScaffoldModule())
            add(SpeedModule())
            add(AirJumpModule())
            add(NoClipModule())
            add(JetPackModule())
            add(HighJumpModule())
            add(BhopModule())
            add(SprintModule())
            add(AutoWalkModule())
            add(AntiAFKModule())
            add(SpiderModule())

            // Visual
            add(DamageTextModule())
            add(ESPModule())
            add(PlayerJoinModule())
            add(ZoomModule())
            add(NoHurtCameraModule())
            add(SpeedDisplayModule())
            add(NetworkInfoModule())
            add(MinimapModule())
            add(TargetHudModule())
            add(FullbrightModule())
            add(PerformanceModeModule())
            add(com.retrivedmods.wclient.game.module.misc.WelcomeModule())
            add(com.retrivedmods.wclient.game.module.misc.GearInfoModule())
            add(com.retrivedmods.wclient.game.module.combat.HoleFillModule())
            add(com.retrivedmods.wclient.game.module.visual.NoRenderModule())
            add(SwingSpeedModule())

            // World
            add(FreeCameraModule())
            add(WeatherControllerModule())
            add(EffectsModule())
            add(ParticlesModule())
            add(AntiDebuffModule())

            // Misc

            add(AutoDisconnectModule())
            add(ToggleSoundModule())
            add(ChestStealerModule())
            add(DesyncModule())
            add(SpammerModule())
            add(WaterMarkModule())
            add(PositionLoggerModule())
            add(NoChatModule())
            add(CommandHandlerModule())
            add(ReplayModule())
            add(PieChartModule())
            add(FakeDeathModule())
            add(FakeXPModule())
            add(MinerModule())
        }
    }

    /** Autoguardado (como KiwiMods): 500 ms despues del primer cambio, guarda el estado mas reciente. */
    fun scheduleSave() {
        if (isLoadingConfig || !configLoaded || !AppContext.isInitialized) return
        if (autoSavePending) return
        autoSavePending = true
        saveExecutor.schedule({
            autoSavePending = false
            try {
                saveConfig()
            } catch (e: Throwable) {
                ModuleGuard.reportError("config", e)
            }
        }, 500, java.util.concurrent.TimeUnit.MILLISECONDS)
    }

    private fun configFile(): File? {
        if (!AppContext.isInitialized) return null
        val configsDir = AppContext.instance.filesDir.resolve("configs")
        configsDir.mkdirs()
        return configsDir.resolve("UserConfig.json")
    }

    private fun readBundledDefaultConfig(): String? = try {
        AppContext.instance.assets.open("default_config.json").bufferedReader().use { it.readText() }
    } catch (e: Exception) {
        null
    }

    @Synchronized
    fun saveConfig() {
        if (!configLoaded) return
        val config = configFile() ?: return

        val jsonObject = buildJsonObject {
            put("modules", buildJsonObject {
                _modules.forEach {
                    if (it.private) {
                        return@forEach
                    }
                    try {
                        put(it.name, it.toJson())
                    } catch (e: Throwable) {
                        ModuleGuard.reportError("config", e)
                    }
                }
            })
        }
        val text = json.encodeToString(JsonObject.serializer(), jsonObject)

        // Escritura atomica: si la app muere a mitad de escritura no se corrompe la config.
        val tmp = File(config.parentFile, "UserConfig.json.tmp")
        try {
            tmp.writeText(text)
            if (!tmp.renameTo(config)) {
                config.writeText(text)
                tmp.delete()
            }
        } catch (e: Exception) {
            ModuleGuard.reportError("config", e)
            try {
                config.writeText(text)
            } catch (_: Exception) {
            }
        }
    }

    /** Aplica la config a los modulos; un modulo con error no afecta a los demas. */
    private fun applyModules(modules: JsonObject): Int {
        var applied = 0
        val previous = isLoadingConfig
        isLoadingConfig = true
        try {
            _modules.forEach { module ->
                (modules[module.name] as? JsonObject)?.let {
                    try {
                        module.fromJson(it)
                        applied++
                    } catch (e: Throwable) {
                        ModuleGuard.reportError("config", e)
                    }
                }
            }
        } finally {
            isLoadingConfig = previous
        }
        return applied
    }

    fun loadConfig() {
        if (!AppContext.isInitialized) {
            return
        }

        com.retrivedmods.wclient.game.friend.FriendManager.load()
        com.retrivedmods.wclient.game.bind.BindManager.load()
        com.retrivedmods.wclient.util.UiColors.load()
        com.retrivedmods.wclient.util.Lang.load()

        try {
            val config = configFile() ?: return

            // Sin config guardada (primera vez): se usa la configuracion por defecto empaquetada
            // en assets/default_config.json. Al cambiar cualquier ajuste se guarda en UserConfig.json.
            val jsonString = if (config.exists()) config.readText() else readBundledDefaultConfig()
            if (jsonString.isNullOrBlank()) {
                return
            }

            val modules = json.parseToJsonElement(jsonString).jsonObject["modules"]?.jsonObject
                ?: return

            // Igual que KiwiMods: la config se aplica en el hilo principal.
            if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
                applyModules(modules)
            } else {
                val latch = java.util.concurrent.CountDownLatch(1)
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    try {
                        applyModules(modules)
                    } finally {
                        latch.countDown()
                    }
                }
                latch.await(5, java.util.concurrent.TimeUnit.SECONDS)
            }
        } catch (e: Exception) {
            ModuleGuard.reportError("config", e)
        } finally {
            configLoaded = true
        }
    }

    fun exportConfig(): String {
        val jsonObject = buildJsonObject {
            put("modules", buildJsonObject {
                _modules.forEach {
                    if (it.private) {
                        return@forEach
                    }
                    put(it.name, it.toJson())
                }
            })
        }
        return json.encodeToString(JsonObject.serializer(), jsonObject)
    }

    fun importConfig(configStr: String) {
        try {
            val jsonObject = json.parseToJsonElement(configStr).jsonObject
            val modules = jsonObject["modules"]?.jsonObject ?: return
            applyModules(modules)
            configLoaded = true
            scheduleSave()
        } catch (e: Exception) {
            throw IllegalArgumentException("Invalid config format: ${e.message}")
        }
    }

    fun exportConfigToFile(context: Context, filePath: String): Boolean {
        return try {
            val file = if (filePath.contains("/")) {
                File(filePath)
            } else {
                val configsDir = context.getExternalFilesDir("configs")
                configsDir?.mkdirs()
                File(configsDir, if (filePath.endsWith(".json")) filePath else "$filePath.json")
            }

            file.parentFile?.mkdirs()
            file.writeText(exportConfig())
            true
        } catch (e: Exception) {
            ModuleGuard.reportError("config", e)
            false
        }
    }

    private fun slotsDir(): File = AppContext.instance.filesDir.resolve("configs/slots").apply { mkdirs() }

    private fun slotFile(name: String): File =
        slotsDir().resolve(name.trim().replace(Regex("[^A-Za-z0-9_-]"), "_").take(40) + ".json")

    /** Configs guardadas con nombre (sin extension). */
    fun listConfigSlots(): List<String> {
        if (!AppContext.isInitialized) return emptyList()
        return slotsDir().listFiles { f -> f.extension == "json" }
            ?.map { it.nameWithoutExtension }?.sorted().orEmpty()
    }

    /** Guarda la configuracion actual con un nombre. */
    fun saveSlot(name: String): Boolean {
        if (!AppContext.isInitialized || name.isBlank()) return false
        return try {
            val current = configFile()
            if (current != null && !current.exists()) saveConfig()
            (current ?: return false).copyTo(slotFile(name), overwrite = true)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Carga una config guardada y la aplica (y la deja como actual). */
    fun loadSlot(name: String): Boolean {
        val file = slotFile(name)
        if (!file.exists()) return false
        return try {
            val modules = json.parseToJsonElement(file.readText()).jsonObject["modules"]?.jsonObject
                ?: return false
            applyModules(modules)
            saveConfig()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun deleteSlot(name: String) {
        slotFile(name).delete()
    }

    fun getWClientConfigsDirectory(): File? {
        return try {
            val documentsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)

            val baseDir = if (documentsDir.exists() || documentsDir.mkdirs()) {
                documentsDir
            } else {
                downloadsDir
            }

            val wclientDir = File(baseDir, "WClient")
            val configsDir = File(wclientDir, "configs")

            if (configsDir.exists() || configsDir.mkdirs()) {
                configsDir
            } else {
                null
            }
        } catch (e: Exception) {
            ModuleGuard.reportError("config", e)
            null
        }
    }

    fun importConfigFromFile(context: Context, uri: Uri): Boolean {
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val configStr = input.bufferedReader().readText()
                importConfig(configStr)
            }
            true
        } catch (e: Exception) {
            ModuleGuard.reportError("config", e)
            false
        }
    }
}