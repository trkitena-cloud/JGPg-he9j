package com.retrivedmods.wclient.overlay.gui.classic

import com.retrivedmods.wclient.util.Lang

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.SaveAlt
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import com.retrivedmods.wclient.util.UiColors
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.retrivedmods.wclient.game.ModuleManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*


private val CardBackgroundExpanded = Color(0xFF18181E)
private val AccentPrimary: Color get() = com.retrivedmods.wclient.util.UiColors.accent
private val TextPrimary = Color(0xFFF0F1F3)
private val TextTertiary = Color(0xFFAAA2B8)
private val ButtonBackground = Color(0xFF202028)

@Composable
fun ConfigurationScreen(
    snackbarHostState: SnackbarHostState,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val filePickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            if (ModuleManager.importConfigFromFile(context, it)) {
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("✅ Config imported successfully")
                }
            } else {
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("❌ Failed to import config")
                }
            }
        }
    }

    Column(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        ConfigurationHeader()
        LanguageSection()
        Spacer(Modifier.height(12.dp))
        UiColorSection()
        Spacer(Modifier.height(12.dp))
        ConfigSlotsSection(snackbarHostState)
        Spacer(Modifier.height(12.dp))
        ConfigurationActions(
            onImportClick = { filePickerLauncher.launch("application/json") },
            onExportClick = {
                coroutineScope.launch(Dispatchers.IO) {
                    val fileName = generateUniqueFileName()
                    val success = exportConfigToWClientFolder(fileName)
                    withContext(Dispatchers.Main) {
                        if (success) {
                            val configsDir = ModuleManager.getWClientConfigsDirectory()
                            val path = configsDir?.let { File(it, fileName).absolutePath } ?: "WClient/configs/$fileName"
                            snackbarHostState.showSnackbar("✅ Exported to: $path")
                        } else {
                            snackbarHostState.showSnackbar("❌ Failed to export config")
                        }
                    }
                }
            },
            onShareLogClick = {
                val msg = shareModuleGuardLog(context)
                coroutineScope.launch { snackbarHostState.showSnackbar(msg) }
            }
        )
    }
}

@Composable
private fun ConfigurationHeader() {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = "Configuration",
            color = TextPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            text = "Manage your configurations with ease",
            color = TextTertiary,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun ConfigurationActions(
    onImportClick: () -> Unit,
    onExportClick: () -> Unit,
    onShareLogClick: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.elevatedCardElevation(0.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = CardBackgroundExpanded)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ConfigActionButton(
                text = "Import Config",
                icon = Icons.Rounded.Upload,
                onClick = onImportClick
            )

            ConfigActionButton(
                text = "Export Config",
                icon = Icons.Rounded.SaveAlt,
                onClick = onExportClick
            )

            ConfigActionButton(
                text = "Share ModuleGuard Log",
                icon = Icons.Rounded.SaveAlt,
                onClick = onShareLogClick
            )
        }
    }
}

@Composable
private fun ConfigActionButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = ButtonBackground,
            contentColor = TextPrimary
        ),
        shape = RoundedCornerShape(6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(20.dp),
            tint = AccentPrimary
        )
        Spacer(Modifier.width(10.dp))
        Text(text = text, fontSize = 14.sp)
    }
}



private fun generateUniqueFileName(): String {
    val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
    val timestamp = dateFormat.format(Date())
    return "config_$timestamp.json"
}

private fun exportConfigToWClientFolder(fileName: String): Boolean {
    return try {
        val configsDir = ModuleManager.getWClientConfigsDirectory() ?: return false
        val file = File(configsDir, fileName)

        val configContent = ModuleManager.exportConfig()
        file.writeText(configContent)
        true
    } catch (e: Exception) {
        e.printStackTrace()
        false
    }
}

/**
 * Copia abysm-guard.log al cache de la app (cubierto por el FileProvider del manifest) y abre el
 * selector para compartirlo (Drive, Telegram, correo...). Devuelve un mensaje para mostrar.
 */
private fun shareModuleGuardLog(context: android.content.Context): String {
    val source = File(context.getExternalFilesDir(null) ?: context.filesDir, "abysm-guard.log")
    if (!source.exists() || source.length() == 0L) {
        return "No hay log todavia. Juega una sesion con los modulos activos y vuelve a intentar."
    }
    return try {
        val copy = File(context.cacheDir, "abysm-guard.log")
        source.copyTo(copy, overwrite = true)
        val uri = androidx.core.content.FileProvider.getUriForFile(
            context, "${context.packageName}.provider", copy
        )
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            putExtra(android.content.Intent.EXTRA_SUBJECT, "RNK Client ModuleGuard log")
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(
            android.content.Intent.createChooser(intent, "Compartir log").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        "Log listo para compartir"
    } catch (e: Exception) {
        "No se pudo compartir el log: ${e.message}"
    }
}

@Composable
private fun UiColorSection() {
    var hex by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.elevatedCardElevation(0.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = CardBackgroundExpanded)
    ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(Lang.t("Color de acento", "Accent color"), color = AccentPrimary, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                UiColors.presets.forEach { preset ->
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .background(preset.second, RoundedCornerShape(8.dp))
                            .clickable { UiColors.applyAccent(preset.second) }
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = hex,
                    onValueChange = { hex = it; error = "" },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("#RRGGBB") }
                )
                Button(onClick = {
                    error = if (UiColors.setAccentFromHex(hex)) "" else Lang.t("Usa 6 digitos hex, ej. #C0C6CF", "Use 6 hex digits, e.g. #C0C6CF")
                }) { Text(Lang.t("Aplicar", "Apply")) }
            }
            if (error.isNotEmpty()) Text(error, color = Color(0xFFFF6B6B), fontSize = 12.sp)
        }
    }
}

@Composable
private fun ConfigSlotsSection(snackbarHostState: SnackbarHostState) {
    val scope = rememberCoroutineScope()
    var slots by remember { mutableStateOf(ModuleManager.listConfigSlots()) }
    var name by remember { mutableStateOf("") }
    fun refresh() { slots = ModuleManager.listConfigSlots() }

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.elevatedCardElevation(0.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = CardBackgroundExpanded)
    ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(Lang.t("Configs guardadas", "Saved configs"), color = AccentPrimary, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(Lang.t("Nombre (ej. combate)", "Name (e.g. combat)")) }
                )
                Button(onClick = {
                    val n = name.trim()
                    if (n.isEmpty()) return@Button
                    val ok = ModuleManager.saveSlot(n)
                    refresh()
                    scope.launch { snackbarHostState.showSnackbar(if (ok) "Guardado: $n" else "No se pudo guardar") }
                }) { Text(Lang.t("Guardar", "Save")) }
            }
            if (slots.isEmpty()) {
                Text(Lang.t("Aun no tienes configs guardadas.", "You have no saved configs yet."), color = Color(0xFFB8B1C4), fontSize = 12.sp)
            }
            slots.forEach { slot ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(slot, modifier = Modifier.weight(1f), color = Color.White)
                    TextButton(onClick = {
                        val ok = ModuleManager.loadSlot(slot)
                        scope.launch { snackbarHostState.showSnackbar(if (ok) "Cargado: $slot" else "No se pudo cargar") }
                    }) { Text(Lang.t("Cargar", "Load")) }
                    TextButton(onClick = {
                        ModuleManager.deleteSlot(slot)
                        refresh()
                    }) { Text("Borrar") }
                }
            }
        }
    }
}

@Composable
private fun LanguageSection() {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.elevatedCardElevation(0.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = CardBackgroundExpanded)
    ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(Lang.t("Idioma", "Language"), color = AccentPrimary, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { Lang.set(true) }, enabled = !Lang.spanish) { Text("Español") }
                Button(onClick = { Lang.set(false) }, enabled = Lang.spanish) { Text("English") }
            }
        }
    }
}
