package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.entity.Player
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.GameType
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.packet.AddPlayerPacket
import org.cloudburstmc.protocol.bedrock.packet.BedrockPacket
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.MoveEntityAbsolutePacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.packet.RemoveEntityPacket
import java.util.UUID

/**
 * Jugador falso local. Se le envia al cliente de Minecraft un AddPlayerPacket para que lo dibuje,
 * y se mueve con MoveEntityAbsolutePacket. No se manda nada al servidor: los ataques dirigidos a
 * su id se descartan en GameSession.serverBound.
 */
class FakePlayerModule : Module("Fake Player", ModuleCategory.Combat) {

    private val distance by floatValue("Distance", 4.0f, 2.0f..12.0f)

    private var fake: Player? = null
    private var lastX = Float.NaN
    private var lastY = Float.NaN
    private var lastZ = Float.NaN

    override fun onEnabled() {
        super.onEnabled()
        spawn()
    }

    override fun onDisabled() {
        super.onDisabled()
        despawn()
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        if (interceptablePacket.packet !is PlayerAuthInputPacket) return
        val entity = fake ?: return

        val lp = session.localPlayer
        val x = lp.posX + distance
        val y = lp.posY
        val z = lp.posZ

        // Si el nivel se limpio (desconexion), lo volvemos a meter.
        if (session.level.entityMap[FAKE_ID] == null) session.level.entityMap[FAKE_ID] = entity

        // Solo mandamos movimiento al cliente si de verdad se movio, para no saturar la conexion.
        if (x != lastX || y != lastY || z != lastZ) {
            entity.move(x, y, z)
            lastX = x
            lastY = y
            lastZ = z
            session.clientBound(MoveEntityAbsolutePacket().apply {
                runtimeEntityId = FAKE_ID
                position = Vector3f.from(x, y, z)
                rotation = Vector3f.from(0f, 0f, 0f)
                onGround = true
                teleported = false
                forceMove = false
            })
        }
    }

    private fun spawn() {
        despawn()
        val lp = session.localPlayer
        val x = lp.posX + distance
        val y = lp.posY
        val z = lp.posZ

        val entity = Player(FAKE_ID, FAKE_ID, UUID.randomUUID(), "FakePlayer")
        entity.move(x, y, z)
        session.level.entityMap[FAKE_ID] = entity
        fake = entity
        lastX = x
        lastY = y
        lastZ = z
        active = true

        session.clientBound(AddPlayerPacket().apply {
            uuid = entity.uuid
            username = "FakePlayer"
            uniqueEntityId = FAKE_ID
            runtimeEntityId = FAKE_ID
            platformChatId = ""
            position = Vector3f.from(x, y, z)
            motion = Vector3f.ZERO
            rotation = Vector3f.from(0f, 0f, 0f)
            hand = ItemData.AIR
            deviceId = ""
            buildPlatform = 0
            gameType = GameType.SURVIVAL
        })
    }

    private fun despawn() {
        if (fake != null) {
            session.clientBound(RemoveEntityPacket().apply { uniqueEntityId = FAKE_ID })
        }
        session.level.entityMap.remove(FAKE_ID)
        fake = null
        active = false
    }

    companion object {
        const val FAKE_ID = -7777777L

        /** true si la entidad es el jugador falso (no debe ser objetivo de los auras). */
        fun isFake(uniqueEntityId: Long): Boolean = uniqueEntityId == FAKE_ID

        @Volatile
        var active = false
            private set

        /** true si el paquete es un ataque dirigido al jugador falso y no debe salir al servidor. */
        fun isBlockedServerBound(packet: BedrockPacket): Boolean {
            if (!active) return false
            if (packet !is InventoryTransactionPacket) return false
            return packet.transactionType == InventoryTransactionType.ITEM_USE_ON_ENTITY &&
                packet.runtimeEntityId == FAKE_ID
        }
    }
}
