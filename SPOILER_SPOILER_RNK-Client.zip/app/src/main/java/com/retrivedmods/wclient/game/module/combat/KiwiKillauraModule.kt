package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.entity.Entity
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.module.combat.rots.AbysmRot
import com.retrivedmods.wclient.game.module.combat.rots.GeoRot
import com.retrivedmods.wclient.game.module.combat.rots.HvHGod
import com.retrivedmods.wclient.game.module.combat.rots.KillauraRots
import com.retrivedmods.wclient.game.module.combat.rots.PredictiveRotator
import com.retrivedmods.wclient.game.kiwi.FriendManager
import com.retrivedmods.wclient.game.kiwi.entityFeetY
import com.retrivedmods.wclient.game.kiwi.hitboxHeight
import com.retrivedmods.wclient.game.kiwi.hitboxWidth
import com.retrivedmods.wclient.game.kiwi.localEyeY
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Killaura portado de KiwiMods (game/module/combat/KillauraModule) con las rotaciones de Lynx.
 *
 * Cada tick de PlayerAuthInputPacket se calculan los objetivos en rango (solo jugadores, con filtro
 * anti-bot), se orienta la rotacion enviada al servidor segun "Rot Mode" y, respetando el CPS, se
 * ataca a todos los objetivos en rango "Packets" veces cada uno (los amigos se saltan).
 *
 * Modos de rotacion:
 *  - Predictive (por defecto): rotacion suave con prediccion de movimiento del objetivo y, con
 *    "Camera Sync", giro visible de la camara. Se actualiza en cada tick (ver rots/PredictiveAim).
 *  - Kiwi: None, Snap, Normal, Silent, Body, Ping Predict, Lead Shot, Smooth, Strafe, Anticipate.
 *  - Lynx: Lynx Smooth, Nemesis, Vortex, FrontStrafe, AirHvH Pro, FrontsX, Astral, Atomic,
 *    Syntax, Cortex, Alpha (rots/KillauraRots). Se recalculan en cada tick de ataque y la
 *    rotacion se mantiene entre ataques.
 *
 * Diferencias a proposito:
 *  - No se incluyen Randomize, Legit ni Jitter de Kiwi, ni "Unified" de Lynx: son ruido aleatorio o
 *    topes de giro pensados para parecer humano ante detecciones; este port no incluye evasion.
 *  - El ojo del jugador local es posY (la Y de red del jugador local ya es a nivel de ojos); Kiwi le
 *    sumaba 1.62 de mas, lo que apuntaba por encima del objetivo.
 */
class KiwiKillauraModule : Module("kiwi_killaura", ModuleCategory.Combat) {

    private val range by floatValue("Range", 6.0f, 1.0f..20.0f)
    private val cps by intValue("CPS", 20, 5..30)
    private val packets by intValue("Packets", 1, 1..10)
    private val playersOnly by boolValue("Players Only", true)
    private val antiBot by boolValue("Anti Bot", true)
    private val rotMode by stringValue("Rot Mode", "Abysm", ROT_MODES)
    private val randomize by boolValue("Randomize", false)
    private val smoothSpeed by floatValue("Smooth Speed", 15.0f, 1.0f..45.0f)
    private val strafeAmp by floatValue("Strafe Amp", 8.0f, 0.0f..30.0f)
    private val vertOffset by floatValue("Vertical Offset", 0.3f, -1.0f..1.0f)

    // Solo aplican con Rot Mode = Predictive
    private val predTime by floatValue("Pred Time", 2.0f, 0.0f..8.0f)
    private val predStrength by floatValue("Pred Strength", 1.0f, 0.0f..1.5f)
    private val rotSmoothing by floatValue("Rot Smoothing", 0.35f, 0.05f..1.0f)
    private val rotMaxSpeed by floatValue("Rot Max Speed", 30.0f, 5.0f..90.0f)
    private val rotAccel by floatValue("Rot Accel", 12.0f, 2.0f..60.0f)
    // Camera Sync: ademas de la rotacion enviada al servidor, gira la camara visible del cliente.
    private val cameraSync by boolValue("Camera Sync", true)

    private var lastAttackTime = 0L
    private var tickCounter = 0L
    private var smoothYaw = 0f
    private var smoothPitch = 0f

    private val predRot = PredictiveRotator()
    private val hvhGod = HvHGod()
    private var lynxHasRot = false
    private var lynxPitch = 0f
    private var lynxYaw = 0f
    private var lynxHead = 0f

    override fun onEnabled() {
        super.onEnabled()
        lastAttackTime = 0L
        tickCounter = 0L
        resetRotationState()
    }

    override fun onDisabled() {
        super.onDisabled()
        resetRotationState()
    }

    private fun resetRotationState() {
        predRot.reset()
        hvhGod.reset()
        KillauraRots.resetState()
        lynxHasRot = false
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet
        if (packet !is PlayerAuthInputPacket) return

        tickCounter++
        val now = System.currentTimeMillis()
        val interval = 1000L / cps
        val targets = searchForTargets()
        val localPlayer = session.localPlayer

        if (rotMode == "HvHGod" || rotMode == "Abysm") {
            for (e in targets) hvhGod.observe(e.runtimeEntityId, e.rotationYaw, e.posX, session.entityFeetY(e), e.posZ, packet.tick)
            hvhGod.retain(targets.map { it.runtimeEntityId })
        }

        when {
            rotMode == "Abysm" && targets.isNotEmpty() -> {
                if (predRot.isOverriding) predRot.reset()
                lynxHasRot = false
                val t = targets.first()
                val feetY = session.entityFeetY(t)
                val chestY = feetY + if (t is Player) t.hitboxHeight() * 0.6f else 0.9f
                hvhGod.pick(t.runtimeEntityId, localPlayer.posX, localPlayer.posZ, packet.tick)
                val style = hvhGod.lastStyle
                val (p, y) = AbysmRot.aim(
                    t.posX, chestY, t.posZ,
                    t.motionX, t.motionY, t.motionZ,
                    localPlayer.posX, session.localEyeY(), localPlayer.posZ,
                    style
                )
                packet.rotation = Vector3f.from(p, y, y)
            }
            rotMode in GeoRot.MODES && targets.isNotEmpty() -> {
                if (predRot.isOverriding) predRot.reset()
                lynxHasRot = false
                val t = targets.first()
                val chestY = session.entityFeetY(t) + if (t is Player) t.hitboxHeight() * 0.6f else 0.9f
                val (ox, oy, oz) = GeoRot.offset(rotMode, packet.tick)
                val (p, y) = AbysmRot.aim(
                    t.posX + ox, chestY + oy, t.posZ + oz,
                    0f, 0f, 0f,
                    localPlayer.posX, session.localEyeY(), localPlayer.posZ,
                    com.retrivedmods.wclient.game.module.combat.rots.HvHGod.Style.UNKNOWN
                )
                packet.rotation = Vector3f.from(p, y, y)
            }
            rotMode == "Predictive" -> {
                // Se actualiza en cada tick, y tambien sin objetivos (vuelve suavemente a la camara real).
                val list = targets.toMutableList()
                if (predRot.update(session, packet, list, predictiveSettings())) {
                    packet.rotation = Vector3f.from(predRot.pitch, predRot.yaw, predRot.yaw)
                }
                if (list.isEmpty()) return
            }
            targets.isEmpty() -> {
                if (predRot.isOverriding) predRot.reset()
                AbysmRot.reset()
                lynxHasRot = false
                return
            }
            rotMode in LYNX_MODES -> {
                if (predRot.isOverriding) predRot.reset()
                val first = targets.first()
                if (now - lastAttackTime >= interval) computeLynxRotation(rotMode, first, packet, localPlayer)
                if (lynxHasRot) packet.rotation = Vector3f.from(lynxPitch, lynxYaw, lynxHead)
            }
            else -> {
                if (predRot.isOverriding) predRot.reset()
                if (!applyKiwiRotation(packet, targets.first(), localPlayer)) return
            }
        }

        if (now - lastAttackTime < interval) return
        for (target in targets) {
            if (target is Player && FriendManager.isFriend(target.uuid)) continue
            repeat(packets) { localPlayer.attack(target) }
        }
        lastAttackTime = now
    }

    // ------------------------------------------------------------------ Predictive

    private fun predictiveSettings() = PredictiveRotator.Settings(
        predTime = predTime,
        predStrength = predStrength,
        smoothing = rotSmoothing,
        maxSpeed = rotMaxSpeed,
        accel = rotAccel,
        cameraSync = cameraSync,
        vertOffset = vertOffset
    )

    // ------------------------------------------------------------------ Lynx (KillauraRots)

    private fun computeLynxRotation(mode: String, first: Entity, packet: PlayerAuthInputPacket, lp: LocalPlayer) {
        val eye = Vector3f.from(lp.posX, session.localEyeY(), lp.posZ)
        val chest = Vector3f.from(
            first.posX,
            session.entityFeetY(first) + first.hitboxHeight() * 0.55f + vertOffset,
            first.posZ
        )
        val (basePitch, baseYaw) = calcAngle(eye, chest)
        var fpitch = basePitch
        var fyaw = baseYaw
        while (fpitch > 90f) fpitch -= 180f
        while (fpitch < -90f) fpitch += 180f
        while (fyaw > 180f) fyaw -= 360f
        while (fyaw < -180f) fyaw += 360f

        val ctx = KillauraRots.Ctx(50f, 0.9f, 8f, 1f, 3f, 0.7f, 1.5f, 0.1f, 0.1f, 8, 20, vertOffset)
        ctx.rotPitch = fpitch
        ctx.rotYaw = fyaw
        ctx.headYaw = fyaw

        val env = KillauraRots.Env(
            lp.posX, session.localEyeY(), lp.posZ,
            lp.motionX, lp.motionY, lp.motionZ,
            packet.inputData.contains(PlayerAuthInputData.UP),
            packet.inputData.contains(PlayerAuthInputData.LEFT),
            packet.inputData.contains(PlayerAuthInputData.DOWN),
            packet.inputData.contains(PlayerAuthInputData.RIGHT),
            packet.inputData.contains(PlayerAuthInputData.JUMPING),
            System.nanoTime() / 1e9f
        )
        val snap = KillauraRots.Target(
            first.posX, session.entityFeetY(first), first.posZ,
            first.motionX, first.motionY, first.motionZ,
            first.rotationYaw, first.hitboxWidth(), first.hitboxHeight()
        )

        val effective = if (mode == "HvHGod") hvhGod.pick(first.runtimeEntityId, lp.posX, lp.posZ, packet.tick) else mode
        when (effective) {
            "Lynx Smooth" -> KillauraRots.smooth(ctx, snap, env)
            "Nemesis" -> KillauraRots.nemesis(ctx, snap, env)
            "Vortex" -> KillauraRots.vortex(ctx, snap, env)
            "FrontStrafe" -> KillauraRots.frontStrafe(ctx, snap, env, first.runtimeEntityId)
            "AirHvH Pro" -> KillauraRots.airHvHPro(ctx, snap, env)
            "FrontsX" -> KillauraRots.frontsX(ctx, snap, env)
            "Astral" -> KillauraRots.astral(ctx, snap, env)
            "Atomic" -> KillauraRots.atomic(ctx, snap, env)
            "Syntax" -> KillauraRots.syntax(ctx, snap, env)
            "Cortex" -> KillauraRots.cortex(ctx, snap, env)
            "Alpha" -> KillauraRots.alpha(ctx, snap, env)
        }
        lynxPitch = ctx.rotPitch
        lynxYaw = ctx.rotYaw
        lynxHead = ctx.headYaw
        lynxHasRot = true
    }

    // ------------------------------------------------------------------ Kiwi

    /** Devuelve false si el modo es "None" (no se toca la rotacion ni se ataca, como en Kiwi). */
    private fun applyKiwiRotation(packet: PlayerAuthInputPacket, first: Entity, localPlayer: LocalPlayer): Boolean {
        val eye = Vector3f.from(localPlayer.posX, session.localEyeY(), localPlayer.posZ)
        val (pitch, yaw) = calcAngle(eye, chestPos(first))

        val outPitch: Float
        val outYaw: Float
        when (rotMode) {
            "None" -> return false
            "Snap", "Normal", "Silent", "Body", "Ping Predict", "Lead Shot" -> {
                var p = pitch
                var y = yaw
                if (randomize) {
                    p += (kotlin.random.Random.nextFloat() - 0.5f) * 14.0f
                    y += (kotlin.random.Random.nextFloat() - 0.5f) * 14.0f
                }
                smoothPitch = p
                smoothYaw = y
                outPitch = p
                outYaw = y
            }
            "Jitter" -> {
                outPitch = pitch + (kotlin.random.Random.nextFloat() - 0.5f) * 14.0f
                outYaw = yaw + (kotlin.random.Random.nextFloat() - 0.5f) * 14.0f
            }
            "Smooth", "Legit" -> {
                var d = yaw - smoothYaw
                while (d > 180f) d -= 360f
                while (d < -180f) d += 360f
                val step = smoothSpeed
                if (abs(d) > step) d = if (d > 0f) step else -step
                smoothYaw += d
                smoothPitch += (pitch - smoothPitch) * 0.3f
                if (rotMode == "Legit" && abs(d) < 5.0f) {
                    smoothPitch += (kotlin.random.Random.nextFloat() - 0.5f) * 3.0f
                    smoothYaw += (kotlin.random.Random.nextFloat() - 0.5f) * 3.0f
                }
                outPitch = smoothPitch
                outYaw = smoothYaw
            }
            "Strafe" -> {
                val dx = first.posX - eye.x
                val dz = first.posZ - eye.z
                val k = min(sqrt(dx * dx + dz * dz) / 6.0f, 1.0f)
                outYaw = sin(tickCounter * 0.35f) * strafeAmp * k + yaw
                outPitch = pitch + cos(tickCounter * 0.22f) * strafeAmp * 0.25f * k
            }
            "Anticipate" -> {
                val rad = Math.toRadians(first.vec3Rotation.y.toDouble())
                val ahead = Vector3f.from(
                    first.posX - sin(rad).toFloat() * ANTICIPATE_DEPTH,
                    chestPos(first).y,
                    first.posZ + cos(rad).toFloat() * ANTICIPATE_DEPTH
                )
                val (p2, y2) = calcAngle(eye, ahead)
                outPitch = p2
                outYaw = y2
            }
            else -> return false
        }
        packet.rotation = Vector3f.from(outPitch, outYaw, outYaw)
        return true
    }

    // ------------------------------------------------------------------ objetivos

    private fun searchForTargets(): List<Entity> {
        val lp = session.localPlayer
        return session.level.entityMap.values
            .filter { it.distance(lp) <= range }
            .filter { isTarget(it) }
            .sortedBy { it.distance(lp) }
    }

    // Igual que Kiwi: solo se atacan jugadores y solo con "Players Only" activo.
    private fun isTarget(entity: Entity): Boolean {
        if (entity is LocalPlayer) return false
        if (entity !is Player) return false
        if (!playersOnly) return false
        // Los friends salen de la lista de objetivos: antes solo se saltaban al atacar y las
        // rotaciones seguian apuntando a targets.first() aunque fuera un friend.
        if (FriendManager.isFriend(entity.uuid)) return false
        return !(antiBot && isBot(entity))
    }

    private fun isBot(player: Player): Boolean {
        if (player is LocalPlayer) return false
        val entry = session.level.playerMap[player.uuid] ?: return true
        val name = entry.name?.toString().orEmpty()
        if (name.isBlank()) return true
        val xuid = entry.xuid.orEmpty()
        return xuid.isEmpty() || xuid == "0"
    }

    /** (pitch, yaw) en grados desde [from] hacia [to]; misma convencion que Kiwi. */
    private fun calcAngle(from: Vector3f, to: Vector3f): Pair<Float, Float> {
        val x = (to.x - from.x).toDouble()
        val y = (to.y - from.y).toDouble()
        val z = (to.z - from.z).toDouble()
        val dist = sqrt(x * x + y * y + z * z)
        val pitch = if (dist > 0.001) (-asin(y / dist) * RAD2DEG).toFloat() else 0f
        val yaw = (-atan2(x, z) * RAD2DEG).toFloat()
        return pitch to yaw
    }

    private fun chestPos(target: Entity): Vector3f = Vector3f.from(
        target.posX,
        session.entityFeetY(target) + if (target is Player) target.hitboxHeight() * 0.5f else 0.9f,
        target.posZ
    )

    private companion object {
        val KIWI_MODES = listOf(
            "None", "Snap", "Normal", "Silent", "Body", "Ping Predict", "Lead Shot",
            "Smooth", "Legit", "Jitter", "Strafe", "Anticipate"
        )
        val LYNX_MODES = listOf(
            "Lynx Smooth", "Nemesis", "Vortex", "FrontStrafe", "AirHvH Pro", "FrontsX",
            "Astral", "Atomic", "Syntax", "Cortex", "Alpha", "HvHGod"
        )
        val ROT_MODES = listOf("Abysm") + GeoRot.MODES + listOf("Predictive") + KIWI_MODES + LYNX_MODES
        const val RAD2DEG = 57.29577951308232
        const val ANTICIPATE_DEPTH = 3.0f
    }
}
