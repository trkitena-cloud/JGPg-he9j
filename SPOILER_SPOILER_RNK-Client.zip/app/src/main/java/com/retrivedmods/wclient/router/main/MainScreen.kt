package com.retrivedmods.wclient.router.main

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.retrivedmods.wclient.ui.theme.WColors
import com.retrivedmods.wclient.viewmodel.MainScreenViewModel

@Immutable
enum class MainScreenPages(
    val title: String,
    val icon: ImageVector,
    val content: @Composable () -> Unit
) {
    HomePage("Home", Icons.Rounded.Home, { HomePageContent() }),
    AccountPage("Account", Icons.Rounded.AccountCircle, { AccountPageContent() }),
    ServerPage("Servers", Icons.Rounded.Storage, { ServerPageContent() }),
    SettingsPage("Settings", Icons.Rounded.Settings, { SettingsPageContent() }),
    AboutPage("About", Icons.Rounded.Info, { AboutPageContent() })
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun MainScreen() {
    val vm: MainScreenViewModel = viewModel()
    val selectedPage by vm.selectedPage.collectAsStateWithLifecycle()
    val pages = remember { MainScreenPages.entries.toList() }
    var isDrawerOpen by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(WColors.Background)
    ) {
        AnimatedContent(
            targetState = selectedPage,
            transitionSpec = {
                slideInHorizontally(
                    initialOffsetX = { it / 3 },
                    animationSpec = tween(320, easing = FastOutSlowInEasing)
                ) + fadeIn(tween(240)) togetherWith
                        slideOutHorizontally(
                            targetOffsetX = { -it / 4 },
                            animationSpec = tween(280, easing = FastOutSlowInEasing)
                        ) + fadeOut(tween(200))
            },
            label = "page_transition"
        ) { page ->
            page.content()
        }

        IconButton(
            onClick = { isDrawerOpen = true },
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
                .size(48.dp)
                .background(WColors.SurfaceVariant, CircleShape)
                .zIndex(1f)
        ) {
            Icon(
                imageVector = Icons.Rounded.ArrowForward,
                contentDescription = "Open navigation",
                tint = WColors.Primary
            )
        }

        AnimatedVisibility(
            visible = isDrawerOpen,
            enter = fadeIn(tween(180)),
            exit = fadeOut(tween(150)),
            modifier = Modifier
                .fillMaxSize()
                .zIndex(2f)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.55f))
                        .clickable { isDrawerOpen = false }
                )

                Surface(
                    color = WColors.Surface,
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .fillMaxHeight()
                        .width(264.dp)
                        .animateEnterExit(
                            enter = slideInHorizontally(
                                initialOffsetX = { -it },
                                animationSpec = tween(220)
                            ),
                            exit = slideOutHorizontally(
                                targetOffsetX = { -it },
                                animationSpec = tween(180)
                            )
                        )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            IconButton(onClick = { isDrawerOpen = false }) {
                                Icon(
                                    imageVector = Icons.Rounded.ArrowBack,
                                    contentDescription = "Close navigation",
                                    tint = WColors.Primary
                                )
                            }
                            Text(
                                text = "Pages",
                                style = MaterialTheme.typography.titleLarge,
                                color = WColors.OnSurface
                            )
                        }

                        pages.forEach { page ->
                            val isSelected = page == selectedPage
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (isSelected) {
                                            WColors.Primary.copy(alpha = 0.16f)
                                        } else {
                                            Color.Transparent
                                        }
                                    )
                                    .clickable {
                                        if (selectedPage != page) vm.selectPage(page)
                                        isDrawerOpen = false
                                    }
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Icon(
                                    imageVector = page.icon,
                                    contentDescription = null,
                                    tint = if (isSelected) WColors.Primary else WColors.OnSurfaceVariant,
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = page.title,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = if (isSelected) WColors.Primary else WColors.OnSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
