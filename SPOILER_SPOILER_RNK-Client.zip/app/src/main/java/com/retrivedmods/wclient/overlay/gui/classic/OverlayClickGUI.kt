package com.retrivedmods.wclient.overlay.gui.classic

import androidx.compose.ui.draw.paint

import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.retrivedmods.wclient.R
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.ModuleContent
import com.retrivedmods.wclient.overlay.OverlayManager
import com.retrivedmods.wclient.overlay.OverlayWindow

private val DarkBackground = Color(0xFF0C0C10)
private val SidebarBackground = Color(0xFF141418)
private val HeaderBackground = Color(0xFF1C1823)
private val AccentPrimary: Color get() = com.retrivedmods.wclient.util.UiColors.accent
private val TextPrimary = Color(0xFFF0F1F3)
private val TextSecondary = Color(0xFFA8ADB5)
private val ButtonBackground = Color(0xFF202028)

class OverlayClickGUI : OverlayWindow() {

    private val _layoutParams by lazy {
        super.layoutParams.apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            val displayMetrics = OverlayManager.currentContext!!.resources.displayMetrics
            width = (displayMetrics.widthPixels * 0.92f).toInt()
            height = (displayMetrics.heightPixels * 0.92f).toInt()
            gravity = Gravity.CENTER
            // La GUI necesita el foco para que el teclado llegue a los campos de texto
            // (buscador, nombres de configs, binds, hex del color). La clase base lo bloquea.
            flags = flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
    }

    override val layoutParams: WindowManager.LayoutParams
        get() = _layoutParams

    private var selectedModuleCategory by mutableStateOf(ModuleCategory.Combat)

    @OptIn(ExperimentalAnimationApi::class)
    @Composable
    override fun Content() {
        val snackbarHostState = remember { SnackbarHostState() }

        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0x99000000))
                .clickable(
                    indication = null,
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
                ) {
                    OverlayManager.dismissOverlayWindow(this)
                },
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(10.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .paint(
                        painterResource(com.retrivedmods.wclient.R.drawable.abysm_background),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                        alpha = 0.22f
                    )
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xE6201B29),
                                Color(0xE6191620)
                            )
                        ),
                        RoundedCornerShape(14.dp)
                    )
                    .clickable(
                        indication = null,
                        interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
                    ) {}
            ) {
                Column(
                    modifier = Modifier.fillMaxSize()
                ) {
                    HeaderBar(
                        onClose = { OverlayManager.dismissOverlayWindow(this@OverlayClickGUI) }
                    )
                    MainArea(snackbarHostState)
                }

                SnackbarHost(
                    hostState = snackbarHostState,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                )
            }
        }
    }

    @Composable
    private fun HeaderBar(
        onClose: () -> Unit
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .background(HeaderBackground)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "RNK Client",
                    color = AccentPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            IconButton(onClick = onClose) {
                Icon(
                    Icons.Rounded.Close,
                    contentDescription = "Close",
                    tint = TextSecondary
                )
            }
        }
    }

    @OptIn(ExperimentalAnimationApi::class)
    @Composable
    private fun MainArea(snackbarHostState: SnackbarHostState) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            CategorySidebar()
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DarkBackground, RoundedCornerShape(12.dp))
                        .padding(20.dp)
            ) {
                AnimatedContent(
                    targetState = selectedModuleCategory,
                    transitionSpec = { EnterTransition.None togetherWith ExitTransition.None },
                    label = "CategoryContent"
                ) { category ->
                    if (category == ModuleCategory.Config) {
                        ConfigurationScreen(snackbarHostState = snackbarHostState)
                    } else if (category == ModuleCategory.Friends) {
                        com.retrivedmods.wclient.game.friend.FriendsScreen()
                    } else if (category == ModuleCategory.Binds) {
                        com.retrivedmods.wclient.game.bind.BindsScreen()
                    } else {
                        ModuleContent(category)
                    }
                }
            }
        }
    }

    @Composable
    private fun CategorySidebar() {
        val categories = remember { ModuleCategory.entries }

        LazyColumn(
            modifier = Modifier
                .width(92.dp)
                .fillMaxHeight()
                .background(SidebarBackground, RoundedCornerShape(12.dp))
                .padding(vertical = 14.dp, horizontal = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            items(categories.size) { index ->
                val category = categories[index]
                CategoryIcon(
                    category = category,
                    isSelected = selectedModuleCategory == category,
                    onClick = { selectedModuleCategory = category }
                )
            }
        }
    }

    @Composable
    private fun CategoryIcon(
        category: ModuleCategory,
        isSelected: Boolean,
        onClick: () -> Unit
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.clickable { onClick() }
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(
                        if (isSelected) AccentPrimary.copy(alpha = 0.2f) else Color.Transparent,
                        RoundedCornerShape(8.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(category.iconResId),
                    contentDescription = category.name,
                    tint = if (isSelected) Color(0xFFD0D4DB) else Color(0xFF827A8E),
                    modifier = Modifier.size(24.dp)
                )
            }
            Text(
                text = category.name,
                color = if (isSelected) Color(0xFFD0D4DB) else Color(0xFF9A92A6),
                fontSize = 10.sp,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}