package com.retrivedmods.wclient.util

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.retrivedmods.wclient.application.AppContext
import java.io.File

/**
 * Color de acento de la GUI (colorpicker). Lo leen las pantallas de Abysm; al cambiarlo se
 * redibujan solas porque es un estado de Compose. Se guarda en configs/ui_colors.txt.
 */
object UiColors {

    val presets: List<Pair<String, Color>> = listOf(
        "Plata" to Color(0xFFC0C6CF),
        "Blanco" to Color(0xFFF4F5F7),
        "Azul" to Color(0xFF6FA8FF),
        "Morado" to Color(0xFF9B6DFF),
        "Rojo" to Color(0xFFFF6B6B),
        "Verde" to Color(0xFF6BE58F)
    )

    var accent by mutableStateOf(presets.first().second)
        private set

    fun applyAccent(color: Color) {
        accent = color
        save(color)
    }

    /** Acepta #RRGGBB o RRGGBB. Devuelve false si el texto no es un color valido. */
    fun setAccentFromHex(text: String): Boolean {
        val hex = text.trim().removePrefix("#")
        if (!hex.matches(Regex("[0-9A-Fa-f]{6}"))) return false
        applyAccent(Color(0xFF000000L or hex.toLong(16)))
        return true
    }

    fun load() {
        val file = file() ?: return
        if (!file.exists()) return
        runCatching { setAccentFromHex(file.readText()) }
    }

    private fun save(color: Color) {
        val file = file() ?: return
        val hex = String.format("%06X", (color.toArgb() and 0xFFFFFF))
        runCatching { file.writeText(hex) }
    }

    private fun file(): File? {
        if (!AppContext.isInitialized) return null
        val dir = AppContext.instance.filesDir.resolve("configs")
        dir.mkdirs()
        return dir.resolve("ui_colors.txt")
    }
}
