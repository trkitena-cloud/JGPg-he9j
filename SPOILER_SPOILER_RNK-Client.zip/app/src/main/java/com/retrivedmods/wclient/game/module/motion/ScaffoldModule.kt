package com.retrivedmods.wclient.game.module.motion

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.kiwi.BlockPlacer
import com.retrivedmods.wclient.game.kiwi.entityFeetY
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import kotlin.math.floor
import kotlin.math.sqrt

/**
 * Scaffold: coloca bloques bajo tus pies en la direccion en la que te mueves (puente automatico).
 * Reescrito para RNK Client (la idea es parecida al Scaffold de Riveria V1).
 * Usa el bloque que llevas en la mano y solo coloca sobre un bloque solido contiguo (apoyo real).
 */
class ScaffoldModule : Module("Scaffold", ModuleCategory.Motion) {

    private val predictDistance by floatValue("Predict Distance", 1.1f, 0.3f..3.0f)
    private val placeDelay by intValue("Place Delay (ms)", 90, 30..500)
    private val placeRange by floatValue("Place Range", 4.0f, 2.0f..6.0f)

    private var lastPlaceTime = 0L
    private var lastX = 0f
    private var lastZ = 0f
    private var dirX = 0f
    private var dirZ = 0f
    private var initialized = false

    override fun onEnabled() {
        super.onEnabled()
        lastPlaceTime = 0L
        dirX = 0f
        dirZ = 0f
        initialized = false
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet
        if (packet !is PlayerAuthInputPacket) return

        val lp = session.localPlayer
        val curX = packet.position.x
        val curZ = packet.position.z

        val dx = curX - lastX
        val dz = curZ - lastZ
        lastX = curX
        lastZ = curZ
        if (!initialized) {
            initialized = true
            return
        }
        if (dx * dx + dz * dz > 0.0009f) {
            dirX = dx
            dirZ = dz
        }

        val now = System.currentTimeMillis()
        if (now - lastPlaceTime < placeDelay) return

        val len = sqrt(dirX * dirX + dirZ * dirZ)
        if (len < 0.0001f) return
        val nx = dirX / len
        val nz = dirZ / len

        // Bloque de la mano (debe ser un bloque colocable)
        val held = lp.inventory.hand
        if (held.count <= 0) return
        val identifier = held.definition?.identifier ?: return
        if (identifier == "minecraft:air") return
        val isBlock = try {
            session.blockMapping.definitionByIdentifier(identifier) != null
        } catch (_: Exception) {
            false
        }
        if (!isBlock) return

        val feetY = session.entityFeetY(lp)
        val target = Vector3i.from(
            floor(curX + nx * predictDistance).toInt(),
            floor(feetY).toInt() - 1,
            floor(curZ + nz * predictDistance).toInt()
        )

        if (!BlockPlacer.isPlaceableCell(session, target, placeRange)) return
        if (BlockPlacer.placeBlock(session, target, lp.inventory.heldItemSlot, identifier)) {
            lastPlaceTime = now
        }
    }
}
