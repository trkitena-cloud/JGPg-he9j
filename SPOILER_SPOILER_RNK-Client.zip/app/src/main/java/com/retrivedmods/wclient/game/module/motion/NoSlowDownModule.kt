package com.retrivedmods.wclient.game.module.motion

import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.kiwi.ItemUseState
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket

/**
 * NoSlowDown portado de KiwiMods (game/module/motion/NoSlowDownModule).
 *
 * Mientras usas un item (comer, arco, escudo...) Bedrock reduce tu velocidad. Este modulo detecta
 * el uso del item a partir del PlayerAuthInputPacket y compensa la perdida escalando el delta de
 * movimiento horizontal por (1 + Boost%/100) y desplazando la posicion en consecuencia.
 *
 * Diferencia con Kiwi: alli el estado "usando item" quedaba activo para siempre tras el primer
 * uso (el flag se releia a si mismo). Aqui expira a los 4 s del ultimo inicio de uso.
 */
class NoSlowDownModule : Module("no_slow_down", ModuleCategory.Motion) {

    private val forceSprint by boolValue("Force Sprint", false)
    private val boostPercent by intValue("Boost %", 185, 0..300)

    private var lastUseStart = 0L

    override fun onDisabled() {
        super.onDisabled()
        ItemUseState.using = false
        lastUseStart = 0L
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet
        if (packet !is PlayerAuthInputPacket || !isSessionCreated) return

        val now = System.currentTimeMillis()
        val started = packet.inputData.contains(PlayerAuthInputData.START_USING_ITEM)
        val interacted = packet.inputData.contains(PlayerAuthInputData.PERFORM_ITEM_INTERACTION) &&
            packet.itemUseTransaction != null && packet.itemUseTransaction.actionType == 1
        if (started || interacted) lastUseStart = now

        val using = started || interacted || now - lastUseStart < USE_WINDOW_MS
        ItemUseState.using = using
        if (!using) return

        if (forceSprint) {
            packet.inputData.remove(PlayerAuthInputData.STOP_SPRINTING)
            if (!packet.inputData.contains(PlayerAuthInputData.SPRINTING)) {
                packet.inputData.add(PlayerAuthInputData.START_SPRINTING)
                packet.inputData.add(PlayerAuthInputData.SPRINTING)
            }
        }

        val mult = boostPercent / 100f + 1f
        if (mult > 1.001f) {
            val delta = packet.delta ?: return
            val nx = delta.x * mult
            val nz = delta.z * mult
            val pos = packet.position
            packet.position = Vector3f.from(pos.x + (nx - delta.x), pos.y, pos.z + (nz - delta.z))
            packet.delta = Vector3f.from(nx, delta.y, nz)
        }
    }

    private companion object {
        const val USE_WINDOW_MS = 4000L
    }
}
