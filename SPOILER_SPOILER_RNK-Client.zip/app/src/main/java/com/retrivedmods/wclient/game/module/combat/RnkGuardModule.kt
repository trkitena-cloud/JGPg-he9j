package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.kiwi.BlockPlacer
import com.retrivedmods.wclient.game.kiwi.FriendManager
import com.retrivedmods.wclient.game.kiwi.entityFeetY
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import kotlin.math.floor

/**
 * RNK Guard: pone obsidiana en los 4 lados de tu celda (adelante, atras, izquierda, derecha)
 * SOLO en los lados que estan libres, asi los cristales/anclas no te dan por los lados.
 *  - Necesita obsidiana en la barra de acceso rapido.
 *  - Los lados que ya tienen un bloque se saltan (no gasta obsidiana de mas).
 *  - Primero cubre los lados que miran al enemigo mas cercano.
 *  - "Head Level": ademas cubre la altura de la cabeza. "Only With Enemy": solo actua con un enemigo cerca.
 *  - Cambia de ranura en silencio (solo el servidor) y vuelve a la ranura de la mano.
 */
class RnkGuardModule : Module("RNK Guard", ModuleCategory.Combat) {

    private val delay by intValue("Delay (ms)", 60, 0..500)
    private val maxPerTick by intValue("Max Per Tick", 2, 1..4)
    private val headLevel by boolValue("Head Level", false)
    private val onlyWithEnemy by boolValue("Only With Enemy", true)
    private val enemyRange by floatValue("Enemy Range", 10.0f, 3.0f..20.0f)
    private val reach by floatValue("Reach", 5.0f, 2.0f..6.0f)

    private var lastPlaceTime = 0L

    override fun onEnabled() {
        super.onEnabled()
        lastPlaceTime = 0L
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet
        if (packet !is PlayerAuthInputPacket) return

        val now = System.currentTimeMillis()
        if (now - lastPlaceTime < delay) return

        val lp = session.localPlayer

        // Enemigo mas cercano (para decidir si actuar y para ordenar los lados)
        var nearest: Player? = null
        var nearestDist = Float.MAX_VALUE
        for (e in session.level.entityMap.values) {
            if (e !is Player || e === lp || FriendManager.isFriend(e.uuid)) continue
            if (FakePlayerModule.isFake(e.uniqueEntityId)) continue
            val d = e.distance(lp)
            if (d < nearestDist) {
                nearestDist = d
                nearest = e
            }
        }
        if (onlyWithEnemy && (nearest == null || nearestDist > enemyRange)) return

        val slot = BlockPlacer.findObsidianSlot(session) ?: return

        val bx = floor(lp.posX).toInt()
        val by = floor(session.entityFeetY(lp) + 0.5f).toInt()
        val bz = floor(lp.posZ).toInt()

        // Lados: (dx, dz). Se ordenan: primero los mas cercanos al enemigo.
        val sides = arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))
        val en = nearest
        if (en != null) {
            sides.sortBy { s ->
                val cx = bx + 0.5f + s[0]
                val cz = bz + 0.5f + s[1]
                (cx - en.posX) * (cx - en.posX) + (cz - en.posZ) * (cz - en.posZ)
            }
        }

        val cells = ArrayList<Vector3i>()
        for (s in sides) {
            cells.add(Vector3i.from(bx + s[0], by, bz + s[1]))
            if (headLevel) cells.add(Vector3i.from(bx + s[0], by + 1, bz + s[1]))
        }

        var placed = 0
        var switched = false
        for (cell in cells) {
            // Solo lados libres (aire/reemplazable, sin entidades, conocidos)
            if (!BlockPlacer.isPlaceableCell(session, cell, reach)) continue
            if (!switched) {
                BlockPlacer.sendServerSlot(session, slot)
                switched = true
            }
            if (BlockPlacer.tryPlaceWithSupport(session, cell, slot, reach, "minecraft:obsidian", 2)) {
                placed++
                if (placed >= maxPerTick) break
            }
        }
        if (switched) {
            BlockPlacer.sendServerSlot(session, lp.inventory.heldItemSlot)
            lastPlaceTime = now
        }
    }
}
