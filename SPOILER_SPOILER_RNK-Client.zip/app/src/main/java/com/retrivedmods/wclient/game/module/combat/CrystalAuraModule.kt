package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.ModuleGuard
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.entity.Entity
import com.retrivedmods.wclient.game.entity.EntityUnknown
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.kiwi.BlockPlacer
import com.retrivedmods.wclient.game.kiwi.FriendManager
import com.retrivedmods.wclient.game.kiwi.ItemUseState
import com.retrivedmods.wclient.game.kiwi.attackEntityId
import com.retrivedmods.wclient.game.kiwi.entityFeetY
import com.retrivedmods.wclient.game.kiwi.toRotation
import com.retrivedmods.wclient.game.utils.constants.Attribute
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.ItemUseTransaction
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.packet.ChangeDimensionPacket
import org.cloudburstmc.protocol.bedrock.packet.StartGamePacket
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sqrt

/**
 * CrystalAura portado de KiwiMods (game/module/combat/KiwiCrystalModule).
 *
 * Cada tick: toma los jugadores cercanos como objetivos (los amigos no), genera las posiciones donde
 * colocar un cristal sobre obsidiana/bedrock con la simulacion de explosion (dano al objetivo >=
 * "Enemy Damage" y dano propio <= "Self Damage"), y rompe los cristales cuyo dano cumple lo mismo.
 * "ID Predict" ademas golpea los siguientes runtime IDs de cristal. Con "Rotate" la rotacion del
 * paquete de input apunta al cristal/posicion de la accion.
 *
 * Notas del port:
 *  - El overlay de render de Kiwi (vacio en el original) no se porta.
 *  - "ID Damage" de Kiwi no se usaba en ningun sitio, asi que no se incluye.
 *  - La rotacion se escribe en el propio PlayerAuthInputPacket en vez de interceptarlo y reenviar
 *    una copia (mismo resultado para el servidor, y los demas modulos siguen viendo el paquete).
 *  - Los registros de colocacion caducan al segundo (ver KiwiWorld.isPlacementPending).
 */
class CrystalAuraModule : Module("crystal_aura", ModuleCategory.Combat) {

    private val placeEnabled by boolValue("Place", true)
    private val breakEnabled by boolValue("Break", true)
    private val placeDelay by intValue("Place Delay", 0, 0..20)
    private val breakDelay by intValue("Break Delay", 0, 0..20)
    private val eatStop by boolValue("Eat Stop", true)
    private val targetRange by floatValue("Target Range", 12.0f, 1.0f..20.0f)
    private val placeRange by floatValue("Place Range", 6.0f, 1.0f..12.0f)
    private val breakRange by floatValue("Break Range", 6.0f, 1.0f..12.0f)
    private val enemyDamage by floatValue("Enemy Damage", 4.0f, 0.0f..20.0f)
    private val selfDamageLimit by floatValue("Self Damage", 6.0f, 0.0f..20.0f)
    // Safe Mode: nunca coloca/rompe un cristal que te baje la vida por debajo de "Min Health" ni que
    // te haga mas dano a ti que al enemigo.
    private val safeMode by boolValue("Safe Mode", true)
    private val minHealth by floatValue("Min Health", 6.0f, 1.0f..20.0f)
    private val rotate by boolValue("Rotate", true)
    private val wasteAmount by intValue("Waste Amount", 4, 1..10)
    private val self by boolValue("Self", false)
    private val idPredict by boolValue("ID Predict", false)
    private val idPackets by intValue("ID Packets", 4, 1..20)
    private val obsidianOnly by boolValue("Obsidian Only", true)
    private val debug by boolValue("Debug", false)

    private class Box(val minX: Float, val minY: Float, val minZ: Float, val maxX: Float, val maxY: Float, val maxZ: Float) {
        fun intersects(o: Box) =
            minX < o.maxX && maxX > o.minX && minY < o.maxY && maxY > o.minY && minZ < o.maxZ && maxZ > o.minZ
    }

    private class PlaceData(val support: Vector3i, val crystalCenter: Vector3f, val targetDamage: Float, val localDamage: Float)
    private class BreakData(val crystal: EntityUnknown, val targetDamage: Float, val localDamage: Float)

    private val placeList = ArrayList<PlaceData>()
    private val breakList = ArrayList<BreakData>()
    private val allEntities = ArrayList<Entity>()

    private var highestCrystalId = -1L
    private var lastActionTick = 0L
    private var lastBreakTime = 0L
    private var lastPlaceTime = 0L
    private var lastDebugTime = 0L
    private var lastGenTime = 0L
    private var lastPredictMs = 0L
    private val PREDICT_MIN_MS = 100L
    // Escaneo reanudable: se reparte entre ticks con un presupuesto fijo para no bloquear el hilo de red.
    private var scanActive = false
    private var scanTargets: List<Entity> = emptyList()
    private var scanBlockers: List<Box> = emptyList()
    private var scanTargetIdx = 0
    private var scanOffIdx = 0
    private var scanPlayer: LocalPlayer? = null
    private var scanPlayerFeet = Vector3f.ZERO
    private var scanRange = 0
    private var scanRange2 = 0f
    private val scanVisited = HashSet<Vector3i>()
    private val scanResult = ArrayList<PlaceData>()
    private val SCAN_BUDGET_NS = 3_000_000L
    private var lastBreakGenTime = 0L
    private var oldSlot = -1
    private var serverSlot = -1
    private var cachedBlockVersion = -1L
    private var cachedTargetSig = ""
    private var cachedPlayerCell: Vector3i? = null

    override fun onEnabled() {
        super.onEnabled()
        placeList.clear()
        breakList.clear()
        allEntities.clear()
        highestCrystalId = -1L
        lastPlaceTime = 0L
        lastBreakTime = 0L
        lastActionTick = 0L
        lastGenTime = 0L
        oldSlot = -1
        serverSlot = -1
        cachedBlockVersion = -1L
        cachedTargetSig = ""
        cachedPlayerCell = null
    }

    override fun onDisabled() {
        super.onDisabled()
        if (oldSlot >= 0 && isSessionCreated && serverSlot != oldSlot) {
            BlockPlacer.sendServerSlot(session, oldSlot)
        }
        placeList.clear()
        breakList.clear()
        allEntities.clear()
        oldSlot = -1
        serverSlot = -1
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet
        if (packet is StartGamePacket || packet is ChangeDimensionPacket) {
            resetForWorldChange()
            return
        }
        if (packet !is PlayerAuthInputPacket) return
        if (packet.tick == lastActionTick) return
        lastActionTick = packet.tick
        pendingRotation = null
        onTick(packet)
        pendingRotation?.let { rot ->
            // El relay reenvia los bytes originales: un cambio en sitio no llega al servidor.
            // Se envia una copia rotada y se descarta el original (igual que Kiwi).
            val clone = packet.clone()
            clone.rotation = rot
            session.serverBound(clone)
            interceptablePacket.intercept()
        }
    }

    private var pendingRotation: Vector3f? = null

    /** Limpia todo lo que depende del mundo actual: sin esto, al entrar al End se usan datos del overworld. */
    private fun resetForWorldChange() {
        placeList.clear()
        breakList.clear()
        scanActive = false
        scanTargets = emptyList()
        scanBlockers = emptyList()
        scanTargetIdx = 0
        scanOffIdx = 0
        scanResult.clear()
        scanVisited.clear()
        lastPublishedSize = -1
        highestCrystalId = -1L
        lastActionTick = 0L
        lastGenTime = 0L
        lastBreakGenTime = 0L
        lastBreakTime = 0L
        lastPredictMs = 0L
        cachedBlockVersion = -1L
        cachedTargetSig = ""
        cachedPlayerCell = null
    }

    private fun onTick(input: PlayerAuthInputPacket) {
        val lp = session.localPlayer
        val now = System.currentTimeMillis()
        if (eatStop && ItemUseState.using) return

        allEntities.clear()

        val targets = ArrayList<Entity>()
        for (e in session.level.entityMap.values) {
            allEntities.add(e)
            if (e is Player && e !== lp && feetDistance(e, lp) <= targetRange && !FriendManager.isFriend(e.uuid) &&
                !FakePlayerModule.isFake(e.uniqueEntityId)) {
                targets.add(e)
            }
        }
        if (self) targets.add(lp)

        if (targets.isEmpty()) {
            if (oldSlot >= 0) restoreSlot()
            placeList.clear()
            return
        }
        if (targets.size > 1) targets.sortBy { feetDistance(it, lp) }

        val crystalSlot = if (placeEnabled) findCrystalSlot() else null
        if (placeEnabled && crystalSlot == null) {
            if (oldSlot >= 0) restoreSlot()
            placeList.clear()
            return
        }

        if (placeEnabled && crystalSlot != null) {
            val sig = targets.joinToString(";") { "${it.runtimeEntityId}:${floor(it.posX).toInt()},${floor(it.posZ).toInt()}" }
            val cell = Vector3i.from(
                floor(lp.posX).toInt(), floor(session.entityFeetY(lp) + 0.5f).toInt(), floor(lp.posZ).toInt()
            )
            val stale = placeList.isEmpty() || cachedBlockVersion != session.kiwiWorld.blockVersion ||
                cachedTargetSig != sig || cachedPlayerCell != cell
            // Como mucho arranca un escaneo nuevo cada GEN_INTERVAL_MS; cada tick solo gasta SCAN_BUDGET_NS.
            if (!scanActive && stale && now - lastGenTime >= GEN_INTERVAL_MS) {
                startScan(lp, targets)
                lastGenTime = now
                cachedBlockVersion = session.kiwiWorld.blockVersion
                cachedTargetSig = sig
                cachedPlayerCell = cell
            }
            if (scanActive) {
                val done = try {
                    scanStep(System.nanoTime() + SCAN_BUDGET_NS)
                } catch (t: Throwable) {
                    scanActive = false
                    scanResult.clear()
                    placeList.clear()
                    ModuleGuard.reportError("crystal_aura.scan", t)
                    true
                }
                // Publicar lo encontrado ya, sin esperar a terminar el escaneo completo.
                if (scanResult.isNotEmpty() || done) publishCrystalResults()
                if (done) {
                    scanActive = false
                    log { "Checked ${scanVisited.size} supports, valid=${placeList.size}" }
                }
            }
        }

        // Throttle del escaneo de cristales: antes se recalculaba en cada tick (el coste principal del log).
        var nearCrystals: List<EntityUnknown> = emptyList()
        if (breakEnabled) {
            nearCrystals = session.kiwiWorld.crystalsNear(breakRange)
            if (now - lastBreakGenTime >= GEN_INTERVAL_MS) {
                generateBreakList(lp, targets, nearCrystals)
                lastBreakGenTime = now
            }
        } else {
            breakList.clear()
        }
        if (breakList.isNotEmpty()) breakList.removeAll { b -> nearCrystals.none { it === b.crystal } }
        log { "Targets=${targets.size} crystals=${nearCrystals.size} placeList=${placeList.size} breakList=${breakList.size}" }

        var acted = false
        if (breakEnabled && breakList.isNotEmpty() && now - lastBreakTime >= breakDelay * 50L) {
            attackCrystals()
            lastBreakTime = now
            acted = true
        }
        if (placeEnabled && placeList.isNotEmpty() && crystalSlot != null && now - lastPlaceTime >= placeDelay * 50L) {
            placeCrystals(crystalSlot)
            lastPlaceTime = now
            acted = true
        }

        // Como Kiwi: la prediccion de ID corre en cada tick mientras haya posiciones validas,
        // no solo justo despues de colocar (antes dependia del placeDelay y llegaba tarde).
        if (idPredict && placeList.isNotEmpty()) doIdPredict()

        if (rotate && acted) {
            val aim: Vector3f = breakList.firstOrNull()?.crystal?.vec3Position
                ?: placeList.firstOrNull()?.crystalCenter
                ?: targets.first().vec3Position
            val eye = Vector3f.from(lp.posX, session.entityFeetY(lp) + 1.62f, lp.posZ)
            val rot = toRotation(eye, aim)
            pendingRotation = Vector3f.from(rot.pitch, rot.yaw, rot.yaw)
        }
    }

    private var offsetsRange = -1
    private var offsetsCache: List<IntArray> = emptyList()

    /** Desplazamientos (dx, dy, dz) ordenados del centro hacia fuera: lo mas cercano al objetivo primero. */
    private fun offsetsFor(range: Int): List<IntArray> {
        if (range != offsetsRange) {
            val list = ArrayList<IntArray>()
            for (dx in -range..range) for (dz in -range..range) for (dy in -4..4) list.add(intArrayOf(dx, dy, dz))
            list.sortBy { it[0] * it[0] + it[2] * it[2] + it[1] * it[1] }
            offsetsCache = list
            offsetsRange = range
        }
        return offsetsCache
    }

    private var lastPublishedSize = -1

    private fun startScan(player: LocalPlayer, targets: List<Entity>) {
        lastPublishedSize = -1
        scanPlayer = player
        scanTargets = targets.toList()
        scanBlockers = allEntities
            .filter { it !== player && it !in targets && it !is EntityUnknown }
            .map { entityBox(it) }
        scanPlayerFeet = Vector3f.from(player.posX, session.entityFeetY(player), player.posZ)
        scanRange = placeRange.toInt()
        scanRange2 = placeRange * placeRange
        scanVisited.clear()
        scanResult.clear()
        scanTargetIdx = 0
        scanOffIdx = 0
        scanActive = true
    }

    /** Avanza el escaneo hasta agotar el presupuesto. Devuelve true cuando ya no queda nada. */
    private fun publishCrystalResults() {
        // No reordenar ni copiar si no hay resultados nuevos desde la ultima publicacion.
        if (scanResult.size == lastPublishedSize) return
        lastPublishedSize = scanResult.size
        scanResult.sortByDescending { it.targetDamage - it.localDamage * 0.8f }
        placeList.clear()
        placeList.addAll(scanResult)
    }

    private fun scanStep(deadline: Long): Boolean {
        val player = scanPlayer ?: return true
        val world = session.kiwiWorld
        val airId = session.blockMapping.airId
        val offsets = offsetsFor(scanRange)
        while (scanTargetIdx < scanTargets.size) {
            val target = scanTargets[scanTargetIdx]
            val tx = floor(target.posX).toInt()
            val ty = floor(session.entityFeetY(target)).toInt()
            val tz = floor(target.posZ).toInt()
            while (scanOffIdx < offsets.size) {
                if (System.nanoTime() > deadline) return false
                val off = offsets[scanOffIdx++]
                val support = Vector3i.from(tx + off[0], ty + off[1], tz + off[2])
                if (!scanVisited.add(support)) continue

                val center = Vector3f.from(support.x + 0.5f, support.y + 0.5f, support.z + 0.5f)
                if (center.distanceSquared(scanPlayerFeet) > scanRange2) continue

                if (!world.isBlockKnown(support)) {
                    world.requestBlockData(support)
                    continue
                }
                val rid = world.getBlockRuntimeId(support)
                if (rid == airId || rid == 0) continue
                if (obsidianOnly) {
                    val id = try { session.blockMapping.getDefinition(rid).identifier } catch (_: Exception) { null }
                    if (id == null || !(id.contains("obsidian") || id.contains("bedrock"))) continue
                }

                val above1 = Vector3i.from(support.x, support.y + 1, support.z)
                val above2 = Vector3i.from(support.x, support.y + 2, support.z)
                if (!world.isBlockKnown(above1)) {
                    world.requestBlockData(above1)
                    continue
                }
                if (!world.isBlockKnown(above2)) {
                    world.requestBlockData(above2)
                    continue
                }
                val r1 = world.getBlockRuntimeId(above1)
                val r2 = world.getBlockRuntimeId(above2)
                if (!((r1 == airId || r1 == 0) && (r2 == airId || r2 == 0))) continue
                if (world.crystalExistsAtSupport(support)) continue

                val crystalCenter = Vector3f.from(support.x + 0.5f, support.y + 1.5f, support.z + 0.5f)
                if (scanTargets.none { it.vec3Position.distanceSquared(crystalCenter) < 144f }) continue

                val space = Box(
                    support.x.toFloat(), support.y + 1.0f, support.z.toFloat(),
                    support.x + 1.0f, support.y + 3.0f, support.z + 1.0f
                )
                if (scanBlockers.any { it.intersects(space) }) continue

                var targetDamage = 0f
                for (t in scanTargets) {
                    if (t === player) continue
                    targetDamage += world.explosionDamageTo(crystalCenter, t, 12f, true)
                }
                val localDamage = world.explosionDamageTo(crystalCenter, player, 12f, true)
                if (targetDamage >= enemyDamage && localDamage <= selfDamageLimit && isSafe(player, localDamage, targetDamage)) {
                    scanResult.add(PlaceData(support, crystalCenter, targetDamage, localDamage))
                }
            }
            scanTargetIdx++
            scanOffIdx = 0
        }
        return true
    }

    private fun generateBreakList(player: LocalPlayer, targets: List<Entity>, nearCrystals: List<EntityUnknown>) {
        breakList.clear()
        val seen = HashSet<Long>()
        for (crystal in nearCrystals) {
            if (!seen.add(crystal.runtimeEntityId)) continue
            if (crystal.runtimeEntityId > highestCrystalId || highestCrystalId == -1L) {
                highestCrystalId = crystal.runtimeEntityId
            }
            val pos = crystal.vec3Position
            var maxTarget = 0f
            for (t in targets) maxTarget = max(maxTarget, session.kiwiWorld.explosionDamageTo(pos, t))
            val local = session.kiwiWorld.explosionDamageTo(pos, player)
            if (local <= selfDamageLimit && maxTarget >= enemyDamage && isSafe(player, local, maxTarget)) {
                breakList.add(BreakData(crystal, maxTarget, local))
            }
        }
        breakList.sortByDescending { it.targetDamage - it.localDamage * 0.8f }
    }

    /** Safe Mode: el dano propio no puede dejarte por debajo de Min Health ni superar el dano al enemigo. */
    private fun isSafe(player: LocalPlayer, localDamage: Float, targetDamage: Float): Boolean {
        if (!safeMode) return true
        val health = player.attributes[Attribute.HEALTH]?.value ?: 20f
        return health - localDamage >= minHealth && localDamage <= targetDamage
    }

    private fun entityBox(e: Entity): Box {
        val feet = session.entityFeetY(e)
        return Box(e.posX - 0.3f, feet, e.posZ - 0.3f, e.posX + 0.3f, feet + 1.8f, e.posZ + 0.3f)
    }

    private fun attackCrystals() {
        var n = 0
        for (b in breakList) {
            session.localPlayer.attack(b.crystal)
            n++
            if (n >= wasteAmount) break
        }
        if (n > 0) log { "Attacked $n crystals" }
    }

    private fun placeCrystals(crystalSlot: Int) {
        val lp = session.localPlayer
        val world = session.kiwiWorld
        if (oldSlot == -1) oldSlot = lp.inventory.heldItemSlot
        if (serverSlot != crystalSlot) {
            BlockPlacer.sendServerSlot(session, crystalSlot)
            serverSlot = crystalSlot
        }
        var n = 0
        for (p in placeList) {
            if (world.crystalExistsAtSupport(p.support) || world.isPlacementPending(p.support)) continue
            var def = world.knownDefinition(p.support)
            if (def == null) {
                world.requestBlockData(p.support)
                def = session.blockMapping.definitionByIdentifier("minecraft:obsidian")
            }
            session.serverBound(InventoryTransactionPacket().apply {
                transactionType = InventoryTransactionType.ITEM_USE
                actionType = 0
                blockPosition = p.support
                blockFace = 1
                hotbarSlot = crystalSlot
                itemInHand = lp.inventory.content[crystalSlot]
                playerPosition = lp.vec3Position
                clickPosition = Vector3f.from(0.5f, 0.5f, 0.5f)
                blockDefinition = def
                triggerType = ItemUseTransaction.TriggerType.PLAYER_INPUT
                clientInteractPrediction = ItemUseTransaction.PredictedResult.SUCCESS
            })
            lp.swing()
            world.registerPlacement(p.support, "minecraft:obsidian")
            log { "Placed at ${p.support} targetDmg=${"%.1f".format(p.targetDamage)} selfDmg=${"%.1f".format(p.localDamage)}" }
            n++
            if (n >= wasteAmount) break
        }
        restoreSlot()
        // Despues de colocar: el cristal recien puesto ya es el mas alto visto, asi que la prediccion
        // apunta a los IDs siguientes (antes se llamaba antes de colocar y tomaba el cristal viejo).
    }

    /** Golpea los siguientes IDs de entidad tras el cristal mas alto visto (el recien colocado). */
    private fun doIdPredict() {
        if (placeList.isEmpty() || !idPredict) return
        // Limite: como mucho una rafaga cada PREDICT_MIN_MS. Antes se mandaba en cada tick (20/s),
        // y con muchos cristales eso saturaba la conexion y el servidor cortaba por tiempo de espera.
        val nowMs = System.currentTimeMillis()
        if (nowMs - lastPredictMs < PREDICT_MIN_MS) return
        lastPredictMs = nowMs
        val base = max(highestCrystalId, session.kiwiWorld.highestCrystalRuntimeId)
        if (base < 0) return
        val first = base + 1
        for (i in 0 until idPackets) session.attackEntityId(first + i, false)
        log { "ID predict: $first..${first + idPackets - 1}" }
    }

    private fun findCrystalSlot(): Int? {
        val inv = session.localPlayer.inventory
        for (i in 0 until 9) {
            val item = inv.content[i]
            val id = item.definition?.identifier ?: continue
            if ((id.contains("end_crystal") || id.contains("ender_crystal")) && item.count > 0) return i
        }
        return null
    }

    private fun feetDistance(a: Entity, b: Entity): Float {
        val dy = session.entityFeetY(a) - session.entityFeetY(b)
        val dx = a.posX - b.posX
        val dz = a.posZ - b.posZ
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    private fun restoreSlot() {
        val old = oldSlot
        if (old == -1) return
        if (serverSlot != old) BlockPlacer.sendServerSlot(session, old)
        serverSlot = old
        oldSlot = -1
    }

    private inline fun log(message: () -> String) {
        if (!debug) return
        val now = System.currentTimeMillis()
        if (now - lastDebugTime < 1000) return
        session.displayClientMessage("[Kiwi] ${message()}")
        lastDebugTime = now
    }

    private companion object {
        const val GEN_INTERVAL_MS = 100L
        const val GEN_BUDGET_NS = 8_000_000L
    }
}
