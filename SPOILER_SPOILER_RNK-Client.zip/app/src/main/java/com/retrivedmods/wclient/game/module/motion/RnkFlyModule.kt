package com.retrivedmods.wclient.game.module.motion

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.Ability
import org.cloudburstmc.protocol.bedrock.data.AbilityLayer
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.data.PlayerPermission
import org.cloudburstmc.protocol.bedrock.data.command.CommandPermission
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.packet.SetEntityMotionPacket
import org.cloudburstmc.protocol.bedrock.packet.UpdateAbilitiesPacket
import kotlin.math.cos
import kotlin.math.sin

/**
 * RNK Fly: vuelo aparte (no reemplaza a Fly ni MotionFly).
 * Movimiento horizontal y vertical con rampa de aceleracion (suave, sin "robotico"), hover
 * (se queda en el aire sin teclas) y envio de movimiento en CADA tick.
 */
class RnkFlyModule : Module("RNK Fly", ModuleCategory.Motion) {

    private val horizontalSpeed by floatValue("Horizontal", 1.2f, 0.1f..6.0f)
    private val verticalSpeed by floatValue("Vertical", 0.8f, 0.1f..4.0f)
    private val accel by floatValue("Accel", 0.5f, 0.05f..1.0f)
    private val hover by boolValue("Hover", true)

    private var curX = 0f
    private var curY = 0f
    private var curZ = 0f
    private var canFly = false

    private fun abilitiesPacket(enabled: Boolean) = UpdateAbilitiesPacket().apply {
        playerPermission = if (enabled) PlayerPermission.OPERATOR else PlayerPermission.VISITOR
        commandPermission = if (enabled) CommandPermission.OWNER else CommandPermission.ANY
        uniqueEntityId = session.localPlayer.uniqueEntityId
        abilityLayers.add(AbilityLayer().apply {
            layerType = AbilityLayer.Type.BASE
            abilitiesSet.addAll(Ability.entries.toTypedArray())
            val flags = mutableListOf(
                Ability.BUILD,
                Ability.MINE,
                Ability.DOORS_AND_SWITCHES,
                Ability.OPEN_CONTAINERS,
                Ability.ATTACK_PLAYERS,
                Ability.ATTACK_MOBS,
                Ability.OPERATOR_COMMANDS,
                Ability.FLY_SPEED,
                Ability.WALK_SPEED
            )
            if (enabled) flags.add(Ability.MAY_FLY)
            abilityValues.addAll(flags)
            walkSpeed = 0.1f
            flySpeed = if (enabled) 0.5f else 0.05f
        })
    }

    private fun applyFlyAbilities(enabled: Boolean) {
        if (canFly != enabled) {
            session.clientBound(abilitiesPacket(enabled))
            canFly = enabled
        }
    }

    override fun onDisabled() {
        super.onDisabled()
        curX = 0f
        curY = 0f
        curZ = 0f
        if (isSessionCreated) applyFlyAbilities(false)
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        val packet = interceptablePacket.packet
        if (!isEnabled || packet !is PlayerAuthInputPacket) return

        applyFlyAbilities(true)

        val input = packet.inputData
        val up = input.contains(PlayerAuthInputData.JUMPING) || input.contains(PlayerAuthInputData.WANT_UP)
        val down = input.contains(PlayerAuthInputData.SNEAKING) || input.contains(PlayerAuthInputData.WANT_DOWN)
        val targetY = when {
            up -> verticalSpeed
            down -> -verticalSpeed
            else -> 0f
        }

        val yawRad = Math.toRadians(packet.rotation.y.toDouble()).toFloat()
        val strafe = packet.motion.x * horizontalSpeed
        val forward = packet.motion.y * horizontalSpeed
        val targetX = strafe * cos(yawRad) - forward * sin(yawRad)
        val targetZ = forward * cos(yawRad) + strafe * sin(yawRad)

        curX += (targetX - curX) * accel
        curY += (targetY - curY) * accel
        curZ += (targetZ - curZ) * accel

        if (hover || curX != 0f || curY != 0f || curZ != 0f) {
            val motionPacket = SetEntityMotionPacket().apply {
                runtimeEntityId = session.localPlayer.runtimeEntityId
                motion = Vector3f.from(curX, curY, curZ)
            }
            session.clientBound(motionPacket)
        }
    }
}
