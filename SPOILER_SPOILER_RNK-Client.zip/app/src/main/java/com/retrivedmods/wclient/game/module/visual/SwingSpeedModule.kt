package com.retrivedmods.wclient.game.module.visual

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.data.Effect
import org.cloudburstmc.protocol.bedrock.packet.MobEffectPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket

/**
 * SwingSpeed (visual): cambia la velocidad de la animacion de golpe de tu mano.
 *
 * La velocidad del swing la decide el cliente segun tus efectos: Haste la acelera y Mining Fatigue
 * la frena. El modulo se manda a si mismo (solo hacia el cliente, nunca al servidor) uno de esos
 * efectos con particulas ocultas, asi que el servidor no se entera; solo cambia lo que ves.
 *
 *  - Fast:       Haste, mas nivel = swing mas rapido.
 *  - Slow:       Mining Fatigue, mas nivel = swing mas lento.
 *  - Ultra Slow: Mining Fatigue a nivel muy alto: el swing tarda varios segundos.
 *
 * Nota: como Haste / Mining Fatigue tambien afectan la velocidad con que el cliente predice que
 * rompes bloques, esa prediccion visual cambia igual (el servidor sigue mandando).
 */
class SwingSpeedModule : Module("swing_speed", ModuleCategory.Visual) {

    private val mode by stringValue("Mode", "Slow", MODES)
    private val level by intValue("Level", 3, 1..10)
    /** Solo para Ultra Slow: duracion aproximada de un golpe, en segundos. */
    private val ultraSeconds by intValue("Ultra Seconds", 10, 2..15)

    /** Efecto aplicado ahora mismo (para quitar el anterior si cambias de modo). */
    private var appliedEffect = -1

    override fun onDisabled() {
        super.onDisabled()
        if (isSessionCreated) {
            removeEffect(Effect.HASTE)
            removeEffect(Effect.MINING_FATIGUE)
        }
        appliedEffect = -1
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet
        if (packet !is PlayerAuthInputPacket) return

        val (effect, amplifier) = when (mode) {
            "Fast" -> Effect.HASTE to level
            "Ultra Slow" -> Effect.MINING_FATIGUE to ultraAmplifier()
            else -> Effect.MINING_FATIGUE to level
        }

        // Cambio de modo: se quita el efecto contrario de inmediato.
        if (appliedEffect != -1 && appliedEffect != effect) {
            removeEffect(appliedEffect)
            appliedEffect = -1
        }

        // Se renueva cada segundo (y al instante tras cambiar de efecto) para que no caduque.
        if (appliedEffect == effect && session.localPlayer.tickExists % 20 != 0L) return
        appliedEffect = effect
        session.clientBound(MobEffectPacket().apply {
            runtimeEntityId = session.localPlayer.runtimeEntityId
            event = MobEffectPacket.Event.ADD
            effectId = effect
            this.amplifier = amplifier
            isParticles = false
            duration = 360000
        })
    }

    private fun ultraAmplifier(): Int = secondsToAmplifier(ultraSeconds)

    private fun removeEffect(effect: Int) {
        session.clientBound(MobEffectPacket().apply {
            runtimeEntityId = session.localPlayer.runtimeEntityId
            event = MobEffectPacket.Event.REMOVE
            effectId = effect
        })
    }

    companion object {
        private val MODES = listOf("Fast", "Slow", "Ultra Slow")

        /**
         * Swing ~ 6 + (nivel + 1) * 2 ticks (20 ticks = 1 s). Con 10 s el nivel sale ~96,
         * igual que el 100 fijo de antes.
         */
        private fun secondsToAmplifier(seconds: Int): Int = (seconds * 10 - 4).coerceIn(0, 127)
    }
}
