package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.kiwi.FriendManager
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket

/**
 * Multi Aura (RNK): killaura simple con tres modos de objetivo.
 *  - Single: golpea solo al mas cercano.
 *  - Switch: rota entre los jugadores en rango cada "Switch Delay" ms.
 *  - Multi: golpea a todos los jugadores en rango en cada ciclo.
 * No cambia rotacion ni posicion: solo envia ataques. El servidor valida el alcance.
 */
class MultiAuraModule : Module("Multi Aura", ModuleCategory.Combat) {

    private val range by floatValue("Range", 6.0f, 2.0f..12.0f)
    private val cps by intValue("CPS", 14, 1..30)
    private val packets by intValue("Packets", 1, 1..5)
    private val mode by stringValue("Target Mode", "Multi", listOf("Single", "Switch", "Multi"))
    private val switchDelay by intValue("Switch Delay (ms)", 100, 20..500)
    private val swing by boolValue("Swing", true)
    private val antiBot by boolValue("Anti Bot", true)

    private var lastAttack = 0L
    private var lastSwitch = 0L
    private var switchIndex = 0

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled || interceptablePacket.packet !is PlayerAuthInputPacket) return
        val now = System.currentTimeMillis()
        if (now - lastAttack < 1000L / cps) return

        val lp = session.localPlayer
        val targets = session.level.entityMap.values
            .filterIsInstance<Player>()
            .filter { valid(it, lp) }
            .sortedBy { it.distance(lp) }
        if (targets.isEmpty()) return

        when (mode) {
            "Single" -> repeat(packets) { lp.attack(targets.first()) }
            "Switch" -> {
                if (now - lastSwitch >= switchDelay) {
                    switchIndex = (switchIndex + 1) % targets.size
                    lastSwitch = now
                }
                repeat(packets) { lp.attack(targets[switchIndex % targets.size]) }
            }
            else -> targets.forEach { t -> repeat(packets) { lp.attack(t) } }
        }
        if (swing) lp.swing()
        lastAttack = now
    }

    private fun valid(e: Player, lp: LocalPlayer): Boolean {
        if (e === lp || e is LocalPlayer) return false
        if (FakePlayerModule.isFake(e.uniqueEntityId)) return false
        if (FriendManager.isFriend(e.uuid)) return false
        if (e.distance(lp) > range) return false
        if (antiBot) {
            val name = session.level.playerMap[e.uuid]?.name?.toString().orEmpty()
            if (name.isBlank()) return false
        }
        return true
    }
}
