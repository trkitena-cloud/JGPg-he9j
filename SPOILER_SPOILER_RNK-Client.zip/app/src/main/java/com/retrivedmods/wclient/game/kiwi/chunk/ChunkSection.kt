package com.retrivedmods.wclient.game.kiwi.chunk

import android.util.Log
import io.netty.buffer.ByteBuf
import com.retrivedmods.wclient.game.kiwi.chunk.palette.BitArrayVersion
import com.retrivedmods.wclient.game.kiwi.chunk.palette.Pow2BitArray
import org.cloudburstmc.protocol.common.util.VarInts

class ChunkSection {

    var storage = BlockStorage(BitArrayVersion.V2, 0)

    /** true si la subchunk traia datos de bloques (false = sin capas: seccion de aire). */
    var hasRealStorage = false

    /**
     * Lee una subchunk en formato de red (igual que KiwiMods). Cabecera de la version 9:
     *   byte version, byte numero de capas, byte indice Y de la subchunk.
     * (Antes se leia el indice Y como numero de capas y todo el resto del chunk quedaba desalineado.)
     * Ante cualquier fallo lanza la excepcion: quien llama deja esa subchunk como "desconocida".
     */
    fun read(buf: ByteBuf) {
        val version = buf.readByte().toInt()
        if (version != 1 && version !in 8..10) {
            error("Unsupported chunk version: $version")
        }
        val layers = if (version == 1) 1 else buf.readByte().toInt()
        if (version >= 9) buf.readByte() // indice Y de la subchunk (no se necesita)
        if (layers <= 0) {
            storage = BlockStorage(BitArrayVersion.V2, 0)
            hasRealStorage = false
            return
        }
        storage = BlockStorage(buf, true)
        hasRealStorage = true
        // Capas adicionales (p. ej. liquidos): se leen para dejar el buffer bien alineado.
        repeat(layers - 1) {
            BlockStorage(buf, true)
        }
    }

    fun write(buffer: ByteBuf, useRuntime: Boolean, legacy: Boolean) {
        val subChunkVersion: Byte = 9
        val blockLayerCount: Byte = 1

        buffer.writeByte(subChunkVersion.toInt())
        buffer.writeByte(blockLayerCount.toInt())

        writeStorageLayer(buffer, storage)
    }

    private fun writeStorageLayer(buffer: ByteBuf, storage: BlockStorage) {
        val bitArray = storage.bitArray
        val words = bitArray.getWords()

        
        buffer.writeByte((bitArray.getVersion().bits shl 1) or 1)
        buffer.writeShortLE(words.size)

        for (word in words) {
            buffer.writeIntLE(word)
        }

        
        VarInts.writeInt(buffer, storage.palette.size)
        for (runtimeId in storage.palette) {
            VarInts.writeInt(buffer, runtimeId)
        }
    }


    fun getBlock(x: Int, y: Int, z: Int): Int {
        return storage.getBlock(x, y, z)
    }

    fun setBlock(x: Int, y: Int, z: Int, id: Int) {
        storage.setBlock(x, y, z, id)
    }
}
