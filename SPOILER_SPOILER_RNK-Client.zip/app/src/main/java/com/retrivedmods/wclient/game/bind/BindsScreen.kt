package com.retrivedmods.wclient.game.bind

import com.retrivedmods.wclient.util.Lang

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.retrivedmods.wclient.game.ModuleManager
import com.retrivedmods.wclient.util.translatedSelf
import kotlinx.coroutines.delay

private val CardColor = Color(0xFF221D2C)
private val OnColor = Color(0xFFC0C6CF)
private val OffColor = Color(0xFF6E747D)
private val MutedText = Color(0xFFB8B1C4)

/** Pestana Binds: crear grupos de modulos y activarlos/desactivarlos juntos con un toque. */
@Composable
fun BindsScreen() {
    var binds by remember { mutableStateOf(BindManager.all()) }
    var newName by remember { mutableStateOf("") }
    var newModules by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        while (true) {
            binds = BindManager.all()
            delay(500)
        }
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Binds", color = OnColor, style = MaterialTheme.typography.titleMedium)
            Text(
                Lang.t("Un bind enciende o apaga varios modulos a la vez. Toca el nombre para activarlo.", "A bind turns several modules on or off at once. Tap its name to activate it."),
                color = MutedText,
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(10.dp))
        }

        items(binds.entries.toList(), key = { it.key }) { (name, ids) ->
            val on = BindManager.isOn(name)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardColor, RoundedCornerShape(10.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { BindManager.toggle(name) }
                ) {
                    Text(name, color = Color.White, style = MaterialTheme.typography.bodyLarge, maxLines = 1)
                    Text(
                        ids.joinToString(", ") { id -> id.translatedSelf },
                        color = MutedText,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1
                    )
                }
                Text(
                    if (on) "ON" else "OFF",
                    color = if (on) OnColor else OffColor,
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier
                        .clickable { BindManager.toggle(name) }
                        .padding(horizontal = 8.dp)
                )
                Text(
                    Lang.t("Borrar", "Delete"),
                    color = OffColor,
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier
                        .clickable { BindManager.remove(name); binds = BindManager.all() }
                        .padding(4.dp)
                )
            }
        }

        item {
            Spacer(Modifier.height(16.dp))
            Text(Lang.t("Crear bind", "Create bind"), color = OnColor, style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text(Lang.t("Nombre (ej. Combate)", "Name (e.g. Combat)")) }
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = newModules,
                onValueChange = { newModules = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text(Lang.t("Modulos separados por coma (ej. killaura, crystal aura)", "Modules separated by commas (e.g. killaura, crystal aura)")) }
            )
            Spacer(Modifier.height(6.dp))
            Text(
                Lang.t("Crear", "Create"),
                color = OnColor,
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier
                    .clickable {
                        val name = newName.trim()
                        if (name.isEmpty()) { status = "Ponle un nombre al bind."; return@clickable }
                        val ids = newModules.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                            .mapNotNull { wanted ->
                                ModuleManager.modules.firstOrNull { m ->
                                    !m.private && (m.name.equals(wanted, true) ||
                                        m.name.translatedSelf.equals(wanted, true))
                                }?.name
                            }
                        if (ids.isEmpty()) { status = "Ningun modulo coincide con esos nombres."; return@clickable }
                        BindManager.put(name, ids)
                        binds = BindManager.all()
                        status = "Bind \"$name\" creado con ${ids.size} modulos."
                        newName = ""
                        newModules = ""
                    }
                    .padding(4.dp)
            )
            if (status.isNotEmpty()) Text(status, color = MutedText, style = MaterialTheme.typography.bodySmall)
        }
    }
}
