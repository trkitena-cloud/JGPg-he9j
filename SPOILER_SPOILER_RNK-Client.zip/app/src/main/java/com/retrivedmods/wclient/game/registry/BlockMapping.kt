package com.retrivedmods.wclient.game.registry

import android.content.Context
import org.cloudburstmc.nbt.NBTInputStream
import org.cloudburstmc.nbt.NbtList
import com.retrivedmods.wrelay.util.BlockPaletteUtils
import org.cloudburstmc.nbt.NbtMap
import org.cloudburstmc.protocol.common.DefinitionRegistry
import java.io.DataInputStream
import java.util.zip.GZIPInputStream

class BlockMapping(
    private val runtimeToGameMap: Map<Int, BlockDefinition>,
    val airId: Int = 0
) : DefinitionRegistry<org.cloudburstmc.protocol.bedrock.data.definitions.BlockDefinition> {

    private val gameToRuntimeMap = mutableMapOf<BlockDefinition, Int>()

    init {
        runtimeToGameMap.forEach { (k, v) -> gameToRuntimeMap[v] = k }
    }

    override fun getDefinition(runtimeId: Int): BlockDefinition {
        return runtimeToGameMap[runtimeId] ?: UnknownBlockDefinition(runtimeId)
    }

    override fun isRegistered(definition: org.cloudburstmc.protocol.bedrock.data.definitions.BlockDefinition): Boolean {
        return definition is UnknownBlockDefinition || getDefinition(definition.runtimeId) == definition
    }

    /** Todos los runtime IDs (una por combinacion de estados) de un bloque, p. ej. respawn_anchor. */
    fun runtimeIdsByIdentifier(identifier: String): Set<Int> =
        runtimeToGameMap.entries.filter { it.value.identifier == identifier }.map { it.key }.toSet()

    /** Primera definicion con ese identificador; si se indica [states], la que los contiene. */
    fun definitionByIdentifier(identifier: String, states: NbtMap? = null): BlockDefinition? {
        val matches = runtimeToGameMap.values.filter { it.identifier == identifier }
        if (states == null || states.isEmpty()) return matches.firstOrNull()
        return matches.firstOrNull { def -> states.all { (k, v) -> def.states[k] == v } } ?: matches.firstOrNull()
    }

    /**
     * Mismo contenido pero con el runtime id = hash FNV-1a del estado del bloque.
     * Es lo que usan los servidores con `blockNetworkIdsHashed` (todos los modernos): los IDs que llegan
     * en los chunks son hashes, no posiciones secuenciales, asi que el mapa estatico no los reconocia
     * (el aire no coincidia con ninguna celda y todo el mundo parecia "bloque desconocido").
     */
    fun toHashed(): BlockMapping {
        val hashed = LinkedHashMap<Int, BlockDefinition>(runtimeToGameMap.size)
        var air = 0
        for (def in runtimeToGameMap.values) {
            val tag = NbtMap.builder()
                .putString("name", def.identifier)
                .putCompound("states", def.states)
                .build()
            val hash = BlockPaletteUtils.createHash(tag)
            hashed[hash] = BlockDefinition(hash, def.identifier, def.states)
            if (def.identifier == "minecraft:air") air = hash
        }
        return BlockMapping(hashed, air)
    }

    companion object {
        /** Mapa construido con la paleta que manda el servidor en StartGamePacket (si no esta vacia). */
        fun fromServerPalette(palette: List<NbtMap>): BlockMapping {
            val map = LinkedHashMap<Int, BlockDefinition>(palette.size)
            var air = 0
            palette.forEachIndexed { index, entry ->
                val runtimeId = if (entry.containsKey("runtimeId")) entry.getInt("runtimeId") else index
                val name = entry.getString("name")
                map[runtimeId] = BlockDefinition(runtimeId, name, entry.getCompound("states") ?: NbtMap.EMPTY)
                if (name == "minecraft:air") air = runtimeId
            }
            return BlockMapping(map, air)
        }

        fun read(context: Context, version: Short): BlockMapping {
            val path = "mcpedata/blocks/runtime_block_states_$version.dat"
            context.assets.open(path).use { stream ->
                val gzipStream = GZIPInputStream(stream)
                val nbtInput = NBTInputStream(DataInputStream(gzipStream))

                @Suppress("unchecked_cast")
                val tag = nbtInput.readTag() as NbtList<NbtMap>
                val runtimeToBlock = mutableMapOf<Int, BlockDefinition>()
                var airId = 0

                tag.forEach { subtag ->
                    val runtime = subtag.getInt("runtimeId")
                    val name = subtag.getString("name")
                    if (name == "minecraft:air") airId = runtime
                    runtimeToBlock[runtime] = BlockDefinition(runtime, name, subtag.getCompound("states") ?: NbtMap.EMPTY)
                }

                return BlockMapping(runtimeToBlock, airId)
            }
        }
    }

}