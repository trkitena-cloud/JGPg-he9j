package com.retrivedmods.wclient.game.module.misc

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.ModuleManager
import com.retrivedmods.wclient.game.friend.FriendManager
import com.retrivedmods.wclient.game.entity.Player
import org.cloudburstmc.protocol.bedrock.data.command.CommandOriginData
import org.cloudburstmc.protocol.bedrock.data.command.CommandOriginType
import org.cloudburstmc.protocol.bedrock.packet.CommandRequestPacket
import org.cloudburstmc.protocol.bedrock.packet.TextPacket
import java.util.UUID

class CommandHandlerModule : Module("command_handler", ModuleCategory.Misc, true) {

    private val prefix = "."

    private companion object {
        const val FRIEND_ADDED_MESSAGE = "Fuiste agregado a mi friend list :>"
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return

        val packet = interceptablePacket.packet
        if (packet !is TextPacket) return

        val message = packet.message.toString()
        if (!message.startsWith(prefix)) return

        interceptablePacket.intercept()

        val args = message.substring(prefix.length).split(" ")
        val command = args[0].lowercase()

        when (command) {

            "help" -> displayHelp(args.getOrNull(1))

            "friend", "f" -> handleFriendCommand(args)

            "replay" -> handleReplayCommand(args)

            else -> toggleModule(command)
        }
    }


    private fun handleFriendCommand(args: List<String>) {

        if (args.size < 2) {
            usage()
            return
        }

        when (args[1].lowercase()) {

            "add" -> {
                val query = args.getOrNull(2) ?: return usage(".f add <name>")
                val (uuid, name) = findPlayerByPartial(query) ?: return notFound(query)

                if (FriendManager.isFriend(uuid)) {
                    session.displayClientMessage("§e$name §cis already in your friend list.")
                    return
                }

                FriendManager.addFriend(uuid, name)
                session.displayClientMessage("§aAdded §f$name §aas friend.")
                // Aviso privado (susurro) al jugador agregado, como en KiwiMods.
                sendWhisper(name, FRIEND_ADDED_MESSAGE)
            }

            "remove" -> {
                val query = args.getOrNull(2) ?: return usage(".f remove <name>")
                val (uuid, name) = findFriendByPartial(query) ?: run {
                    session.displayClientMessage("§cNo friend matching \"§f$query§c\" found.")
                    return
                }

                FriendManager.removeFriend(uuid)
                session.displayClientMessage("§eRemoved §f$name §efrom friend list.")
            }

            "list" -> {
                val friends = FriendManager.getFriends()
                if (friends.isEmpty()) {
                    session.displayClientMessage("§7Friend list is empty")
                    return
                }

                session.displayClientMessage("§l§bFriends §7(${friends.size}):")
                friends.forEach { uuid ->
                    val name = session.level.playerMap[uuid]?.name?.toString() ?: uuid.toString()
                    session.displayClientMessage("§7- §f$name")
                }
            }

            "clear" -> {
                FriendManager.clear()
                session.displayClientMessage("§cFriend list cleared.")
            }

            else -> usage()
        }
    }

    private fun resolveUsername(player: Player): String {
        if (player.username.isNotBlank()) return player.username
        return session.level.playerMap[player.uuid]?.name?.toString().orEmpty()
    }

    /**
     * Busca por nombre parcial como KiwiMods: primero los jugadores cercanos (empieza por, luego
     * contiene, el mas cercano primero) y, si no hay, cualquier jugador de la lista del servidor.
     */
    private fun findPlayerByPartial(query: String): Pair<UUID, String>? {
        val q = query.lowercase()
        val lp = session.localPlayer
        val nearby = session.level.entityMap.values
            .filterIsInstance<Player>()
            .filter { it !== lp && it.uuid != lp.uuid }
            .sortedBy { it.distanceSq(lp) }
            .map { it.uuid to resolveUsername(it) }
            .filter { it.second.isNotBlank() }

        nearby.firstOrNull { it.second.lowercase().startsWith(q) }?.let { return it }
        nearby.firstOrNull { it.second.lowercase().contains(q) }?.let { return it }

        val listed = session.level.playerMap.entries
            .filter { it.key != lp.uuid }
            .mapNotNull { e -> e.value.name?.toString()?.takeIf { it.isNotBlank() }?.let { e.key to it } }

        listed.firstOrNull { it.second.lowercase().startsWith(q) }?.let { return it }
        return listed.firstOrNull { it.second.lowercase().contains(q) }
    }

    private fun findFriendByPartial(query: String): Pair<UUID, String>? {
        val q = query.lowercase()
        val named = FriendManager.getFriends().mapNotNull { uuid ->
            session.level.playerMap[uuid]?.name?.toString()?.takeIf { it.isNotBlank() }?.let { uuid to it }
        }
        named.firstOrNull { it.second.lowercase().startsWith(q) }?.let { return it }
        return named.firstOrNull { it.second.lowercase().contains(q) }
    }

    private fun sendWhisper(targetName: String, message: String) {
        val lp = session.localPlayer
        val packet = CommandRequestPacket()
        packet.command = "/msg $targetName $message"
        packet.commandOriginData = CommandOriginData(
            CommandOriginType.PLAYER, lp.uuid, "", lp.runtimeEntityId
        )
        packet.setInternal(false)
        packet.version = 0
        session.serverBound(packet)
    }

    private fun displayHelp(category: String?) {
        session.displayClientMessage(
            """
            §l§c[WClient] §r§7Commands:
            §f.help <category> §7- Show modules
            §f.f §7- Manage friends (.f add/remove/list/clear)
            §f.<module> §7- Toggle module
            """.trimIndent()
        )

        if (category == null) {
            ModuleCategory.entries.forEach { displayCategory(it) }
            return
        }

        try {
            displayCategory(ModuleCategory.valueOf(category.uppercase()))
        } catch (_: Exception) {
            session.displayClientMessage("§cInvalid category")
        }
    }

    private fun displayCategory(category: ModuleCategory) {
        val modules = ModuleManager.modules.filter {
            it.category == category && !it.private
        }

        if (modules.isEmpty()) return

        session.displayClientMessage("§l§b${category.name}:")
        modules.chunked(3).forEach { row ->
            session.displayClientMessage(
                row.joinToString("   ") {
                    val s = if (it.isEnabled) "§a✔" else "§c✘"
                    "$s §f${it.name}"
                }
            )
        }
    }

    private fun handleReplayCommand(args: List<String>) {
        val replay = ModuleManager.modules.find { it is ReplayModule } as? ReplayModule
            ?: return session.displayClientMessage("§cReplay module not found")

        when (args.getOrNull(1)?.lowercase()) {
            "record" -> replay.startRecording()
            "play" -> replay.startPlayback()
            "stop" -> {
                replay.stopRecording()
                replay.stopPlayback()
            }
            "save" -> replay.saveReplay(args.getOrNull(2) ?: return)
            "load" -> replay.loadReplay(args.getOrNull(2) ?: return)
            else -> session.displayClientMessage("§7.replay record | play | stop | save | load")
        }
    }

    private fun toggleModule(name: String) {
        val module = ModuleManager.modules.find {
            it.name.equals(name, true)
        }

        if (module != null && !module.private) {
            module.isEnabled = !module.isEnabled
        } else {
            session.displayClientMessage("§cModule not found: §f$name")
        }
    }

    private fun usage(msg: String = ".friend add <name> | remove <name> | list | clear") {
        session.displayClientMessage("§cUsage: $msg")
    }

    private fun notFound(name: String) {
        session.displayClientMessage("§cPlayer not found: §f$name")
    }
}
