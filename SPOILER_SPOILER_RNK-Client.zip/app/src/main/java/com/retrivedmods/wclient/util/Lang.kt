package com.retrivedmods.wclient.util

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.retrivedmods.wclient.application.AppContext
import java.io.File

/**
 * Idioma de la interfaz (Espanol / English). Se cambia en Config y se guarda en configs/lang.txt.
 * Los textos de la GUI usan Lang.t("espanol", "english"); al cambiar, Compose redibuja solo.
 */
object Lang {

    var spanish by mutableStateOf(true)
        private set

    fun set(toSpanish: Boolean) {
        spanish = toSpanish
        save()
    }

    fun t(es: String, en: String): String = if (spanish) es else en

    fun load() {
        val file = file() ?: return
        if (!file.exists()) return
        runCatching { spanish = file.readText().trim() != "en" }
    }

    private fun save() {
        val file = file() ?: return
        runCatching { file.writeText(if (spanish) "es" else "en") }
    }

    private fun file(): File? {
        if (!AppContext.isInitialized) return null
        val dir = AppContext.instance.filesDir.resolve("configs")
        dir.mkdirs()
        return dir.resolve("lang.txt")
    }
}
