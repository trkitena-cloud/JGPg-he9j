package com.retrivedmods.wclient.game.module.motion

import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.InterceptablePacket
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.packet.CorrectPlayerMovePredictionPacket
import org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.packet.SetEntityMotionPacket
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Testfly portado de KiwiMods (game/module/motion/Fly2Module).
 *
 * Vuelo por empuje: en cada PlayerAuthInputPacket calcula una velocidad (horizontal segun tu
 * input y la rotacion de la camara; vertical segun saltar/agacharse + "Glide") y se la aplica al
 * cliente con un SetEntityMotionPacket. Salta un tick si te has movido mas de 4.5 bloques desde
 * el anterior (teletransporte/correccion) para no acumular el empuje sobre una posicion invalida.
 */
class TestflyModule : Module("testfly", ModuleCategory.Motion) {

    private val hSpeedBps by floatValue("H Speed BPS", 46.0f, 1.0f..100.0f)
    private val upSpeedBps by floatValue("Up Speed BPS", 19.8f, 1.0f..60.0f)
    private val downSpeedBps by floatValue("Down Speed BPS", 46.0f, 1.0f..60.0f)
    private val glide by floatValue("Glide", -0.02f, -0.3f..0.0f)
    private val upHFactor by floatValue("Up H Factor", 0.55f, 0.1f..1.0f)
    private val downHFactor by floatValue("Down H Factor", 0.55f, 0.1f..1.0f)

    // Con glide = 0 y sin input antes no se enviaba nada y la gravedad te bajaba; con Hover se
    // envia movimiento 0 para mantenerte en el aire.
    private val hover by boolValue("Hover", true)

    private var lastPos: Vector3f = Vector3f.ZERO
    private var graceTicks = 0

    override fun onEnabled() {
        super.onEnabled()
        lastPos = Vector3f.ZERO
        graceTicks = 0
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        val packet = interceptablePacket.packet
        if (!isEnabled) return

        // El servidor te corrigio la posicion (teleport / correccion de prediccion): se deja de
        // empujar unos ticks. Si se sigue empujando, cada tick vuelve a chocar con la correccion y
        // el lagback se encadena (o te hunde).
        if (packet is CorrectPlayerMovePredictionPacket ||
            (packet is MovePlayerPacket &&
                packet.runtimeEntityId == session.localPlayer.runtimeEntityId &&
                (packet.mode == MovePlayerPacket.Mode.TELEPORT || packet.mode == MovePlayerPacket.Mode.RESPAWN))
        ) {
            graceTicks = GRACE_TICKS
            lastPos = Vector3f.ZERO
            return
        }

        if (packet !is PlayerAuthInputPacket) return

        val localPlayer = session.localPlayer
        val pos = localPlayer.vec3Position

        if (graceTicks > 0) {
            graceTicks--
            lastPos = pos
            return
        }

        val dx = pos.x - lastPos.x
        val dy = pos.y - lastPos.y
        val dz = pos.z - lastPos.z
        if (sqrt(dx * dx + dy * dy + dz * dz) > MAX_STEP) {
            lastPos = pos
            return
        }

        var vertical = glide.toDouble()
        val up = packet.inputData.contains(PlayerAuthInputData.WANT_UP) ||
            packet.inputData.contains(PlayerAuthInputData.JUMPING)
        val down = packet.inputData.contains(PlayerAuthInputData.WANT_DOWN) ||
            packet.inputData.contains(PlayerAuthInputData.SNEAKING)

        if (!up && !down && packet.motion.x == 0f && packet.motion.y == 0f && glide == 0f) {
            lastPos = pos
            if (hover) {
                session.clientBound(SetEntityMotionPacket().apply {
                    runtimeEntityId = localPlayer.runtimeEntityId
                    motion = Vector3f.ZERO
                })
            }
            return
        }

        var hSpeed = (hSpeedBps / 20f).coerceAtMost(sqrt(5.99f))
        if (up) hSpeed *= upHFactor
        if (down) hSpeed *= downHFactor

        if (up) {
            vertical = (upSpeedBps / 20f).toDouble()
        } else if (down) {
            vertical = (-(downSpeedBps / 20f) + glide).toDouble()
        }

        // packet.motion = (x = strafe, y = forward) en el espacio de la camara.
        val rad = Math.toRadians(packet.rotation.y.toDouble())
        val s = sin(rad)
        val c = cos(rad)
        val fwd = packet.motion.y.toDouble()
        val strafe = packet.motion.x.toDouble()
        val mx = (-s * fwd + c * strafe).toFloat()
        val mz = (c * fwd + s * strafe).toFloat()
        val len = sqrt(mx * mx + mz * mz)

        var outX = 0f
        var outZ = 0f
        if (len > 0.001f) {
            val k = hSpeed / len
            outX = mx * k
            outZ = mz * k
        }

        session.clientBound(SetEntityMotionPacket().apply {
            runtimeEntityId = localPlayer.runtimeEntityId
            motion = Vector3f.from(outX, vertical.toFloat(), outZ)
        })
        lastPos = pos
    }

    private companion object {
        const val MAX_STEP = 4.5f
        const val GRACE_TICKS = 8
    }
}
