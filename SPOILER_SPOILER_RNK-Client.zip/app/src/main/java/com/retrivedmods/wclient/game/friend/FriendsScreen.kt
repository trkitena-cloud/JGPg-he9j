package com.retrivedmods.wclient.game.friend

import com.retrivedmods.wclient.util.Lang

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

private val CardColor = Color(0xFF221D2C)
private val AccentPrimary: Color get() = com.retrivedmods.wclient.util.UiColors.accent
private val MutedText = Color(0xFFA8ADB5)

/** Lista de friends dentro de la GUI. Se refresca cada 500 ms y permite quitar a alguien con un toque. */
@Composable
fun FriendsScreen() {
    var friends by remember { mutableStateOf(FriendManager.entries()) }

    LaunchedEffect(Unit) {
        while (true) {
            friends = FriendManager.entries()
            delay(500)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = Lang.t("Amigos (${friends.size})", "Friends (${friends.size})"),
            color = AccentPrimary,
            style = MaterialTheme.typography.titleMedium
        )
        Spacer(Modifier.height(12.dp))

        if (friends.isEmpty()) {
            Text(
                text = Lang.t("Tu lista esta vacia. Usa .f add <nombre> en el chat.", "Your list is empty. Use .f add <name> in chat."),
                color = MutedText,
                style = MaterialTheme.typography.bodyMedium
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(friends, key = { it.first.toString() }) { (uuid, name) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CardColor, RoundedCornerShape(10.dp))
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = name.ifBlank { uuid.toString().take(8) },
                            color = Color.White,
                            style = MaterialTheme.typography.bodyLarge,
                            maxLines = 1,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = Lang.t("Quitar", "Remove"),
                            color = AccentPrimary,
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier
                                .clickable {
                                    FriendManager.removeFriend(uuid)
                                    friends = FriendManager.entries()
                                }
                                .padding(4.dp)
                        )
                    }
                }
            }
        }
    }
}
