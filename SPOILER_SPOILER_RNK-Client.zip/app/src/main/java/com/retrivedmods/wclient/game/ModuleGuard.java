package com.retrivedmods.wclient.game;

import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Guardian del despachador de modulos (GameSession.beforePacketBound).
 *
 * POR QUE EXISTE
 * Todos los modulos se ejecutan de forma SINCRONA dentro del callback de red del relay, es decir en
 * el mismo hilo (event loop de Netty) que atiende los temporizadores de RakNet (ACK/reenvios cada
 * 10 ms), el vaciado de paquetes salientes (cada 50 ms) y el reenvio de todo el trafico. Si cualquier
 * modulo tarda mucho, o se queda en un bucle, TODO el relay se queda esperando: el juego "se
 * paraliza" y, pasado el timeout de RakNet (10 s), se pierde la conexion. Hasta ahora no habia
 * ninguna medicion, limite ni aviso por modulo, asi que el culpable era invisible.
 *
 * QUE HACE (nada de esto oculta excepciones)
 *  1. Mide cuanto tarda cada modulo habilitado en cada paquete y deja el resultado en logcat
 *     (etiqueta "ModuleGuard") y en el archivo abysm-guard.log.
 *  2. Si un modulo tarda mas de 15 ms en 3 ticks seguidos (PlayerAuthInputPacket) lo pausa 300 ms
 *     (solo los ticks; el resto de paquetes le siguen llegando) y avisa en el chat del juego.
 *  3. Un hilo vigilante vuelca el STACK TRACE del hilo de red cuando una fase lleva mas de 500 ms
 *     sin terminar (bucle infinito, bloqueo, interbloqueo...). Es la evidencia que faltaba.
 *  4. Las excepciones se siguen registrando con su stack trace completo la primera vez; las
 *     repeticiones se resumen cada 5 s con el numero de veces (evita inundar logcat desde el hilo de
 *     red, que en Android es caro).
 *
 * Interruptor general: {@link #enabled}.
 */
public final class ModuleGuard {

    public static final String TAG = "ModuleGuard";

    /** false = no mide ni pausa ni vigila (las excepciones se siguen registrando). */
    public static volatile boolean enabled = true;

    // ---- umbrales (ns salvo que se indique)
    static final long SLOW_CALL_NS = 15_000_000L;       // una llamada de modulo > 15 ms es "lenta"
    static final int STRIKES_TO_PAUSE = 3;              // ticks lentos seguidos antes de pausar
    static final long PAUSE_NS = 300_000_000L;          // duracion de la pausa
    static final long STALL_NS = 500_000_000L;          // fase sin terminar => volcado de stack
    static final long STALL_REPEAT_NS = 2_000_000_000L; // minimo entre volcados del mismo hilo
    static final long WARN_INTERVAL_NS = 2_000_000_000L;
    static final long CHAT_INTERVAL_NS = 5_000_000_000L;
    static final long ERR_SUMMARY_NS = 5_000_000_000L;
    static final long SUMMARY_NS = 10_000_000_000L;
    static final long WATCHDOG_PERIOD_MS = 250L;
    static final int MAX_STACK_FRAMES = 30;
    static final long MAX_LOG_FILE_BYTES = 1_048_576L;
    static final int MAX_QUEUED_LINES = 400;

    private static final String BASE_PHASE = "sesion";

    // ---------------------------------------------------------------- estado por hilo de red
    private static final class Slot {
        final Thread thread;
        volatile String label;   // fase en curso
        volatile long startNs;   // 0 = inactivo
        long lastDumpNs;         // solo lo toca el vigilante

        Slot(Thread thread) {
            this.thread = thread;
        }
    }

    private static final ThreadLocal<Slot> SLOT = new ThreadLocal<Slot>();
    private static final CopyOnWriteArrayList<Slot> SLOTS = new CopyOnWriteArrayList<Slot>();

    // ---------------------------------------------------------------- estadisticas por modulo
    private static final class Stat {
        final String name;
        long calls;
        long totalNs;
        long maxNs;
        int strikes;
        long pauses;
        long lastWarnNs;
        long lastChatNs;
        volatile long pausedUntilNs; // 0 = activo

        Stat(String name) {
            this.name = name;
        }
    }

    private static final ConcurrentHashMap<String, Stat> STATS = new ConcurrentHashMap<String, Stat>();

    private static final class ErrStat {
        long total;
        long sinceSummary;
        long lastLogNs;
    }

    private static final ConcurrentHashMap<String, ErrStat> ERRORS = new ConcurrentHashMap<String, ErrStat>();

    // ---------------------------------------------------------------- archivo de log
    private static final ConcurrentLinkedQueue<String> FILE_QUEUE = new ConcurrentLinkedQueue<String>();
    private static volatile File logFile;
    private static final AtomicBoolean WATCHDOG_STARTED = new AtomicBoolean(false);

    private ModuleGuard() {
    }

    /** Linea informativa: va a logcat y a abysm-guard.log. */
    public static void info(String msg) {
        Log.i(TAG, msg);
        enqueueFile("INFO", msg);
        ensureWatchdog();
    }

    /** Archivo donde se copian los avisos (opcional). Se escribe desde el hilo vigilante, nunca desde el hilo de red. */
    public static void setLogFile(File file) {
        logFile = file;
    }

    // ================================================================= API usada por GameSession

    /** Entra en el despacho de un paquete (fase base). Emparejar siempre con {@link #end()}. */
    public static void begin(String label) {
        if (!enabled) {
            return;
        }
        Slot s = slot();
        s.label = label;
        s.startNs = System.nanoTime();
    }

    /** Sale del despacho. Incondicional para no dejar un hilo marcado como "ocupado". */
    public static void end() {
        Slot s = SLOT.get();
        if (s != null) {
            s.startNs = 0L;
            s.label = null;
        }
    }

    /** Marca el inicio de una fase (un modulo, level, kiwiWorld...). Devuelve el nanoTime de inicio. */
    public static long phase(String label) {
        long now = System.nanoTime();
        if (enabled) {
            Slot s = slot();
            s.label = label;
            s.startNs = now;
        }
        return now;
    }

    /**
     * Cierra una fase: acumula estadisticas, registra si fue lenta y, si es un tick y se repite,
     * pausa el modulo. Devuelve un texto para mostrar en el chat del juego o null.
     */
    public static String finish(String label, long startNs, Object packet, boolean tick) {
        long now = System.nanoTime();
        if (!enabled) {
            return null;
        }
        Slot s = SLOT.get();
        if (s != null) {
            s.label = BASE_PHASE;
            s.startNs = now;
        }
        long dt = now - startNs;
        Stat st = stat(label);
        st.calls++;
        st.totalNs += dt;
        if (dt > st.maxNs) {
            st.maxNs = dt;
        }
        if (dt < SLOW_CALL_NS) {
            if (tick) {
                st.strikes = 0;
            }
            return null;
        }

        if (now - st.lastWarnNs >= WARN_INTERVAL_NS) {
            st.lastWarnNs = now;
            log(Log.WARN, "'" + label + "' tardo " + ms(dt) + " ms en " + packetName(packet)
                    + " [hilo " + Thread.currentThread().getName() + "]");
        }

        String chat = null;
        if (tick) {
            st.strikes++;
            if (st.strikes >= STRIKES_TO_PAUSE) {
                st.strikes = 0;
                st.pauses++;
                st.pausedUntilNs = now + PAUSE_NS;
                log(Log.WARN, "'" + label + "' PAUSADO " + (PAUSE_NS / 1_000_000L) + " ms: "
                        + STRIKES_TO_PAUSE + " ticks lentos seguidos (ultimo " + ms(dt) + " ms)");
                if (now - st.lastChatNs >= CHAT_INTERVAL_NS) {
                    st.lastChatNs = now;
                    chat = "\u00a7e[Guard] " + label + " va muy lento (" + ms(dt)
                            + " ms por tick) y se pauso un momento. Baja rangos/objetivos o desactivalo.";
                }
            }
        }
        return chat;
    }

    /** true mientras el modulo esta en pausa por lentitud (solo se consulta para ticks). */
    public static boolean shouldSkip(String name) {
        if (!enabled) {
            return false;
        }
        Stat st = STATS.get(name);
        if (st == null) {
            return false;
        }
        long until = st.pausedUntilNs;
        if (until == 0L) {
            return false;
        }
        if (System.nanoTime() - until < 0L) {
            return true;
        }
        st.pausedUntilNs = 0L;
        return false;
    }

    /**
     * Registra una excepcion de un modulo/handler. La primera vez con stack trace completo; las
     * repeticiones se agrupan en un resumen periodico. Nunca la traga en silencio.
     */
    public static void reportError(String where, Throwable t) {
        String key = where + ":" + t.getClass().getName();
        ErrStat es = ERRORS.get(key);
        long now = System.nanoTime();
        if (es == null) {
            ErrStat created = new ErrStat();
            es = ERRORS.putIfAbsent(key, created);
            if (es == null) {
                es = created;
                es.total = 1;
                es.lastLogNs = now;
                Log.e(TAG, "Excepcion en '" + where + "' (primera vez; las repeticiones se resumen cada "
                        + (ERR_SUMMARY_NS / 1_000_000_000L) + " s)", t);
                enqueueFile("ERROR", "Excepcion en '" + where + "': " + stackToString(t));
                ensureWatchdog();
                return;
            }
        }
        es.total++;
        es.sinceSummary++;
        if (now - es.lastLogNs >= ERR_SUMMARY_NS) {
            long n = es.sinceSummary;
            es.sinceSummary = 0;
            es.lastLogNs = now;
            log(Log.ERROR, "'" + where + "' sigue lanzando " + t.getClass().getSimpleName() + ": " + t.getMessage()
                    + " (" + n + " veces mas, " + es.total + " en total)");
        }
    }

    // ================================================================= internos

    private static Stat stat(String name) {
        Stat s = STATS.get(name);
        if (s == null) {
            Stat created = new Stat(name);
            s = STATS.putIfAbsent(name, created);
            if (s == null) {
                s = created;
            }
        }
        return s;
    }

    private static Slot slot() {
        Slot s = SLOT.get();
        if (s == null) {
            s = new Slot(Thread.currentThread());
            SLOT.set(s);
            SLOTS.add(s);
            ensureWatchdog();
        }
        return s;
    }

    private static String ms(long ns) {
        return String.valueOf(ns / 1_000_000L);
    }

    private static String packetName(Object packet) {
        return packet == null ? "?" : packet.getClass().getSimpleName();
    }

    private static void log(int priority, String msg) {
        Log.println(priority, TAG, msg);
        enqueueFile(priority == Log.ERROR ? "ERROR" : "WARN", msg);
    }

    private static void enqueueFile(String level, String msg) {
        if (logFile == null) {
            return;
        }
        if (FILE_QUEUE.size() >= MAX_QUEUED_LINES) {
            return;
        }
        FILE_QUEUE.add(level + " " + msg);
    }

    private static String stackToString(Throwable t) {
        StringBuilder sb = new StringBuilder();
        sb.append(t.toString());
        StackTraceElement[] st = t.getStackTrace();
        int n = Math.min(st.length, MAX_STACK_FRAMES);
        for (int i = 0; i < n; i++) {
            sb.append("\n    at ").append(st[i]);
        }
        return sb.toString();
    }

    // ================================================================= hilo vigilante

    private static void ensureWatchdog() {
        if (WATCHDOG_STARTED.compareAndSet(false, true)) {
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    watchdogLoop();
                }
            }, "ModuleGuard-watchdog");
            t.setDaemon(true);
            t.start();
            log(Log.INFO, "activo: lento >" + (SLOW_CALL_NS / 1_000_000L) + " ms, pausa tras "
                    + STRIKES_TO_PAUSE + " ticks lentos, volcado de stack si una fase supera "
                    + (STALL_NS / 1_000_000L) + " ms");
        }
    }

    private static void watchdogLoop() {
        long lastSummary = System.nanoTime();
        while (true) {
            try {
                Thread.sleep(WATCHDOG_PERIOD_MS);
            } catch (InterruptedException e) {
                return;
            }
            try {
                long now = System.nanoTime();
                if (enabled) {
                    for (Slot s : SLOTS) {
                        if (!s.thread.isAlive()) {
                            SLOTS.remove(s);
                            continue;
                        }
                        long started = s.startNs;
                        String label = s.label;
                        if (started != 0L && label != null && now - started >= STALL_NS
                                && now - s.lastDumpNs >= STALL_REPEAT_NS) {
                            s.lastDumpNs = now;
                            dumpStall(s, label, now - started);
                        }
                    }
                    if (now - lastSummary >= SUMMARY_NS) {
                        lastSummary = now;
                        summarize();
                    }
                }
                flushFile();
            } catch (Throwable t) {
                Log.e(TAG, "fallo en el hilo vigilante", t);
            }
        }
    }

    private static void dumpStall(Slot s, String label, long stuckNs) {
        StackTraceElement[] st = s.thread.getStackTrace();
        StringBuilder sb = new StringBuilder();
        sb.append("ATASCO: el hilo '").append(s.thread.getName()).append("' lleva ").append(ms(stuckNs))
                .append(" ms en la fase '").append(label).append("' (estado ").append(s.thread.getState()).append(")");
        int n = Math.min(st.length, MAX_STACK_FRAMES);
        for (int i = 0; i < n; i++) {
            sb.append("\n    at ").append(st[i]);
        }
        log(Log.ERROR, sb.toString());
    }

    private static void summarize() {
        for (Stat st : STATS.values()) {
            long calls = st.calls;
            if (calls == 0L) {
                continue;
            }
            long avgUs = st.totalNs / calls / 1_000L;
            long max = st.maxNs;
            long pauses = st.pauses;
            st.calls = 0L;
            st.totalNs = 0L;
            st.maxNs = 0L;
            if (max >= SLOW_CALL_NS || avgUs >= 2_000L || pauses > 0L) {
                log(Log.INFO, "perfil '" + st.name + "': " + calls + " llamadas, media " + avgUs + " us, max "
                        + ms(max) + " ms, pausas acumuladas " + pauses);
            }
        }
    }

    private static void flushFile() {
        File f = logFile;
        if (f == null || FILE_QUEUE.isEmpty()) {
            return;
        }
        FileWriter w = null;
        try {
            File parent = f.getParentFile();
            if (parent != null) {
                parent.mkdirs();
            }
            boolean append = !(f.exists() && f.length() > MAX_LOG_FILE_BYTES);
            w = new FileWriter(f, append);
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US);
            String line;
            while ((line = FILE_QUEUE.poll()) != null) {
                w.write(fmt.format(new Date()));
                w.write(' ');
                w.write(line);
                w.write('\n');
            }
        } catch (IOException ignored) {
            // el log en archivo es opcional; logcat sigue funcionando
        } finally {
            if (w != null) {
                try {
                    w.close();
                } catch (IOException ignored) {
                    // nada que hacer
                }
            }
        }
    }
}
