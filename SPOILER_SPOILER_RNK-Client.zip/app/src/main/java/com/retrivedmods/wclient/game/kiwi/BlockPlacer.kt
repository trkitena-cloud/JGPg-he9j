package com.retrivedmods.wclient.game.kiwi

import com.retrivedmods.wclient.game.GameSession
import com.retrivedmods.wclient.game.entity.Entity
import com.retrivedmods.wclient.game.entity.Item
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.registry.BlockDefinition
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.ItemUseTransaction
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.MobEquipmentPacket
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.sqrt

/** Rotacion (yaw, pitch) en grados, como la de Kiwi (game/utils/math/Rotation). */
data class Rotation(val yaw: Float, val pitch: Float)

/** Rotacion para mirar de [from] a [to] (misma formula que RotationUtilsKt.toRotation de Kiwi). */
fun toRotation(from: Vector3f, to: Vector3f): Rotation {
    val x = (to.x - from.x).toDouble()
    val y = (to.y - from.y).toDouble()
    val z = (to.z - from.z).toDouble()
    return Rotation(
        (Math.toDegrees(atan2(z, x)) - 90.0).toFloat(),
        (-Math.toDegrees(atan2(y, sqrt(x * x + z * z)))).toFloat()
    )
}

fun angleDifference(a: Float, b: Float): Float = ((((a - b) % 360f) + 540f) % 360f) - 180f

fun rotationDifference(a: Rotation, b: Rotation): Float =
    hypot(angleDifference(a.yaw, b.yaw), a.pitch - b.pitch)

/**
 * Colocacion de bloques de KiwiMods (game/utils/BlockPlacer): busca un bloque solido contiguo que
 * sirva de apoyo, envia el clic de uso de item al servidor y registra la colocacion esperada.
 */
object BlockPlacer {

    val REPLACEABLE: Set<String> = setOf(
        "minecraft:air", "minecraft:tallgrass", "minecraft:double_plant", "minecraft:water",
        "minecraft:flowing_water", "minecraft:lava", "minecraft:flowing_lava", "minecraft:snow_layer",
        "minecraft:fire", "minecraft:structure_void", "minecraft:soul_fire", "minecraft:short_grass",
        "minecraft:fern", "minecraft:dead_bush", "minecraft:dandelion", "minecraft:poppy",
        "minecraft:blue_orchid", "minecraft:allium", "minecraft:azure_bluet", "minecraft:red_tulip",
        "minecraft:orange_tulip", "minecraft:peony", "minecraft:rose_bush", "minecraft:seagrass",
        "minecraft:tall_seagrass", "minecraft:kelp", "minecraft:twisting_vines", "minecraft:weeping_vines"
    )

    data class SupportClick(
        val blockPosition: Vector3i,
        val blockFace: Int,
        val clickPosition: Vector3f,
        val blockDefinition: BlockDefinition?
    )

    fun isSolidBlock(session: GameSession, pos: Vector3i): Boolean {
        val world = session.kiwiWorld
        if (!world.isBlockKnown(pos)) return false
        val rid = world.getBlockRuntimeId(pos)
        if (rid == 0 || rid == session.blockMapping.airId) return false
        return try {
            session.blockMapping.getDefinition(rid).identifier !in REPLACEABLE
        } catch (_: Exception) {
            true
        }
    }

    /** Vecino solido desde el que se puede hacer clic para colocar un bloque en [pos]. */
    fun findSupport(session: GameSession, pos: Vector3i): SupportClick? {
        val candidates = listOf(
            Triple(Vector3i.from(pos.x, pos.y - 1, pos.z), 1, Vector3f.from(0.5f, 1.0f, 0.5f)),
            Triple(Vector3i.from(pos.x, pos.y + 1, pos.z), 0, Vector3f.from(0.5f, 0.0f, 0.5f)),
            Triple(Vector3i.from(pos.x, pos.y, pos.z - 1), 3, Vector3f.from(0.5f, 0.5f, 1.0f)),
            Triple(Vector3i.from(pos.x, pos.y, pos.z + 1), 2, Vector3f.from(0.5f, 0.5f, 0.0f)),
            Triple(Vector3i.from(pos.x - 1, pos.y, pos.z), 5, Vector3f.from(1.0f, 0.5f, 0.5f)),
            Triple(Vector3i.from(pos.x + 1, pos.y, pos.z), 4, Vector3f.from(0.0f, 0.5f, 0.5f))
        )
        for ((neighbor, face, click) in candidates) {
            if (!isSolidBlock(session, neighbor)) continue
            val def = session.kiwiWorld.knownDefinition(neighbor)
            if (def != null) return SupportClick(neighbor, face, click, def)
            session.kiwiWorld.requestBlockData(neighbor)
        }
        return null
    }

    fun entityIntersectsBlock(session: GameSession, entity: Entity, pos: Vector3i): Boolean {
        val feetY = session.entityFeetY(entity)
        val isPlayer = entity is Player
        val halfW = if (isPlayer) entity.hitboxWidth() * 0.5f else 0.3f
        val h = if (isPlayer) entity.hitboxHeight() else 1.8f
        return entity.posX + halfW > pos.x && entity.posX - halfW < pos.x + 1 &&
            h + feetY > pos.y && feetY < pos.y + 1 &&
            entity.posZ + halfW > pos.z && entity.posZ - halfW < pos.z + 1
    }

    fun anyEntityInCell(session: GameSession, pos: Vector3i): Boolean {
        for (e in session.level.entityMap.values) {
            if (e !is Item && entityIntersectsBlock(session, e, pos)) return true
        }
        return entityIntersectsBlock(session, session.localPlayer, pos)
    }

    fun isPlaceableCell(session: GameSession, pos: Vector3i, placeRange: Float): Boolean {
        val lp = session.localPlayer
        val world = session.kiwiWorld
        if (!world.isBlockKnown(pos)) {
            world.requestBlockData(pos)
            return false
        }
        val rid = world.getBlockRuntimeId(pos)
        if (rid != 0 && rid != session.blockMapping.airId) {
            val def = try { session.blockMapping.getDefinition(rid) } catch (_: Exception) { null }
            if (def == null || def.identifier !in REPLACEABLE) return false
        }
        if (anyEntityInCell(session, pos)) return false

        val feetY = session.entityFeetY(lp)
        val dx = lp.posX - (pos.x + 0.5f)
        val dy = feetY - (pos.y + 0.5f)
        return abs(dx) <= placeRange &&
            abs(lp.posZ - (pos.z + 0.5f)) <= placeRange &&
            dy >= -placeRange && dy <= placeRange + 2.0f
    }

    /**
     * Coloca un bloque en [pos] haciendo clic sobre un bloque solido contiguo (apoyo real).
     * Si no hay apoyo devuelve false: este port no incluye la colocacion "sobre aire" de Kiwi
     * (clic en una celda vacia sin apoyo), porque se salta la validacion de apoyo del servidor.
     */
    fun placeBlock(
        session: GameSession, pos: Vector3i, slot: Int,
        identifier: String = "minecraft:obsidian"
    ): Boolean {
        val lp = session.localPlayer
        val item = lp.inventory.content.getOrNull(slot) ?: return false

        val support = findSupport(session, pos) ?: return false

        session.serverBound(InventoryTransactionPacket().apply {
            transactionType = InventoryTransactionType.ITEM_USE
            actionType = 0
            blockPosition = support.blockPosition
            blockFace = support.blockFace
            hotbarSlot = slot
            itemInHand = item
            playerPosition = lp.vec3Position
            clickPosition = support.clickPosition
            blockDefinition = support.blockDefinition
            triggerType = ItemUseTransaction.TriggerType.PLAYER_INPUT
            clientInteractPrediction = ItemUseTransaction.PredictedResult.SUCCESS
        })
        session.kiwiWorld.registerPlacement(pos, identifier)
        try {
            session.blockMapping.definitionByIdentifier(identifier)?.let {
                session.kiwiWorld.setBlockPredicted(pos, it.runtimeId)
            }
        } catch (_: Exception) {
        }
        return true
    }

    /**
     * Intenta colocar en [pos]; si no hay apoyo, busca el bloque solido mas cercano (hasta
     * [proximity]) y coloca un bloque en una celda vecina de el para crear el apoyo.
     */
    fun tryPlaceWithSupport(
        session: GameSession, pos: Vector3i, slot: Int,
        reach: Float, identifier: String, proximity: Int
    ): Boolean {
        if (placeBlock(session, pos, slot, identifier)) return true

        var nearest: Vector3i? = null
        var best = Int.MAX_VALUE
        for (dx in -proximity..proximity) for (dy in -proximity..proximity) for (dz in -proximity..proximity) {
            if (dx == 0 && dy == 0 && dz == 0) continue
            val p = Vector3i.from(pos.x + dx, pos.y + dy, pos.z + dz)
            val d = dx * dx + dy * dy + dz * dz
            if (isSolidBlock(session, p) && d < best) {
                nearest = p
                best = d
            }
        }
        val anchor = nearest ?: return false

        val neighbors = ArrayList<Pair<Vector3i, Int>>()
        for (dx in -1..1) for (dy in -1..1) for (dz in -1..1) {
            if (dx == 0 && dy == 0 && dz == 0) continue
            val n = Vector3i.from(anchor.x + dx, anchor.y + dy, anchor.z + dz)
            val ox = pos.x - n.x
            val oy = pos.y - n.y
            val oz = pos.z - n.z
            neighbors.add(n to (ox * ox + oy * oy + oz * oz))
        }
        neighbors.sortBy { it.second }
        for ((cell, _) in neighbors) {
            if (isPlaceableCell(session, cell, reach) && placeBlock(session, cell, slot, identifier)) return true
        }
        return false
    }

    fun findHotbarSlot(session: GameSession, predicate: (String) -> Boolean): Int? {
        val inv = session.localPlayer.inventory
        for (i in 0 until 9) {
            val item = inv.content[i]
            if (item.count > 0) {
                val id = item.definition?.identifier ?: continue
                if (predicate(id)) return i
            }
        }
        return null
    }

    fun findObsidianSlot(session: GameSession): Int? = findHotbarSlot(session) { it.contains("obsidian") }

    fun findButtonSlot(session: GameSession): Int? = findHotbarSlot(session) { it.endsWith("button") }

    /** Avisa al servidor de que la ranura activa es [slot] (sin tocar la que ve el cliente). */
    fun sendServerSlot(session: GameSession, slot: Int): Boolean {
        val lp = session.localPlayer
        val item: ItemData = lp.inventory.content.getOrNull(slot) ?: return false
        session.serverBound(MobEquipmentPacket().apply {
            runtimeEntityId = lp.runtimeEntityId
            this.item = item
            inventorySlot = slot
            hotbarSlot = slot
        })
        return true
    }

    fun feetBlockPos(entity: Entity, feetY: Float): Vector3i =
        Vector3i.from(floor(entity.posX).toInt(), floor(feetY).toInt(), floor(entity.posZ).toInt())
}
