package com.retrivedmods.wclient.game.kiwi

import com.retrivedmods.wclient.game.GameSession
import com.retrivedmods.wclient.game.entity.Entity
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Piezas de KiwiMods que los modulos portados necesitan y que Lumina no tiene.
 * Se mantienen aqui (en vez de tocar clases base de Lumina) para que el port sea aditivo.
 */

/** Lista de amigos de Kiwi (por UUID). Los modulos de combate no atacan ni cuentan pops de amigos. */
object FriendManager {
    private val wc = com.retrivedmods.wclient.game.friend.FriendManager

    fun isFriend(uuid: UUID): Boolean = wc.isFriend(uuid)
    fun add(uuid: UUID) { wc.addFriend(uuid) }
    fun remove(uuid: UUID) { wc.removeFriend(uuid) }
    fun toggle(uuid: UUID): Boolean = if (wc.isFriend(uuid)) { wc.removeFriend(uuid); false } else { wc.addFriend(uuid); true }
    fun clear() = wc.clear()
}

const val PLAYER_EYE_HEIGHT = 1.62f

/**
 * Altura de los pies de una entidad (equivalente a Level.entityFeetY de Kiwi, sin la calibracion
 * adaptativa por chunks). En Bedrock la Y de red de un Player es la de los ojos (pies + 1.62);
 * la del resto de entidades ya es la de los pies.
 */
fun GameSession.entityFeetY(e: Entity): Float =
    if (e is Player || e is LocalPlayer) e.posY - PLAYER_EYE_HEIGHT else e.posY

/** Posicion de los ojos del jugador local (su posY de red ya es a nivel de ojos). */
fun GameSession.localEyeY(): Float = localPlayer.posY

/** Altura de hitbox de la entidad (metadata HEIGHT, 1.8 por defecto). */
fun Entity.hitboxHeight(): Float =
    (metadata[org.cloudburstmc.protocol.bedrock.data.entity.EntityDataTypes.HEIGHT] as? Float) ?: 1.8f

fun Entity.hitboxWidth(): Float =
    (metadata[org.cloudburstmc.protocol.bedrock.data.entity.EntityDataTypes.WIDTH] as? Float) ?: 0.6f

/**
 * Estado "usando item" del jugador local. En Kiwi era un campo de Entity que solo escribia
 * NoSlowDown y que leian los modulos con "Eat Stop" (pausan sus acciones mientras comes).
 * Aqui vive aparte para no tocar Entity/LocalPlayer de Lumina.
 */
object ItemUseState {
    @Volatile
    var using: Boolean = false
}

/**
 * Equivalente simplificado de Level.adaptiveFeetY de Kiwi (que ademas calibraba la convencion de
 * altura con los bloques del suelo). Jugador local: posY + manualOffset (normalmente -1.62).
 * Resto de jugadores: su Y de red es a nivel de ojos, asi que se resta la altura de ojos.
 * Para entidades que no son jugadores (cristales, mobs) usa entityFeetY / posY directamente.
 */
@Suppress("UNUSED_PARAMETER")
fun GameSession.adaptiveFeetY(posY: Float, x: Int, z: Int, isLocalPlayer: Boolean, manualOffset: Float): Float =
    if (isLocalPlayer) posY + manualOffset else posY - PLAYER_EYE_HEIGHT + manualOffset

/** Ataca una entidad por su runtimeId (aunque aun no la conozcamos), como LocalPlayer.attack de Kiwi. */
fun GameSession.attackEntityId(runtimeId: Long, swing: Boolean = true) {
    val lp = localPlayer
    if (swing) lp.swing()
    serverBound(InventoryTransactionPacket().apply {
        transactionType = InventoryTransactionType.ITEM_USE_ON_ENTITY
        actionType = 1
        runtimeEntityId = runtimeId
        hotbarSlot = lp.inventory.heldItemSlot
        itemInHand = lp.inventory.hand
        playerPosition = lp.vec3Position
        clickPosition = Vector3f.ZERO
    })
}
